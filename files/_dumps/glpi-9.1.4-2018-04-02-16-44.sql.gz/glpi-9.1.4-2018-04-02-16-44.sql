#GLPI Dump database on 2018-04-02 16:44

### Dump table glpi_alerts

DROP TABLE IF EXISTS `glpi_alerts`;
CREATE TABLE `glpi_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php ALERT_* constant',
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`type`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_apiclients

DROP TABLE IF EXISTS `glpi_apiclients`;
CREATE TABLE `glpi_apiclients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `ipv4_range_start` bigint(20) DEFAULT NULL,
  `ipv4_range_end` bigint(20) DEFAULT NULL,
  `ipv6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `app_token_date` datetime DEFAULT NULL,
  `dolog_method` tinyint(4) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_apiclients` VALUES ('1','0','1','full access from localhost',NULL,'1','2130706433','2130706433','::1','',NULL,'0',NULL);

### Dump table glpi_authldapreplicates

DROP TABLE IF EXISTS `glpi_authldapreplicates`;
CREATE TABLE `glpi_authldapreplicates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `authldaps_id` (`authldaps_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_authldaps

DROP TABLE IF EXISTS `glpi_authldaps`;
CREATE TABLE `glpi_authldaps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `basedn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rootdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '389',
  `condition` text COLLATE utf8_unicode_ci,
  `login_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'uid',
  `use_tls` tinyint(1) NOT NULL DEFAULT '0',
  `group_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `group_condition` text COLLATE utf8_unicode_ci,
  `group_search_type` int(11) NOT NULL DEFAULT '0',
  `group_member_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email1_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_dn` tinyint(1) NOT NULL DEFAULT '1',
  `time_offset` int(11) NOT NULL DEFAULT '0' COMMENT 'in seconds',
  `deref_option` int(11) NOT NULL DEFAULT '0',
  `title_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_condition` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `rootdn_passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_number_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email2_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email3_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email4_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagesize` int(11) NOT NULL DEFAULT '0',
  `ldap_maxlimit` int(11) NOT NULL DEFAULT '0',
  `can_support_pagesize` tinyint(1) NOT NULL DEFAULT '0',
  `picture_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_default` (`is_default`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_authmails

DROP TABLE IF EXISTS `glpi_authmails`;
CREATE TABLE `glpi_authmails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `connect_string` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `is_active` (`is_active`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_autoupdatesystems

DROP TABLE IF EXISTS `glpi_autoupdatesystems`;
CREATE TABLE `glpi_autoupdatesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklistedmailcontents

DROP TABLE IF EXISTS `glpi_blacklistedmailcontents`;
CREATE TABLE `glpi_blacklistedmailcontents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_blacklists

DROP TABLE IF EXISTS `glpi_blacklists`;
CREATE TABLE `glpi_blacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_blacklists` VALUES ('1','1','empty IP','',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('2','1','localhost','127.0.0.1',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('3','1','zero IP','0.0.0.0',NULL,NULL,NULL);
INSERT INTO `glpi_blacklists` VALUES ('4','2','empty MAC','',NULL,NULL,NULL);

### Dump table glpi_bookmarks

DROP TABLE IF EXISTS `glpi_bookmarks`;
CREATE TABLE `glpi_bookmarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php BOOKMARK_* constant',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_private` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `query` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `is_private` (`is_private`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_bookmarks_users

DROP TABLE IF EXISTS `glpi_bookmarks_users`;
CREATE TABLE `glpi_bookmarks_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `bookmarks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`),
  KEY `bookmarks_id` (`bookmarks_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_budgets

DROP TABLE IF EXISTS `glpi_budgets`;
CREATE TABLE `glpi_budgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `budgettypes_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `begin_date` (`begin_date`),
  KEY `is_template` (`is_template`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `locations_id` (`locations_id`),
  KEY `budgettypes_id` (`budgettypes_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_budgettypes

DROP TABLE IF EXISTS `glpi_budgettypes`;
CREATE TABLE `glpi_budgettypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendars

DROP TABLE IF EXISTS `glpi_calendars`;
CREATE TABLE `glpi_calendars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `cache_duration` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendars` VALUES ('1','Default','0','1','Default calendar',NULL,'[0,43200,43200,43200,43200,43200,0]',NULL);

### Dump table glpi_calendars_holidays

DROP TABLE IF EXISTS `glpi_calendars_holidays`;
CREATE TABLE `glpi_calendars_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `holidays_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`calendars_id`,`holidays_id`),
  KEY `holidays_id` (`holidays_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_calendarsegments

DROP TABLE IF EXISTS `glpi_calendarsegments`;
CREATE TABLE `glpi_calendarsegments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `day` tinyint(1) NOT NULL DEFAULT '1' COMMENT 'numer of the day based on date(w)',
  `begin` time DEFAULT NULL,
  `end` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendars_id` (`calendars_id`),
  KEY `day` (`day`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_calendarsegments` VALUES ('1','1','0','0','1','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('2','1','0','0','2','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('3','1','0','0','3','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('4','1','0','0','4','08:00:00','20:00:00');
INSERT INTO `glpi_calendarsegments` VALUES ('5','1','0','0','5','08:00:00','20:00:00');

### Dump table glpi_cartridgeitems

DROP TABLE IF EXISTS `glpi_cartridgeitems`;
CREATE TABLE `glpi_cartridgeitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `cartridgeitemtypes_id` (`cartridgeitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitems_printermodels

DROP TABLE IF EXISTS `glpi_cartridgeitems_printermodels`;
CREATE TABLE `glpi_cartridgeitems_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`printermodels_id`,`cartridgeitems_id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridgeitemtypes

DROP TABLE IF EXISTS `glpi_cartridgeitemtypes`;
CREATE TABLE `glpi_cartridgeitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_cartridges

DROP TABLE IF EXISTS `glpi_cartridges`;
CREATE TABLE `glpi_cartridges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `cartridgeitems_id` int(11) NOT NULL DEFAULT '0',
  `printers_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_use` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `pages` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cartridgeitems_id` (`cartridgeitems_id`),
  KEY `printers_id` (`printers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changecosts

DROP TABLE IF EXISTS `glpi_changecosts`;
CREATE TABLE `glpi_changecosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `changes_id` (`changes_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes

DROP TABLE IF EXISTS `glpi_changes`;
CREATE TABLE `glpi_changes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `controlistcontent` longtext COLLATE utf8_unicode_ci,
  `rolloutplancontent` longtext COLLATE utf8_unicode_ci,
  `backoutplancontent` longtext COLLATE utf8_unicode_ci,
  `checklistcontent` longtext COLLATE utf8_unicode_ci,
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `due_date` (`due_date`),
  KEY `global_validation` (`global_validation`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_changes` VALUES ('1','Activación reporte en SISREC','0','0','0','5',']Se solicita activar reporte de octubre para el contratista con CC 1152702694.

NOTA 1: La oficina 232 es del Jefe del Centro de Investigación:

NOTA 2: La oficina 237, donde me ubico, no está en el listado.','2017-11-14 16:07:51','2017-11-14 16:05:52','2017-11-14 16:07:51',NULL,'2017-11-14 10:55:00','2','2','5','3','4','2',NULL,NULL,NULL,NULL,NULL,'1','0','0','&lt;p&gt;Se ha realizado la  activación del reporte para el mes de octubre. Ademas, se han agregado las oficinas en el sistema. &lt;/p&gt;
&lt;p&gt;Un feliz día,&lt;/p&gt;','0','2017-11-14 16:06:32','0','0','119','2017-11-14 16:06:07');

### Dump table glpi_changes_groups

DROP TABLE IF EXISTS `glpi_changes_groups`;
CREATE TABLE `glpi_changes_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_items

DROP TABLE IF EXISTS `glpi_changes_items`;
CREATE TABLE `glpi_changes_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_problems

DROP TABLE IF EXISTS `glpi_changes_problems`;
CREATE TABLE `glpi_changes_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `problems_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`problems_id`),
  KEY `problems_id` (`problems_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_projects

DROP TABLE IF EXISTS `glpi_changes_projects`;
CREATE TABLE `glpi_changes_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`projects_id`),
  KEY `projects_id` (`projects_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_suppliers

DROP TABLE IF EXISTS `glpi_changes_suppliers`;
CREATE TABLE `glpi_changes_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changes_tickets

DROP TABLE IF EXISTS `glpi_changes_tickets`;
CREATE TABLE `glpi_changes_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_changes_tickets` VALUES ('1','1','4');

### Dump table glpi_changes_users

DROP TABLE IF EXISTS `glpi_changes_users`;
CREATE TABLE `glpi_changes_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`changes_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_changes_users` VALUES ('1','1','2','1','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_changes_users` VALUES ('2','1','2','2','1','juan.correa2@udea.edu.co');

### Dump table glpi_changetasks

DROP TABLE IF EXISTS `glpi_changetasks`;
CREATE TABLE `glpi_changetasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `changes_id` (`changes_id`),
  KEY `state` (`state`),
  KEY `users_id` (`users_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `taskcategories_id` (`taskcategories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_changevalidations

DROP TABLE IF EXISTS `glpi_changevalidations`;
CREATE TABLE `glpi_changevalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `changes_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `changes_id` (`changes_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerantiviruses

DROP TABLE IF EXISTS `glpi_computerantiviruses`;
CREATE TABLE `glpi_computerantiviruses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `antivirus_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `signature_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_uptodate` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_expiration` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `antivirus_version` (`antivirus_version`),
  KEY `signature_version` (`signature_version`),
  KEY `is_active` (`is_active`),
  KEY `is_uptodate` (`is_uptodate`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `is_deleted` (`is_deleted`),
  KEY `computers_id` (`computers_id`),
  KEY `date_expiration` (`date_expiration`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computerdisks

DROP TABLE IF EXISTS `glpi_computerdisks`;
CREATE TABLE `glpi_computerdisks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `device` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mountpoint` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesystems_id` int(11) NOT NULL DEFAULT '0',
  `totalsize` int(11) NOT NULL DEFAULT '0',
  `freesize` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `device` (`device`),
  KEY `mountpoint` (`mountpoint`),
  KEY `totalsize` (`totalsize`),
  KEY `freesize` (`freesize`),
  KEY `computers_id` (`computers_id`),
  KEY `filesystems_id` (`filesystems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computermodels

DROP TABLE IF EXISTS `glpi_computermodels`;
CREATE TABLE `glpi_computermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_computermodels` VALUES ('1','Acer-Aspire-E5-471','Computador de escritorio.','2017-08-10 10:43:35','2017-08-10 10:43:35');
INSERT INTO `glpi_computermodels` VALUES ('2','Acer_Aspire-V5-131','Computador de escritorio','2017-08-10 10:43:59','2017-08-10 10:43:59');
INSERT INTO `glpi_computermodels` VALUES ('3','Acer_Aspire-4935','Computador de escritorio','2017-08-10 10:44:10','2017-08-10 10:44:10');
INSERT INTO `glpi_computermodels` VALUES ('4','Lenovo_ThinkCentre-M72e','Computador de escritorio','2017-08-10 10:44:35','2017-08-10 10:44:35');
INSERT INTO `glpi_computermodels` VALUES ('5','Lenovo_ThinkPad-SL410','Computador de escritorio','2017-08-10 10:44:48','2017-08-10 10:44:48');
INSERT INTO `glpi_computermodels` VALUES ('6','Lenovo_C50-30','Computador de escritorio','2017-08-10 10:45:14','2017-08-10 10:45:14');
INSERT INTO `glpi_computermodels` VALUES ('7','Lenovo_ThinkCentre-E73','Computador de escritorio','2017-08-10 10:46:04','2017-08-10 10:46:04');
INSERT INTO `glpi_computermodels` VALUES ('8','Lenovo_ThinkCentre-M700','Computador de escritorio','2017-08-10 10:46:16','2017-08-10 10:46:16');
INSERT INTO `glpi_computermodels` VALUES ('9','Lenovo_IdeaPad-310','Computador portatil','2017-08-10 10:46:34','2017-08-10 10:46:34');
INSERT INTO `glpi_computermodels` VALUES ('10','Lenovo_IdeaPad-510','Computador portatil','2017-08-10 10:46:46','2017-08-10 10:46:46');
INSERT INTO `glpi_computermodels` VALUES ('11','Lenovo_G40-80','Computador portatil','2017-08-10 10:47:01','2017-08-10 10:47:01');
INSERT INTO `glpi_computermodels` VALUES ('12','Dell_Optiplex-745','Computador de escritorio','2017-08-10 10:47:21','2017-08-10 10:47:21');
INSERT INTO `glpi_computermodels` VALUES ('13','Dell_Optiplex-990','Computador de escritorio','2017-08-10 10:47:41','2017-08-10 10:47:41');
INSERT INTO `glpi_computermodels` VALUES ('14','Dell_Optiplex-9010','Computador de escritorio','2017-08-10 10:48:01','2017-08-10 10:48:01');
INSERT INTO `glpi_computermodels` VALUES ('15','HP_Compaq-6005-Pro-SFF','Computador de escritorio','2017-08-10 10:48:14','2017-08-10 10:48:14');
INSERT INTO `glpi_computermodels` VALUES ('16','HP_Compaq-dc5750-SFF','Computador de escritorio','2017-08-10 10:48:27','2017-08-10 10:48:27');
INSERT INTO `glpi_computermodels` VALUES ('17','HP_AIO-20R006LA','Computador de escritorio (Todo en uno)','2017-08-10 10:49:39','2017-08-10 10:49:39');
INSERT INTO `glpi_computermodels` VALUES ('18','HP_AIO-23R003LA','Computador de escritorio (Todo en uno)','2017-08-10 10:49:55','2017-08-10 10:49:55');
INSERT INTO `glpi_computermodels` VALUES ('19','Sure_GA-G41MT-S2','Equipo de escritorio MotherBoard Model GA-G41MT-S2','2017-08-10 10:53:50','2017-08-10 10:53:50');
INSERT INTO `glpi_computermodels` VALUES ('20','Sure_GA-G31M-S2C','Equipo de escritorio MotherBoard GA-G31M-S2C','2017-08-10 10:54:11','2017-08-10 10:54:11');
INSERT INTO `glpi_computermodels` VALUES ('21','Sure_GA-H61M-D2P-B3','Equipo de escritorio MotherBoard Model GA-H61M-D2P-B3','2017-08-10 10:55:00','2017-08-10 10:55:00');
INSERT INTO `glpi_computermodels` VALUES ('22','Sure_945G','Equipo de escritorio MotherBoard Model 945G','2017-08-10 10:55:19','2017-08-10 10:55:19');
INSERT INTO `glpi_computermodels` VALUES ('23','Sure_ECS-945GZT-M','Equipo de escritorio MotherBoard Model ECS-945GZT-M','2017-08-10 10:55:41','2017-08-10 10:55:41');
INSERT INTO `glpi_computermodels` VALUES ('24','Sure_ECS-H61H2-M3','Equipo de escritorio MotherBoard Model ECS-H61H2-M3','2017-08-10 10:58:59','2017-08-10 10:58:59');
INSERT INTO `glpi_computermodels` VALUES ('25','Sure_Intel-DG31PR','Equipo de escritorio MotherBoard Model Intel-DG31PR','2017-08-10 10:59:16','2017-08-10 10:59:16');

### Dump table glpi_computers

DROP TABLE IF EXISTS `glpi_computers`;
CREATE TABLE `glpi_computers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemversions_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemservicepacks_id` int(11) NOT NULL DEFAULT '0',
  `operatingsystemarchitectures_id` int(11) NOT NULL DEFAULT '0',
  `os_license_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os_licenseid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `os_kernel_version` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autoupdatesystems_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `computermodels_id` int(11) NOT NULL DEFAULT '0',
  `computertypes_id` int(11) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `autoupdatesystems_id` (`autoupdatesystems_id`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `computermodels_id` (`computermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `operatingsystemservicepacks_id` (`operatingsystemservicepacks_id`),
  KEY `operatingsystemversions_id` (`operatingsystemversions_id`),
  KEY `operatingsystemarchitectures_id` (`operatingsystemarchitectures_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `computertypes_id` (`computertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `uuid` (`uuid`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_items

DROP TABLE IF EXISTS `glpi_computers_items`;
CREATE TABLE `glpi_computers_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0' COMMENT 'RELATION to various table, according to itemtype (ID)',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_softwarelicenses

DROP TABLE IF EXISTS `glpi_computers_softwarelicenses`;
CREATE TABLE `glpi_computers_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwarelicenses_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwarelicenses_id`),
  KEY `computers_id` (`computers_id`),
  KEY `softwarelicenses_id` (`softwarelicenses_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computers_softwareversions

DROP TABLE IF EXISTS `glpi_computers_softwareversions`;
CREATE TABLE `glpi_computers_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted_computer` tinyint(1) NOT NULL DEFAULT '0',
  `is_template_computer` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_install` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`computers_id`,`softwareversions_id`),
  KEY `softwareversions_id` (`softwareversions_id`),
  KEY `computers_info` (`entities_id`,`is_template_computer`,`is_deleted_computer`),
  KEY `is_template` (`is_template_computer`),
  KEY `is_deleted` (`is_deleted_computer`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_install` (`date_install`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_computertypes

DROP TABLE IF EXISTS `glpi_computertypes`;
CREATE TABLE `glpi_computertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_computertypes` VALUES ('1','Portatil','Equipo portátil ','2017-06-30 00:07:29','2017-06-30 00:07:29');
INSERT INTO `glpi_computertypes` VALUES ('2','Escritorio - PC','PC + monitor','2017-06-30 10:55:58','2017-06-30 10:55:58');
INSERT INTO `glpi_computertypes` VALUES ('3','Escritorio All in one','Equipo todo en uno','2017-06-30 10:56:35','2017-06-30 10:56:35');
INSERT INTO `glpi_computertypes` VALUES ('4','Servidor','','2017-07-26 10:15:49','2017-07-26 10:15:49');
INSERT INTO `glpi_computertypes` VALUES ('5','Tablet PC','','2017-07-26 10:20:28','2017-07-26 10:16:06');
INSERT INTO `glpi_computertypes` VALUES ('6','Tablet entretenimiento','','2017-07-26 10:16:51','2017-07-26 10:16:51');
INSERT INTO `glpi_computertypes` VALUES ('7','Portátil Ultrabook','','2017-07-26 10:21:18','2017-07-26 10:21:18');
INSERT INTO `glpi_computertypes` VALUES ('8','Estación de trabajo','','2017-07-26 10:22:05','2017-07-26 10:22:05');

### Dump table glpi_computervirtualmachines

DROP TABLE IF EXISTS `glpi_computervirtualmachines`;
CREATE TABLE `glpi_computervirtualmachines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `computers_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `virtualmachinestates_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinesystems_id` int(11) NOT NULL DEFAULT '0',
  `virtualmachinetypes_id` int(11) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `vcpu` int(11) NOT NULL DEFAULT '0',
  `ram` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`computers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `virtualmachinestates_id` (`virtualmachinestates_id`),
  KEY `virtualmachinesystems_id` (`virtualmachinesystems_id`),
  KEY `vcpu` (`vcpu`),
  KEY `ram` (`ram`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `uuid` (`uuid`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_configs

DROP TABLE IF EXISTS `glpi_configs`;
CREATE TABLE `glpi_configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `context` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`context`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_configs` VALUES ('1','core','version','9.1.4');
INSERT INTO `glpi_configs` VALUES ('2','core','show_jobs_at_login','0');
INSERT INTO `glpi_configs` VALUES ('3','core','cut','250');
INSERT INTO `glpi_configs` VALUES ('4','core','list_limit','15');
INSERT INTO `glpi_configs` VALUES ('5','core','list_limit_max','50');
INSERT INTO `glpi_configs` VALUES ('6','core','url_maxlength','30');
INSERT INTO `glpi_configs` VALUES ('7','core','event_loglevel','5');
INSERT INTO `glpi_configs` VALUES ('8','core','use_mailing','1');
INSERT INTO `glpi_configs` VALUES ('9','core','admin_email','gestiontifnsp@udea.edu.co');
INSERT INTO `glpi_configs` VALUES ('10','core','admin_email_name','Área Académica de desarrollo didáctico y tecnológico ');
INSERT INTO `glpi_configs` VALUES ('11','core','admin_reply','gestiontifnsp@udea.edu.co');
INSERT INTO `glpi_configs` VALUES ('12','core','admin_reply_name','Área Académica de desarrollo didáctico y tecnológico');
INSERT INTO `glpi_configs` VALUES ('13','core','mailing_signature','Área Académica de desarrollo didáctico y tecnológico ');
INSERT INTO `glpi_configs` VALUES ('14','core','use_anonymous_helpdesk','0');
INSERT INTO `glpi_configs` VALUES ('15','core','use_anonymous_followups','0');
INSERT INTO `glpi_configs` VALUES ('16','core','language','es_CO');
INSERT INTO `glpi_configs` VALUES ('17','core','priority_1','#d9f3d5');
INSERT INTO `glpi_configs` VALUES ('18','core','priority_2','#ffe0e0');
INSERT INTO `glpi_configs` VALUES ('19','core','priority_3','#ffcece');
INSERT INTO `glpi_configs` VALUES ('20','core','priority_4','#ecf2a6');
INSERT INTO `glpi_configs` VALUES ('21','core','priority_5','#ffadad');
INSERT INTO `glpi_configs` VALUES ('22','core','priority_6','#ff5555');
INSERT INTO `glpi_configs` VALUES ('23','core','date_tax','2005-12-31');
INSERT INTO `glpi_configs` VALUES ('24','core','cas_host','');
INSERT INTO `glpi_configs` VALUES ('25','core','cas_port','443');
INSERT INTO `glpi_configs` VALUES ('26','core','cas_uri','');
INSERT INTO `glpi_configs` VALUES ('27','core','cas_logout','');
INSERT INTO `glpi_configs` VALUES ('28','core','existing_auth_server_field_clean_domain','0');
INSERT INTO `glpi_configs` VALUES ('29','core','planning_begin','08:00');
INSERT INTO `glpi_configs` VALUES ('30','core','planning_end','17:00');
INSERT INTO `glpi_configs` VALUES ('31','core','utf8_conv','1');
INSERT INTO `glpi_configs` VALUES ('32','core','use_public_faq','0');
INSERT INTO `glpi_configs` VALUES ('33','core','url_base','http://saludpublicavirtual.udea.edu.co/glpi');
INSERT INTO `glpi_configs` VALUES ('34','core','show_link_in_mail','0');
INSERT INTO `glpi_configs` VALUES ('35','core','text_login','');
INSERT INTO `glpi_configs` VALUES ('36','core','founded_new_version','');
INSERT INTO `glpi_configs` VALUES ('37','core','dropdown_max','100');
INSERT INTO `glpi_configs` VALUES ('38','core','ajax_wildcard','*');
INSERT INTO `glpi_configs` VALUES ('42','core','ajax_limit_count','50');
INSERT INTO `glpi_configs` VALUES ('43','core','use_ajax_autocompletion','1');
INSERT INTO `glpi_configs` VALUES ('44','core','is_users_auto_add','1');
INSERT INTO `glpi_configs` VALUES ('45','core','date_format','0');
INSERT INTO `glpi_configs` VALUES ('46','core','number_format','0');
INSERT INTO `glpi_configs` VALUES ('47','core','csv_delimiter',';');
INSERT INTO `glpi_configs` VALUES ('48','core','is_ids_visible','0');
INSERT INTO `glpi_configs` VALUES ('50','core','smtp_mode','2');
INSERT INTO `glpi_configs` VALUES ('51','core','smtp_host','smtp.gmail.com');
INSERT INTO `glpi_configs` VALUES ('52','core','smtp_port','465');
INSERT INTO `glpi_configs` VALUES ('53','core','smtp_username','gestiontifnsp@udea.edu.co');
INSERT INTO `glpi_configs` VALUES ('54','core','proxy_name','');
INSERT INTO `glpi_configs` VALUES ('55','core','proxy_port','8080');
INSERT INTO `glpi_configs` VALUES ('56','core','proxy_user','');
INSERT INTO `glpi_configs` VALUES ('57','core','add_followup_on_update_ticket','1');
INSERT INTO `glpi_configs` VALUES ('58','core','keep_tickets_on_delete','0');
INSERT INTO `glpi_configs` VALUES ('59','core','time_step','5');
INSERT INTO `glpi_configs` VALUES ('60','core','decimal_number','2');
INSERT INTO `glpi_configs` VALUES ('61','core','helpdesk_doc_url','');
INSERT INTO `glpi_configs` VALUES ('62','core','central_doc_url','');
INSERT INTO `glpi_configs` VALUES ('63','core','documentcategories_id_forticket','0');
INSERT INTO `glpi_configs` VALUES ('64','core','monitors_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('65','core','phones_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('66','core','peripherals_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('67','core','printers_management_restrict','2');
INSERT INTO `glpi_configs` VALUES ('68','core','use_log_in_files','1');
INSERT INTO `glpi_configs` VALUES ('69','core','time_offset','0');
INSERT INTO `glpi_configs` VALUES ('70','core','is_contact_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('71','core','is_user_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('72','core','is_group_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('73','core','is_location_autoupdate','1');
INSERT INTO `glpi_configs` VALUES ('74','core','state_autoupdate_mode','0');
INSERT INTO `glpi_configs` VALUES ('75','core','is_contact_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('76','core','is_user_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('77','core','is_group_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('78','core','is_location_autoclean','0');
INSERT INTO `glpi_configs` VALUES ('79','core','state_autoclean_mode','0');
INSERT INTO `glpi_configs` VALUES ('80','core','use_flat_dropdowntree','0');
INSERT INTO `glpi_configs` VALUES ('81','core','use_autoname_by_entity','1');
INSERT INTO `glpi_configs` VALUES ('84','core','softwarecategories_id_ondelete','1');
INSERT INTO `glpi_configs` VALUES ('85','core','x509_email_field','');
INSERT INTO `glpi_configs` VALUES ('86','core','x509_cn_restrict','');
INSERT INTO `glpi_configs` VALUES ('87','core','x509_o_restrict','');
INSERT INTO `glpi_configs` VALUES ('88','core','x509_ou_restrict','');
INSERT INTO `glpi_configs` VALUES ('89','core','default_mailcollector_filesize_max','2097152');
INSERT INTO `glpi_configs` VALUES ('90','core','followup_private','0');
INSERT INTO `glpi_configs` VALUES ('91','core','task_private','0');
INSERT INTO `glpi_configs` VALUES ('92','core','default_software_helpdesk_visible','1');
INSERT INTO `glpi_configs` VALUES ('93','core','names_format','1');
INSERT INTO `glpi_configs` VALUES ('94','core','default_graphtype','svg');
INSERT INTO `glpi_configs` VALUES ('95','core','default_requesttypes_id','1');
INSERT INTO `glpi_configs` VALUES ('96','core','use_noright_users_add','1');
INSERT INTO `glpi_configs` VALUES ('97','core','cron_limit','5');
INSERT INTO `glpi_configs` VALUES ('98','core','priority_matrix','{\"1\":{\"1\":\"1\",\"2\":\"1\",\"3\":\"2\",\"4\":\"2\",\"5\":\"2\"},\"2\":{\"1\":\"1\",\"2\":\"2\",\"3\":\"2\",\"4\":\"3\",\"5\":\"3\"},\"3\":{\"1\":\"2\",\"2\":\"2\",\"3\":\"3\",\"4\":\"4\",\"5\":\"4\"},\"4\":{\"1\":\"2\",\"2\":\"3\",\"3\":\"4\",\"4\":\"4\",\"5\":\"5\"},\"5\":{\"1\":\"2\",\"2\":\"3\",\"3\":\"4\",\"4\":\"5\",\"5\":\"5\"}}');
INSERT INTO `glpi_configs` VALUES ('99','core','urgency_mask','62');
INSERT INTO `glpi_configs` VALUES ('100','core','impact_mask','62');
INSERT INTO `glpi_configs` VALUES ('101','core','user_deleted_ldap','0');
INSERT INTO `glpi_configs` VALUES ('102','core','auto_create_infocoms','0');
INSERT INTO `glpi_configs` VALUES ('103','core','use_slave_for_search','0');
INSERT INTO `glpi_configs` VALUES ('104','core','proxy_passwd','');
INSERT INTO `glpi_configs` VALUES ('105','core','smtp_passwd','/KuxsYn005pd2dw=');
INSERT INTO `glpi_configs` VALUES ('106','core','transfers_id_auto','0');
INSERT INTO `glpi_configs` VALUES ('107','core','show_count_on_tabs','1');
INSERT INTO `glpi_configs` VALUES ('108','core','refresh_ticket_list','0');
INSERT INTO `glpi_configs` VALUES ('109','core','set_default_tech','1');
INSERT INTO `glpi_configs` VALUES ('110','core','allow_search_view','2');
INSERT INTO `glpi_configs` VALUES ('111','core','allow_search_all','1');
INSERT INTO `glpi_configs` VALUES ('112','core','allow_search_global','1');
INSERT INTO `glpi_configs` VALUES ('113','core','display_count_on_home','5');
INSERT INTO `glpi_configs` VALUES ('114','core','use_password_security','0');
INSERT INTO `glpi_configs` VALUES ('115','core','password_min_length','8');
INSERT INTO `glpi_configs` VALUES ('116','core','password_need_number','1');
INSERT INTO `glpi_configs` VALUES ('117','core','password_need_letter','1');
INSERT INTO `glpi_configs` VALUES ('118','core','password_need_caps','1');
INSERT INTO `glpi_configs` VALUES ('119','core','password_need_symbol','1');
INSERT INTO `glpi_configs` VALUES ('120','core','use_check_pref','0');
INSERT INTO `glpi_configs` VALUES ('121','core','notification_to_myself','1');
INSERT INTO `glpi_configs` VALUES ('122','core','duedateok_color','#06ff00');
INSERT INTO `glpi_configs` VALUES ('123','core','duedatewarning_color','#ffb800');
INSERT INTO `glpi_configs` VALUES ('124','core','duedatecritical_color','#ff0000');
INSERT INTO `glpi_configs` VALUES ('125','core','duedatewarning_less','20');
INSERT INTO `glpi_configs` VALUES ('126','core','duedatecritical_less','5');
INSERT INTO `glpi_configs` VALUES ('127','core','duedatewarning_unit','%');
INSERT INTO `glpi_configs` VALUES ('128','core','duedatecritical_unit','%');
INSERT INTO `glpi_configs` VALUES ('129','core','realname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('130','core','firstname_ssofield','');
INSERT INTO `glpi_configs` VALUES ('131','core','email1_ssofield','');
INSERT INTO `glpi_configs` VALUES ('132','core','email2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('133','core','email3_ssofield','');
INSERT INTO `glpi_configs` VALUES ('134','core','email4_ssofield','');
INSERT INTO `glpi_configs` VALUES ('135','core','phone_ssofield','');
INSERT INTO `glpi_configs` VALUES ('136','core','phone2_ssofield','');
INSERT INTO `glpi_configs` VALUES ('137','core','mobile_ssofield','');
INSERT INTO `glpi_configs` VALUES ('138','core','comment_ssofield','');
INSERT INTO `glpi_configs` VALUES ('139','core','title_ssofield','');
INSERT INTO `glpi_configs` VALUES ('140','core','category_ssofield','');
INSERT INTO `glpi_configs` VALUES ('141','core','language_ssofield','');
INSERT INTO `glpi_configs` VALUES ('142','core','entity_ssofield','');
INSERT INTO `glpi_configs` VALUES ('143','core','registration_number_ssofield','');
INSERT INTO `glpi_configs` VALUES ('144','core','ssovariables_id','0');
INSERT INTO `glpi_configs` VALUES ('145','core','translate_kb','0');
INSERT INTO `glpi_configs` VALUES ('146','core','translate_dropdowns','0');
INSERT INTO `glpi_configs` VALUES ('147','core','pdffont','helvetica');
INSERT INTO `glpi_configs` VALUES ('148','core','keep_devices_when_purging_item','0');
INSERT INTO `glpi_configs` VALUES ('149','core','maintenance_mode','0');
INSERT INTO `glpi_configs` VALUES ('150','core','maintenance_text','');
INSERT INTO `glpi_configs` VALUES ('151','core','use_rich_text','1');
INSERT INTO `glpi_configs` VALUES ('152','core','attach_ticket_documents_to_mail','0');
INSERT INTO `glpi_configs` VALUES ('153','core','backcreated','0');
INSERT INTO `glpi_configs` VALUES ('154','core','task_state','1');
INSERT INTO `glpi_configs` VALUES ('155','core','layout','lefttab');
INSERT INTO `glpi_configs` VALUES ('156','core','ticket_timeline','1');
INSERT INTO `glpi_configs` VALUES ('157','core','ticket_timeline_keep_replaced_tabs','0');
INSERT INTO `glpi_configs` VALUES ('158','core','palette','greenflat');
INSERT INTO `glpi_configs` VALUES ('159','core','lock_use_lock_item','0');
INSERT INTO `glpi_configs` VALUES ('160','core','lock_autolock_mode','1');
INSERT INTO `glpi_configs` VALUES ('161','core','lock_directunlock_notification','0');
INSERT INTO `glpi_configs` VALUES ('162','core','lock_item_list','[]');
INSERT INTO `glpi_configs` VALUES ('163','core','lock_lockprofile_id','8');
INSERT INTO `glpi_configs` VALUES ('164','core','set_default_requester','1');
INSERT INTO `glpi_configs` VALUES ('165','core','highcontrast_css','0');
INSERT INTO `glpi_configs` VALUES ('166','core','smtp_check_certificate','0');
INSERT INTO `glpi_configs` VALUES ('167','core','enable_api','0');
INSERT INTO `glpi_configs` VALUES ('168','core','enable_api_login_credentials','0');
INSERT INTO `glpi_configs` VALUES ('169','core','enable_api_login_external_token','1');
INSERT INTO `glpi_configs` VALUES ('170','core','url_base_api','http://localhost/glpi/apirest.php/');
INSERT INTO `glpi_configs` VALUES ('171','core','_no_history','');
INSERT INTO `glpi_configs` VALUES ('172','core','_matrix','1');
INSERT INTO `glpi_configs` VALUES ('173','core','_impact_5','1');
INSERT INTO `glpi_configs` VALUES ('174','core','_impact_4','1');
INSERT INTO `glpi_configs` VALUES ('175','core','_impact_3','1');
INSERT INTO `glpi_configs` VALUES ('176','core','_impact_2','1');
INSERT INTO `glpi_configs` VALUES ('177','core','_impact_1','1');
INSERT INTO `glpi_configs` VALUES ('178','core','_urgency_5','1');
INSERT INTO `glpi_configs` VALUES ('179','core','_matrix_5_5','5');
INSERT INTO `glpi_configs` VALUES ('180','core','_matrix_5_4','5');
INSERT INTO `glpi_configs` VALUES ('181','core','_matrix_5_3','4');
INSERT INTO `glpi_configs` VALUES ('182','core','_matrix_5_2','3');
INSERT INTO `glpi_configs` VALUES ('183','core','_matrix_5_1','2');
INSERT INTO `glpi_configs` VALUES ('184','core','_urgency_4','1');
INSERT INTO `glpi_configs` VALUES ('185','core','_matrix_4_5','5');
INSERT INTO `glpi_configs` VALUES ('186','core','_matrix_4_4','4');
INSERT INTO `glpi_configs` VALUES ('187','core','_matrix_4_3','4');
INSERT INTO `glpi_configs` VALUES ('188','core','_matrix_4_2','3');
INSERT INTO `glpi_configs` VALUES ('189','core','_matrix_4_1','2');
INSERT INTO `glpi_configs` VALUES ('190','core','_urgency_3','1');
INSERT INTO `glpi_configs` VALUES ('191','core','_matrix_3_5','4');
INSERT INTO `glpi_configs` VALUES ('192','core','_matrix_3_4','4');
INSERT INTO `glpi_configs` VALUES ('193','core','_matrix_3_3','3');
INSERT INTO `glpi_configs` VALUES ('194','core','_matrix_3_2','2');
INSERT INTO `glpi_configs` VALUES ('195','core','_matrix_3_1','2');
INSERT INTO `glpi_configs` VALUES ('196','core','_urgency_2','1');
INSERT INTO `glpi_configs` VALUES ('197','core','_matrix_2_5','3');
INSERT INTO `glpi_configs` VALUES ('198','core','_matrix_2_4','3');
INSERT INTO `glpi_configs` VALUES ('199','core','_matrix_2_3','2');
INSERT INTO `glpi_configs` VALUES ('200','core','_matrix_2_2','2');
INSERT INTO `glpi_configs` VALUES ('201','core','_matrix_2_1','1');
INSERT INTO `glpi_configs` VALUES ('202','core','_urgency_1','1');
INSERT INTO `glpi_configs` VALUES ('203','core','_matrix_1_5','2');
INSERT INTO `glpi_configs` VALUES ('204','core','_matrix_1_4','2');
INSERT INTO `glpi_configs` VALUES ('205','core','_matrix_1_3','2');
INSERT INTO `glpi_configs` VALUES ('206','core','_matrix_1_2','1');
INSERT INTO `glpi_configs` VALUES ('207','core','_matrix_1_1','1');

### Dump table glpi_consumableitems

DROP TABLE IF EXISTS `glpi_consumableitems`;
CREATE TABLE `glpi_consumableitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `consumableitemtypes_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `alarm_threshold` int(11) NOT NULL DEFAULT '10',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `consumableitemtypes_id` (`consumableitemtypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `alarm_threshold` (`alarm_threshold`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumableitemtypes

DROP TABLE IF EXISTS `glpi_consumableitemtypes`;
CREATE TABLE `glpi_consumableitemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_consumables

DROP TABLE IF EXISTS `glpi_consumables`;
CREATE TABLE `glpi_consumables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `consumableitems_id` int(11) NOT NULL DEFAULT '0',
  `date_in` date DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_in` (`date_in`),
  KEY `date_out` (`date_out`),
  KEY `consumableitems_id` (`consumableitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts

DROP TABLE IF EXISTS `glpi_contacts`;
CREATE TABLE `glpi_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contacttypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `contacttypes_id` (`contacttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacts_suppliers

DROP TABLE IF EXISTS `glpi_contacts_suppliers`;
CREATE TABLE `glpi_contacts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contacts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contacts_id`),
  KEY `contacts_id` (`contacts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contacttypes

DROP TABLE IF EXISTS `glpi_contacttypes`;
CREATE TABLE `glpi_contacttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contractcosts

DROP TABLE IF EXISTS `glpi_contractcosts`;
CREATE TABLE `glpi_contractcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `contracts_id` (`contracts_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts

DROP TABLE IF EXISTS `glpi_contracts`;
CREATE TABLE `glpi_contracts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contracttypes_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` date DEFAULT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `notice` int(11) NOT NULL DEFAULT '0',
  `periodicity` int(11) NOT NULL DEFAULT '0',
  `billing` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `accounting_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `week_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `week_end_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `saturday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_saturday` tinyint(1) NOT NULL DEFAULT '0',
  `monday_begin_hour` time NOT NULL DEFAULT '00:00:00',
  `monday_end_hour` time NOT NULL DEFAULT '00:00:00',
  `use_monday` tinyint(1) NOT NULL DEFAULT '0',
  `max_links_allowed` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `renewal` int(11) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `begin_date` (`begin_date`),
  KEY `name` (`name`),
  KEY `contracttypes_id` (`contracttypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `use_monday` (`use_monday`),
  KEY `use_saturday` (`use_saturday`),
  KEY `alert` (`alert`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_items

DROP TABLE IF EXISTS `glpi_contracts_items`;
CREATE TABLE `glpi_contracts_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`contracts_id`,`itemtype`,`items_id`),
  KEY `FK_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracts_suppliers

DROP TABLE IF EXISTS `glpi_contracts_suppliers`;
CREATE TABLE `glpi_contracts_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `contracts_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`suppliers_id`,`contracts_id`),
  KEY `contracts_id` (`contracts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_contracttypes

DROP TABLE IF EXISTS `glpi_contracttypes`;
CREATE TABLE `glpi_contracttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_crontasklogs

DROP TABLE IF EXISTS `glpi_crontasklogs`;
CREATE TABLE `glpi_crontasklogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crontasks_id` int(11) NOT NULL,
  `crontasklogs_id` int(11) NOT NULL COMMENT 'id of ''start'' event',
  `date` datetime NOT NULL,
  `state` int(11) NOT NULL COMMENT '0:start, 1:run, 2:stop',
  `elapsed` float NOT NULL COMMENT 'time elapsed since start',
  `volume` int(11) NOT NULL COMMENT 'for statistics',
  `content` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'message',
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `crontasks_id` (`crontasks_id`),
  KEY `crontasklogs_id_state` (`crontasklogs_id`,`state`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_crontasklogs` VALUES ('1','18','0','2017-06-29 12:16:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('2','18','1','2017-06-29 12:16:53','2','0.0360019','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('3','19','0','2017-06-29 12:19:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('4','19','3','2017-06-29 12:19:16','2','0.017','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('5','20','0','2017-06-29 12:19:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('6','20','5','2017-06-29 12:19:33','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('7','21','0','2017-06-29 12:19:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('8','21','7','2017-06-29 12:19:33','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('9','22','0','2017-06-29 12:21:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('10','22','9','2017-06-29 12:21:58','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('11','23','0','2017-06-29 12:27:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('12','23','11','2017-06-29 12:27:27','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('13','24','0','2017-06-29 12:35:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('14','24','13','2017-06-29 12:35:34','1','0.0156002','1','Limpiar 1 archivo temporal creado hace más de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('15','24','13','2017-06-29 12:35:34','2','0.0156002','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('16','25','0','2017-06-29 14:36:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('17','25','16','2017-06-29 14:36:50','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('18','5','0','2017-06-29 14:38:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('19','5','18','2017-06-29 14:38:21','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('20','6','0','2017-06-29 14:46:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('21','6','20','2017-06-29 14:46:07','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('22','8','0','2017-06-29 15:28:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('23','8','22','2017-06-29 15:28:49','2','0.858002','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('24','9','0','2017-06-29 15:30:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('25','9','24','2017-06-29 15:30:58','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('26','12','0','2017-06-29 21:31:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('27','12','26','2017-06-29 21:31:52','1','0.0156','5','Limpiar 5 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('28','12','26','2017-06-29 21:31:52','2','0.0156','5','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('29','13','0','2017-06-30 00:03:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('30','13','29','2017-06-30 00:03:52','1','0.0311999','1','Limpiar 1 archivo gráfico creado desde hace mas de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('31','13','29','2017-06-30 00:03:52','2','0.0311999','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('32','14','0','2017-06-30 00:09:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('33','14','32','2017-06-30 00:09:10','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('34','15','0','2017-06-30 00:12:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('35','15','34','2017-06-30 00:12:10','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('36','16','0','2017-06-30 00:12:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('37','16','36','2017-06-30 00:12:57','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('38','17','0','2017-06-30 00:13:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('39','17','38','2017-06-30 00:13:41','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('40','22','0','2017-06-30 00:13:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('41','22','40','2017-06-30 00:13:50','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('42','21','0','2017-06-30 00:14:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('43','21','42','2017-06-30 00:14:01','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('44','20','0','2017-06-30 00:23:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('45','20','44','2017-06-30 00:23:12','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('46','24','0','2017-06-30 00:28:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('47','24','46','2017-06-30 00:28:53','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('48','9','0','2017-06-30 00:29:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('49','9','48','2017-06-30 00:29:30','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('50','22','0','2017-06-30 10:23:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('51','22','50','2017-06-30 10:23:49','2','0.0468009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('52','17','0','2017-06-30 10:24:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('53','17','52','2017-06-30 10:24:04','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('54','21','0','2017-06-30 10:53:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('55','21','54','2017-06-30 10:53:57','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('56','9','0','2017-06-30 10:59:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('57','9','56','2017-06-30 10:59:34','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('58','13','0','2017-06-30 11:01:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('59','13','58','2017-06-30 11:01:58','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('60','14','0','2017-06-30 11:03:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('61','14','60','2017-06-30 11:03:01','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('62','20','0','2017-06-30 11:08:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('63','20','62','2017-06-30 11:08:44','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('64','24','0','2017-06-30 11:17:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('65','24','64','2017-06-30 11:17:27','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('66','22','0','2017-06-30 11:23:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('67','22','66','2017-06-30 11:23:06','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('68','17','0','2017-06-30 12:10:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('69','17','68','2017-06-30 12:10:41','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('70','21','0','2017-06-30 12:10:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('71','21','70','2017-06-30 12:10:59','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('72','9','0','2017-06-30 12:11:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('73','9','72','2017-06-30 12:11:11','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('74','22','0','2017-06-30 12:11:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('75','22','74','2017-06-30 12:11:26','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('76','13','0','2017-06-30 12:11:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('77','13','76','2017-06-30 12:11:37','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('78','14','0','2017-06-30 12:11:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('79','14','78','2017-06-30 12:11:57','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('80','20','0','2017-07-10 09:50:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('81','20','80','2017-07-10 09:50:22','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('82','15','0','2017-07-10 09:50:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('83','15','82','2017-07-10 09:50:24','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('84','16','0','2017-07-10 09:50:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('85','16','84','2017-07-10 09:50:24','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('86','22','0','2017-07-10 09:50:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('87','22','86','2017-07-10 09:50:37','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('88','17','0','2017-07-10 09:50:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('89','17','88','2017-07-10 09:50:47','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('90','21','0','2017-07-10 09:51:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('91','21','90','2017-07-10 09:51:20','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('92','18','0','2017-07-10 09:56:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('93','18','92','2017-07-10 09:56:31','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('94','24','0','2017-07-10 09:56:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('95','24','94','2017-07-10 09:56:41','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('96','19','0','2017-07-10 09:57:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('97','19','96','2017-07-10 09:57:21','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('98','9','0','2017-07-10 09:59:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('99','9','98','2017-07-10 09:59:08','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('100','23','0','2017-07-10 09:59:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('101','23','100','2017-07-10 09:59:38','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('102','13','0','2017-07-10 09:59:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('103','13','102','2017-07-10 09:59:58','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('104','14','0','2017-07-10 10:05:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('105','14','104','2017-07-10 10:05:05','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('106','25','0','2017-07-10 10:08:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('107','25','106','2017-07-10 10:08:03','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('108','5','0','2017-07-10 10:10:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('109','5','108','2017-07-10 10:10:12','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('110','6','0','2017-07-10 10:10:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('111','6','110','2017-07-10 10:10:33','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('112','12','0','2017-07-10 10:11:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('113','12','112','2017-07-10 10:11:32','1','0.0156','18','Limpiar 18 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('114','12','112','2017-07-10 10:11:32','2','0.0311999','18','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('115','8','0','2017-07-10 10:12:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('116','8','115','2017-07-10 10:12:22','2','0.2496','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('117','22','0','2017-07-10 10:15:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('118','22','117','2017-07-10 10:15:22','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('119','17','0','2017-07-10 10:17:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('120','17','119','2017-07-10 10:17:09','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('121','21','0','2017-07-10 10:18:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('122','21','121','2017-07-10 10:18:51','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('123','9','0','2017-07-10 10:21:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('124','9','123','2017-07-10 10:21:08','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('125','22','0','2017-07-10 10:22:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('126','22','125','2017-07-10 10:22:13','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('127','17','0','2017-07-10 14:53:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('128','17','127','2017-07-10 14:53:45','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('129','21','0','2017-07-11 09:33:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('130','21','129','2017-07-11 09:33:34','2','0.148401','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('131','22','0','2017-07-11 09:39:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('132','22','131','2017-07-11 09:39:20','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('133','9','0','2017-07-11 10:02:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('134','9','133','2017-07-11 10:02:51','2','0.328601','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('135','20','0','2017-07-11 10:08:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('136','20','135','2017-07-11 10:08:02','2','0.2496','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('137','24','0','2017-07-11 10:30:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('138','24','137','2017-07-11 10:30:41','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('139','13','0','2017-07-11 10:35:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('140','13','139','2017-07-11 10:35:45','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('141','14','0','2017-07-11 10:36:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('142','14','141','2017-07-11 10:36:07','2','0.0270009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('143','17','0','2017-07-11 14:33:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('144','17','143','2017-07-11 14:33:18','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('145','15','0','2017-07-11 14:40:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('146','15','145','2017-07-11 14:40:26','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('147','16','0','2017-07-12 10:22:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('148','16','147','2017-07-12 10:22:27','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('149','21','0','2017-07-12 10:22:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('150','21','149','2017-07-12 10:22:28','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('151','22','0','2017-07-12 10:22:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('152','22','151','2017-07-12 10:22:42','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('153','18','0','2017-07-12 10:22:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('154','18','153','2017-07-12 10:22:51','2','0.2184','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('155','19','0','2017-07-12 10:23:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('156','19','155','2017-07-12 10:23:07','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('157','23','0','2017-07-12 10:23:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('158','23','157','2017-07-12 10:23:25','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('159','25','0','2017-07-12 10:32:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('160','25','159','2017-07-12 10:32:34','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('161','5','0','2017-07-12 10:41:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('162','5','161','2017-07-12 10:41:13','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('163','6','0','2017-07-12 10:46:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('164','6','163','2017-07-12 10:46:21','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('165','12','0','2017-07-12 10:47:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('166','12','165','2017-07-12 10:47:30','1','0.0156','1','Limpiar 1 archivo de sesión creado hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('167','12','165','2017-07-12 10:47:30','2','0.0156','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('168','9','0','2017-07-12 10:51:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('169','9','168','2017-07-12 10:51:38','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('170','20','0','2017-07-12 10:58:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('171','20','170','2017-07-12 10:58:03','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('172','24','0','2017-07-12 11:00:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('173','24','172','2017-07-12 11:00:34','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('174','13','0','2017-07-12 11:04:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('175','13','174','2017-07-12 11:04:31','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('176','14','0','2017-07-12 11:09:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('177','14','176','2017-07-12 11:09:33','2','0.0312009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('178','17','0','2017-07-12 11:23:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('179','17','178','2017-07-12 11:23:26','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('180','15','0','2017-07-12 11:28:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('181','15','180','2017-07-12 11:28:29','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('182','22','0','2017-07-12 11:29:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('183','22','182','2017-07-12 11:29:53','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('184','21','0','2017-07-12 11:52:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('185','21','184','2017-07-12 11:52:32','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('186','9','0','2017-07-12 11:52:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('187','9','186','2017-07-12 11:52:36','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('188','17','0','2017-07-12 11:52:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('189','17','188','2017-07-12 11:52:39','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('190','22','0','2017-07-12 11:58:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('191','22','190','2017-07-12 11:58:40','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('192','17','0','2017-07-12 11:58:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('193','17','192','2017-07-12 11:58:42','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('194','21','0','2017-07-12 11:59:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('195','21','194','2017-07-12 11:59:03','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('196','20','0','2017-07-12 11:59:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('197','20','196','2017-07-12 11:59:44','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('198','22','0','2017-07-12 12:00:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('199','22','198','2017-07-12 12:00:50','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('200','24','0','2017-07-12 12:01:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('201','24','200','2017-07-12 12:01:31','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('202','22','0','2017-07-12 12:02:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('203','22','202','2017-07-12 12:02:28','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('204','9','0','2017-07-12 12:02:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('205','9','204','2017-07-12 12:02:29','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('206','17','0','2017-07-12 12:03:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('207','17','206','2017-07-12 12:03:17','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('208','22','0','2017-07-12 12:03:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('209','22','208','2017-07-12 12:03:19','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('210','13','0','2017-07-12 12:06:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('211','13','210','2017-07-12 12:06:48','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('212','21','0','2017-07-13 09:36:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('213','21','212','2017-07-13 09:36:27','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('214','22','0','2017-07-13 10:16:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('215','22','214','2017-07-13 10:16:10','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('216','17','0','2017-07-13 10:51:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('217','17','216','2017-07-13 10:51:36','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('218','14','0','2017-07-13 10:51:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('219','14','218','2017-07-13 10:51:38','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('220','9','0','2017-07-13 10:51:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('221','9','220','2017-07-13 10:51:56','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('222','20','0','2017-07-13 10:52:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('223','20','222','2017-07-13 10:52:25','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('224','24','0','2017-07-13 10:52:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('225','24','224','2017-07-13 10:52:28','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('226','13','0','2017-07-13 10:52:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('227','13','226','2017-07-13 10:52:43','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('228','16','0','2017-07-13 10:53:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('229','16','228','2017-07-13 10:53:05','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('230','15','0','2017-07-13 10:53:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('231','15','230','2017-07-13 10:53:25','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('232','21','0','2017-07-13 10:56:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('233','21','232','2017-07-13 10:56:18','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('234','22','0','2017-07-13 10:56:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('235','22','234','2017-07-13 10:56:31','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('236','18','0','2017-07-13 10:57:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('237','18','236','2017-07-13 10:57:14','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('238','19','0','2017-07-13 10:57:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('239','19','238','2017-07-13 10:57:37','2','0.0468001','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('240','23','0','2017-07-13 15:58:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('241','23','240','2017-07-13 15:58:57','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('242','25','0','2017-07-13 15:59:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('243','25','242','2017-07-13 15:59:38','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('244','5','0','2017-07-13 15:59:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('245','5','244','2017-07-13 15:59:48','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('246','6','0','2017-07-13 15:59:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('247','6','246','2017-07-13 15:59:55','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('248','12','0','2017-07-13 16:03:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('249','12','248','2017-07-13 16:03:12','1','0.0156','6','Limpiar 6 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('250','12','248','2017-07-13 16:03:12','2','0.0156','6','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('251','17','0','2017-07-13 16:03:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('252','17','251','2017-07-13 16:03:19','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('253','22','0','2017-07-13 16:03:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('254','22','253','2017-07-13 16:03:31','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('255','9','0','2017-07-13 16:03:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('256','9','255','2017-07-13 16:03:59','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('257','21','0','2017-07-13 16:06:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('258','21','257','2017-07-13 16:06:47','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('259','14','0','2017-07-13 16:09:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('260','14','259','2017-07-13 16:09:11','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('261','13','0','2017-07-14 13:33:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('262','13','261','2017-07-14 13:33:43','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('263','20','0','2017-07-14 13:33:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('264','20','263','2017-07-14 13:33:50','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('265','24','0','2017-07-14 13:41:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('266','24','265','2017-07-14 13:41:27','2','0.343201','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('267','22','0','2017-07-14 13:42:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('268','22','267','2017-07-14 13:42:19','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('269','17','0','2017-07-18 09:37:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('270','17','269','2017-07-18 09:37:23','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('271','21','0','2017-07-18 09:37:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('272','21','271','2017-07-18 09:37:24','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('273','9','0','2017-07-18 09:37:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('274','9','273','2017-07-18 09:37:34','2','0.1092','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('275','14','0','2017-07-18 09:42:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('276','14','275','2017-07-18 09:42:54','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('277','15','0','2017-07-18 09:48:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('278','15','277','2017-07-18 09:48:00','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('279','16','0','2017-07-18 09:53:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('280','16','279','2017-07-18 09:53:16','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('281','18','0','2017-07-18 09:56:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('282','18','281','2017-07-18 09:56:28','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('283','19','0','2017-07-25 15:20:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('284','19','283','2017-07-25 15:20:21','2','0.0780001','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('285','22','0','2017-07-25 15:20:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('286','22','285','2017-07-25 15:20:21','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('287','13','0','2017-07-25 15:20:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('288','13','287','2017-07-25 15:20:46','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('289','20','0','2017-07-25 15:21:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('290','20','289','2017-07-25 15:21:03','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('291','24','0','2017-07-25 15:26:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('292','24','291','2017-07-25 15:26:33','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('293','23','0','2017-07-25 15:31:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('294','23','293','2017-07-25 15:31:46','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('295','5','0','2017-07-25 15:58:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('296','5','295','2017-07-25 15:58:45','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('297','6','0','2017-07-25 16:10:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('298','6','297','2017-07-25 16:10:09','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('299','25','0','2017-07-25 17:44:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('300','25','299','2017-07-25 17:44:53','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('301','12','0','2017-07-25 17:54:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('302','12','301','2017-07-25 17:54:54','1','0.0312011','11','Limpiar 11 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('303','12','301','2017-07-25 17:54:54','2','0.0312011','11','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('304','8','0','2017-07-25 17:59:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('305','8','304','2017-07-25 17:59:58','2','0.374401','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('306','17','0','2017-07-25 18:03:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('307','17','306','2017-07-25 18:03:26','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('308','21','0','2017-07-25 18:03:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('309','21','308','2017-07-25 18:03:47','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('310','9','0','2017-07-25 18:03:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('311','9','310','2017-07-25 18:03:58','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('312','14','0','2017-07-25 18:04:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('313','14','312','2017-07-25 18:04:32','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('314','15','0','2017-07-25 18:06:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('315','15','314','2017-07-25 18:06:59','2','0.1248','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('316','16','0','2017-07-25 18:08:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('317','16','316','2017-07-25 18:08:02','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('318','18','0','2017-07-25 18:08:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('319','18','318','2017-07-25 18:08:16','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('320','22','0','2017-07-25 18:08:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('321','22','320','2017-07-25 18:08:58','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('322','13','0','2017-07-25 18:09:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('323','13','322','2017-07-25 18:09:55','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('324','20','0','2017-07-25 18:11:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('325','20','324','2017-07-25 18:11:11','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('326','24','0','2017-07-25 18:12:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('327','24','326','2017-07-25 18:12:09','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('328','17','0','2017-07-25 18:17:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('329','17','328','2017-07-25 18:17:39','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('330','21','0','2017-07-25 18:22:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('331','21','330','2017-07-25 18:22:48','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('332','22','0','2017-07-25 22:09:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('333','22','332','2017-07-25 22:09:17','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('334','9','0','2017-07-25 22:09:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('335','9','334','2017-07-25 22:09:33','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('336','17','0','2017-07-25 22:15:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('337','17','336','2017-07-25 22:15:37','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('338','21','0','2017-07-25 22:18:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('339','21','338','2017-07-25 22:18:43','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('340','14','0','2017-07-25 22:32:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('341','14','340','2017-07-25 22:32:36','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('342','13','0','2017-07-25 22:42:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('343','13','342','2017-07-25 22:42:56','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('344','20','0','2017-07-25 22:54:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('345','20','344','2017-07-25 22:54:08','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('346','24','0','2017-07-25 23:11:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('347','24','346','2017-07-25 23:11:51','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('348','22','0','2017-07-25 23:24:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('349','22','348','2017-07-25 23:24:17','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('350','9','0','2017-07-25 23:30:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('351','9','350','2017-07-25 23:30:15','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('352','17','0','2017-07-26 00:22:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('353','17','352','2017-07-26 00:22:21','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('354','21','0','2017-07-26 00:27:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('355','21','354','2017-07-26 00:27:42','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('356','22','0','2017-07-26 00:32:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('357','22','356','2017-07-26 00:32:53','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('358','14','0','2017-07-26 09:23:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('359','14','358','2017-07-26 09:23:12','2','0.0936','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('360','9','0','2017-07-26 09:23:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('361','9','360','2017-07-26 09:23:14','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('362','13','0','2017-07-26 09:28:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('363','13','362','2017-07-26 09:28:21','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('364','20','0','2017-07-26 09:28:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('365','20','364','2017-07-26 09:28:22','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('366','24','0','2017-07-26 09:34:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('367','24','366','2017-07-26 09:34:25','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('368','17','0','2017-07-26 09:41:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('369','17','368','2017-07-26 09:41:56','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('370','21','0','2017-07-26 09:48:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('371','21','370','2017-07-26 09:48:23','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('372','22','0','2017-07-26 09:54:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('373','22','372','2017-07-26 09:54:08','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('374','15','0','2017-07-26 09:58:45','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('375','15','374','2017-07-26 09:58:45','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('376','16','0','2017-07-26 09:59:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('377','16','376','2017-07-26 09:59:03','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('378','9','0','2017-07-26 09:59:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('379','9','378','2017-07-26 09:59:06','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('380','17','0','2017-07-26 09:59:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('381','17','380','2017-07-26 09:59:36','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('382','21','0','2017-07-26 09:59:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('383','21','382','2017-07-26 09:59:56','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('384','22','0','2017-07-26 10:00:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('385','22','384','2017-07-26 10:00:53','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('386','22','0','2017-07-26 10:01:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('387','22','386','2017-07-26 10:01:08','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('388','22','0','2017-07-26 10:07:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('389','22','388','2017-07-26 10:07:12','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('390','17','0','2017-07-26 10:12:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('391','17','390','2017-07-26 10:12:50','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('392','21','0','2017-07-26 10:18:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('393','21','392','2017-07-26 10:18:26','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('394','22','0','2017-07-26 10:23:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('395','22','394','2017-07-26 10:23:30','2','0.0156009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('396','9','0','2017-07-26 10:31:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('397','9','396','2017-07-26 10:31:42','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('398','17','0','2017-07-26 10:38:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('399','17','398','2017-07-26 10:38:24','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('400','14','0','2017-07-26 10:43:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('401','14','400','2017-07-26 10:43:46','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('402','21','0','2017-07-26 10:49:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('403','21','402','2017-07-26 10:49:17','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('404','22','0','2017-07-26 10:52:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('405','22','404','2017-07-26 10:52:18','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('406','13','0','2017-07-27 10:18:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('407','13','406','2017-07-27 10:18:50','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('408','20','0','2017-07-27 10:19:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('409','20','408','2017-07-27 10:19:03','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('410','24','0','2017-07-27 10:19:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('411','24','410','2017-07-27 10:19:20','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('412','9','0','2017-07-27 10:19:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('413','9','412','2017-07-27 10:19:31','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('414','17','0','2017-07-27 10:19:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('415','17','414','2017-07-27 10:19:57','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('416','22','0','2017-07-27 10:29:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('417','22','416','2017-07-27 10:29:46','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('418','21','0','2017-07-27 10:30:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('419','21','418','2017-07-27 10:30:16','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('420','14','0','2017-07-27 10:53:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('421','14','420','2017-07-27 10:53:00','2','0.0312009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('422','19','0','2017-07-27 11:24:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('423','19','422','2017-07-27 11:24:26','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('424','23','0','2017-07-27 11:29:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('425','23','424','2017-07-27 11:29:35','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('426','5','0','2017-07-27 11:34:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('427','5','426','2017-07-27 11:34:37','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('428','6','0','2017-07-27 11:35:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('429','6','428','2017-07-27 11:35:55','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('430','25','0','2017-07-27 11:36:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('431','25','430','2017-07-27 11:36:42','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('432','12','0','2017-08-10 10:11:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('433','12','432','2017-08-10 10:11:13','1','0.0780001','23','Limpiar 23 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('434','12','432','2017-08-10 10:11:13','2','0.0936','23','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('435','18','0','2017-08-10 10:11:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('436','18','435','2017-08-10 10:11:41','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('437','15','0','2017-08-10 10:12:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('438','15','437','2017-08-10 10:12:35','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('439','16','0','2017-08-10 10:14:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('440','16','439','2017-08-10 10:14:29','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('441','17','0','2017-08-10 10:36:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('442','17','441','2017-08-10 10:36:42','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('443','9','0','2017-08-10 10:38:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('444','9','443','2017-08-10 10:38:36','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('445','22','0','2017-08-10 10:44:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('446','22','445','2017-08-10 10:44:00','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('447','21','0','2017-08-10 10:49:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('448','21','447','2017-08-10 10:49:40','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('449','13','0','2017-08-10 10:55:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('450','13','449','2017-08-10 10:55:00','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('451','20','0','2017-08-10 11:00:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('452','20','451','2017-08-10 11:00:05','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('453','24','0','2017-08-10 11:05:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('454','24','453','2017-08-10 11:05:28','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('455','14','0','2017-08-10 11:12:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('456','14','455','2017-08-10 11:12:58','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('457','19','0','2017-08-10 11:23:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('458','19','457','2017-08-10 11:23:48','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('459','23','0','2017-08-10 11:25:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('460','23','459','2017-08-10 11:25:11','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('461','5','0','2017-08-10 11:28:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('462','5','461','2017-08-10 11:28:49','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('463','6','0','2017-08-10 11:48:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('464','6','463','2017-08-10 11:48:55','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('465','25','0','2017-08-15 22:39:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('466','25','465','2017-08-15 22:39:21','2','0.0779998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('467','8','0','2017-08-15 22:39:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('468','8','467','2017-08-15 22:39:56','2','0.592801','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('469','17','0','2017-08-15 22:40:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('470','17','469','2017-08-15 22:40:34','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('471','22','0','2017-08-15 22:40:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('472','22','471','2017-08-15 22:40:49','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('473','9','0','2017-08-15 22:43:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('474','9','473','2017-08-15 22:43:32','2','0.0779998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('475','21','0','2017-08-15 22:45:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('476','21','475','2017-08-15 22:45:00','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('477','13','0','2017-08-15 22:45:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('478','13','477','2017-08-15 22:45:15','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('479','20','0','2017-08-15 22:45:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('480','20','479','2017-08-15 22:45:26','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('481','24','0','2017-08-15 22:45:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('482','24','481','2017-08-15 22:45:43','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('483','14','0','2017-08-15 22:45:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('484','14','483','2017-08-15 22:45:58','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('485','15','0','2017-08-15 22:51:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('486','15','485','2017-08-15 22:51:52','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('487','16','0','2017-08-15 22:56:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('488','16','487','2017-08-15 22:56:34','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('489','12','0','2017-08-15 22:57:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('490','12','489','2017-08-15 22:57:25','1','0.0156002','5','Limpiar 5 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('491','12','489','2017-08-15 22:57:25','2','0.0156002','5','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('492','18','0','2017-08-15 23:03:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('493','18','492','2017-08-15 23:03:43','2','0.1092','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('494','19','0','2017-08-15 23:07:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('495','19','494','2017-08-15 23:07:44','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('496','23','0','2017-08-15 23:07:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('497','23','496','2017-08-15 23:07:52','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('498','5','0','2017-08-15 23:08:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('499','5','498','2017-08-15 23:08:51','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('500','6','0','2017-08-15 23:14:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('501','6','500','2017-08-15 23:14:08','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('502','22','0','2017-08-15 23:22:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('503','22','502','2017-08-15 23:22:43','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('504','17','0','2017-08-15 23:57:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('505','17','504','2017-08-15 23:57:13','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('506','21','0','2017-08-15 23:58:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('507','21','506','2017-08-15 23:58:06','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('508','9','0','2017-08-16 00:03:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('509','9','508','2017-08-16 00:03:13','2','1.8096','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('510','22','0','2017-08-16 00:04:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('511','22','510','2017-08-16 00:04:33','2','2.5428','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('512','13','0','2017-08-16 08:15:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('513','13','512','2017-08-16 08:15:41','2','0.0779998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('514','14','0','2017-08-16 08:15:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('515','14','514','2017-08-16 08:15:49','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('516','20','0','2017-08-17 09:47:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('517','20','516','2017-08-17 09:47:03','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('518','24','0','2017-08-17 11:23:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('519','24','518','2017-08-17 11:23:40','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('520','17','0','2017-08-17 11:29:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('521','17','520','2017-08-17 11:29:22','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('522','21','0','2017-08-17 11:30:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('523','21','522','2017-08-17 11:30:09','2','0.0779998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('524','22','0','2017-08-18 10:48:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('525','22','524','2017-08-18 10:48:18','2','0.717601','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('526','9','0','2017-08-18 10:48:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('527','9','526','2017-08-18 10:48:20','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('528','13','0','2017-08-18 10:52:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('529','13','528','2017-08-18 10:52:36','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('530','14','0','2017-08-18 10:54:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('531','14','530','2017-08-18 10:54:28','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('532','15','0','2017-08-18 10:56:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('533','15','532','2017-08-18 10:56:32','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('534','16','0','2017-08-18 11:06:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('535','16','534','2017-08-18 11:06:53','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('536','25','0','2017-08-18 11:07:00','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('537','25','536','2017-08-18 11:07:00','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('538','12','0','2017-08-18 11:07:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('539','12','538','2017-08-18 11:07:03','1','0.0156','10','Limpiar 10 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('540','12','538','2017-08-18 11:07:03','2','0.0156','10','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('541','18','0','2017-08-18 11:08:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('542','18','541','2017-08-18 11:08:30','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('543','19','0','2017-08-18 11:08:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('544','19','543','2017-08-18 11:08:31','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('545','23','0','2017-08-18 11:09:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('546','23','545','2017-08-18 11:09:09','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('547','5','0','2017-08-18 11:09:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('548','5','547','2017-08-18 11:09:10','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('549','6','0','2017-08-18 11:09:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('550','6','549','2017-08-18 11:09:34','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('551','20','0','2017-08-18 11:12:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('552','20','551','2017-08-18 11:12:29','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('553','17','0','2017-08-18 11:13:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('554','17','553','2017-08-18 11:13:41','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('555','21','0','2017-08-18 11:14:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('556','21','555','2017-08-18 11:14:10','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('557','24','0','2017-08-18 11:14:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('558','24','557','2017-08-18 11:14:12','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('559','22','0','2017-08-18 11:15:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('560','22','559','2017-08-18 11:15:46','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('561','9','0','2017-08-18 12:55:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('562','9','561','2017-08-18 12:55:48','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('563','22','0','2017-08-18 13:00:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('564','22','563','2017-08-18 13:00:50','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('565','17','0','2017-08-18 13:03:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('566','17','565','2017-08-18 13:03:14','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('567','21','0','2017-08-18 13:03:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('568','21','567','2017-08-18 13:03:40','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('569','13','0','2017-08-18 13:06:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('570','13','569','2017-08-18 13:06:31','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('571','14','0','2017-08-18 13:06:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('572','14','571','2017-08-18 13:06:59','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('573','20','0','2017-08-18 13:12:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('574','20','573','2017-08-18 13:12:24','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('575','24','0','2017-08-18 13:24:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('576','24','575','2017-08-18 13:24:16','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('577','22','0','2017-08-22 14:23:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('578','22','577','2017-08-22 14:23:44','2','0.0312009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('579','9','0','2017-08-23 03:54:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('580','9','579','2017-08-23 03:54:25','2','0.202801','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('581','17','0','2017-09-21 15:57:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('582','17','581','2017-09-21 15:57:02','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('583','21','0','2017-09-30 10:15:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('584','21','583','2017-09-30 10:15:41','2','0.2496','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('585','13','0','2017-10-02 14:16:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('586','13','585','2017-10-02 14:16:44','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('587','14','0','2017-11-02 15:09:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('588','14','587','2017-11-02 15:09:26','2','0.0880048','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('589','20','0','2017-11-02 15:09:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('590','20','589','2017-11-02 15:09:39','2','0.016001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('591','24','0','2017-11-02 15:13:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('592','24','591','2017-11-02 15:13:13','2','0.026001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('593','15','0','2017-11-02 15:13:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('594','15','593','2017-11-02 15:13:32','2','0.025001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('595','16','0','2017-11-02 15:13:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('596','16','595','2017-11-02 15:13:40','2','0.0250008','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('597','12','0','2017-11-02 15:29:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('598','12','597','2017-11-02 15:29:12','1','0.0780001','27','Limpiar 27 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('599','12','597','2017-11-02 15:29:12','2','0.0780001','27','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('600','25','0','2017-11-02 15:35:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('601','25','600','2017-11-02 15:35:08','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('602','18','0','2017-11-02 15:46:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('603','18','602','2017-11-02 15:46:32','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('604','19','0','2017-11-02 15:46:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('605','19','604','2017-11-02 15:46:54','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('606','5','0','2017-11-03 10:28:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('607','5','606','2017-11-03 10:28:07','2','4.78921','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('608','6','0','2017-11-03 11:25:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('609','6','608','2017-11-03 11:25:22','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('610','23','0','2017-11-03 11:26:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('611','23','610','2017-11-03 11:26:32','2','0.0156','16','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('612','22','0','2017-11-03 11:27:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('613','22','612','2017-11-03 11:27:05','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('614','8','0','2017-11-03 11:28:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('615','8','614','2017-11-03 11:28:53','2','0.624001','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('616','9','0','2017-11-03 11:31:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('617','9','616','2017-11-03 11:31:22','2','0.0935998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('618','17','0','2017-11-03 11:55:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('619','17','618','2017-11-03 11:55:57','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('620','21','0','2017-11-07 15:37:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('621','21','620','2017-11-07 15:37:34','2','0.0720041','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('622','13','0','2017-11-07 15:39:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('623','13','622','2017-11-07 15:39:03','2','0.0150011','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('624','14','0','2017-11-07 15:41:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('625','14','624','2017-11-07 15:41:35','2','0.022001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('626','20','0','2017-11-07 15:42:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('627','20','626','2017-11-07 15:42:59','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('628','24','0','2017-11-07 15:49:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('629','24','628','2017-11-07 15:49:58','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('630','15','0','2017-11-07 15:53:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('631','15','630','2017-11-07 15:53:10','2','0.0260019','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('632','16','0','2017-11-07 15:54:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('633','16','632','2017-11-07 15:54:48','2','0.0240011','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('634','22','0','2017-11-07 15:54:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('635','22','634','2017-11-07 15:54:54','2','0.032002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('636','9','0','2017-11-07 15:59:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('637','9','636','2017-11-07 15:59:14','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('638','17','0','2017-11-07 16:00:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('639','17','638','2017-11-07 16:00:40','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('640','12','0','2017-11-07 16:02:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('641','12','640','2017-11-07 16:02:26','1','0.0156','7','Limpiar 7 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('642','12','640','2017-11-07 16:02:26','2','0.0156','7','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('643','25','0','2017-11-07 16:03:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('644','25','643','2017-11-07 16:03:52','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('645','18','0','2017-11-07 16:05:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('646','18','645','2017-11-07 16:05:11','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('647','19','0','2017-11-07 16:06:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('648','19','647','2017-11-07 16:06:24','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('649','5','0','2017-11-07 16:08:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('650','5','649','2017-11-07 16:08:27','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('651','6','0','2017-11-07 16:14:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('652','6','651','2017-11-07 16:14:08','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('653','23','0','2017-11-07 16:14:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('654','23','653','2017-11-07 16:14:34','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('655','21','0','2017-11-07 16:15:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('656','21','655','2017-11-07 16:15:37','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('657','22','0','2017-11-07 16:59:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('658','22','657','2017-11-07 16:59:40','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('659','17','0','2017-11-07 17:04:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('660','17','659','2017-11-07 17:04:47','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('661','9','0','2017-11-08 09:48:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('662','9','661','2017-11-08 09:48:47','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('663','21','0','2017-11-08 09:48:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('664','21','663','2017-11-08 09:48:48','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('665','13','0','2017-11-08 09:48:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('666','13','665','2017-11-08 09:48:49','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('667','14','0','2017-11-08 10:05:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('668','14','667','2017-11-08 10:05:23','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('669','20','0','2017-11-08 10:11:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('670','20','669','2017-11-08 10:11:01','2','0.013001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('671','24','0','2017-11-08 10:11:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('672','24','671','2017-11-08 10:11:29','2','0.0180011','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('673','22','0','2017-11-08 10:32:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('674','22','673','2017-11-08 10:32:34','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('675','17','0','2017-11-08 18:03:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('676','17','675','2017-11-08 18:03:20','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('677','15','0','2017-11-08 18:03:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('678','15','677','2017-11-08 18:03:24','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('679','16','0','2017-11-08 22:36:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('680','16','679','2017-11-08 22:36:37','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('681','21','0','2017-11-08 22:37:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('682','21','681','2017-11-08 22:37:02','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('683','9','0','2017-11-08 23:33:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('684','9','683','2017-11-08 23:33:32','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('685','22','0','2017-11-09 00:09:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('686','22','685','2017-11-09 00:09:39','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('687','13','0','2017-11-10 00:03:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('688','13','687','2017-11-10 00:03:12','2','0.073004','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('689','14','0','2017-11-12 10:21:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('690','14','689','2017-11-12 10:21:12','2','0.1404','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('691','20','0','2017-11-14 10:19:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('692','20','691','2017-11-14 10:19:22','2','0.0936','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('693','24','0','2017-11-14 10:19:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('694','24','693','2017-11-14 10:19:39','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('695','12','0','2017-11-14 10:19:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('696','12','695','2017-11-14 10:19:55','1','0.0624001','30','Limpiar 30 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('697','12','695','2017-11-14 10:19:55','2','0.0624001','30','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('698','25','0','2017-11-14 10:24:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('699','25','698','2017-11-14 10:24:18','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('700','18','0','2017-11-14 10:37:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('701','18','700','2017-11-14 10:37:58','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('702','19','0','2017-11-14 10:41:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('703','19','702','2017-11-14 10:41:22','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('704','5','0','2017-11-14 12:01:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('705','5','704','2017-11-14 12:01:51','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('706','6','0','2017-11-14 12:12:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('707','6','706','2017-11-14 12:12:43','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('708','23','0','2017-11-14 14:26:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('709','23','708','2017-11-14 14:26:24','2','0.0936','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('710','17','0','2017-11-14 15:45:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('711','17','710','2017-11-14 15:45:57','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('712','21','0','2017-11-14 15:58:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('713','21','712','2017-11-14 15:58:06','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('714','9','0','2017-11-14 16:04:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('715','9','714','2017-11-14 16:04:29','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('716','22','0','2017-11-15 10:09:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('717','22','716','2017-11-15 10:09:25','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('718','15','0','2017-11-15 10:37:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('719','15','718','2017-11-15 10:37:21','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('720','16','0','2017-11-16 14:56:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('721','16','720','2017-11-16 14:56:28','2','0.140401','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('722','13','0','2017-11-16 15:01:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('723','13','722','2017-11-16 15:01:50','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('724','8','0','2017-11-16 16:14:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('725','8','724','2017-11-16 16:14:16','2','0.717602','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('726','14','0','2017-11-16 16:46:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('727','14','726','2017-11-16 16:46:11','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('728','20','0','2017-11-16 16:52:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('729','20','728','2017-11-16 16:52:01','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('730','24','0','2017-11-18 13:59:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('731','24','730','2017-11-18 13:59:49','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('732','17','0','2017-11-19 17:42:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('733','17','732','2017-11-19 17:42:32','2','0.343201','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('734','21','0','2017-11-19 18:52:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('735','21','734','2017-11-19 18:52:24','2','0.0936','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('736','9','0','2017-11-19 22:03:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('737','9','736','2017-11-19 22:03:19','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('738','22','0','2017-11-20 10:24:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('739','22','738','2017-11-20 10:24:48','2','0.1248','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('740','12','0','2017-11-20 13:19:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('741','12','740','2017-11-20 13:19:57','1','0.093601','22','Limpiar 22 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('742','12','740','2017-11-20 13:19:57','2','0.093601','22','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('743','25','0','2017-11-20 14:27:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('744','25','743','2017-11-20 14:27:01','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('745','18','0','2017-11-20 15:44:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('746','18','745','2017-11-20 15:44:09','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('747','19','0','2017-11-20 19:06:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('748','19','747','2017-11-20 19:06:28','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('749','5','0','2017-11-21 09:39:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('750','5','749','2017-11-21 09:39:57','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('751','6','0','2017-11-21 14:56:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('752','6','751','2017-11-21 14:56:59','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('753','23','0','2017-11-22 15:33:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('754','23','753','2017-11-22 15:33:38','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('755','15','0','2017-11-23 14:47:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('756','15','755','2017-11-23 14:47:26','2','0.1092','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('757','13','0','2017-11-23 15:47:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('758','13','757','2017-11-23 15:47:14','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('759','14','0','2017-11-23 16:24:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('760','14','759','2017-11-23 16:24:37','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('761','20','0','2017-11-24 14:35:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('762','20','761','2017-11-24 14:35:55','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('763','16','0','2017-11-24 14:41:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('764','16','763','2017-11-24 14:41:52','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('765','24','0','2017-11-24 18:16:58','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('766','24','765','2017-11-24 18:16:58','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('767','17','0','2017-11-28 10:57:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('768','17','767','2017-11-28 10:57:47','2','0.1248','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('769','21','0','2017-11-28 11:01:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('770','21','769','2017-11-28 11:01:57','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('771','9','0','2017-11-28 11:09:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('772','9','771','2017-11-28 11:09:18','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('773','22','0','2017-11-28 16:10:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('774','22','773','2017-11-28 16:10:52','2','0.117007','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('775','12','0','2017-11-29 14:13:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('776','12','775','2017-11-29 14:13:21','1','0.0623999','21','Limpiar 21 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('777','12','775','2017-11-29 14:13:21','2','0.0623999','21','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('778','25','0','2017-11-29 14:30:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('779','25','778','2017-11-29 14:30:13','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('780','18','0','2017-12-05 10:25:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('781','18','780','2017-12-05 10:25:10','2','0.1248','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('782','19','0','2017-12-05 10:42:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('783','19','782','2017-12-05 10:42:11','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('784','5','0','2017-12-05 13:48:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('785','5','784','2017-12-05 13:48:38','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('786','6','0','2017-12-05 13:50:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('787','6','786','2017-12-05 13:50:59','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('788','23','0','2017-12-05 17:42:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('789','23','788','2017-12-05 17:42:24','2','0.0156','4','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('790','8','0','2017-12-06 13:56:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('791','8','790','2017-12-06 13:56:48','2','4.33681','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('792','13','0','2017-12-06 14:09:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('793','13','792','2017-12-06 14:09:12','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('794','14','0','2017-12-06 14:11:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('795','14','794','2017-12-06 14:11:07','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('796','15','0','2017-12-06 14:17:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('797','15','796','2017-12-06 14:17:13','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('798','20','0','2017-12-06 14:18:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('799','20','798','2017-12-06 14:18:30','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('800','24','0','2017-12-06 14:24:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('801','24','800','2017-12-06 14:24:38','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('802','16','0','2017-12-06 14:30:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('803','16','802','2017-12-06 14:30:23','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('804','17','0','2017-12-06 14:35:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('805','17','804','2017-12-06 14:35:44','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('806','21','0','2017-12-06 14:41:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('807','21','806','2017-12-06 14:41:03','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('808','9','0','2017-12-06 14:47:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('809','9','808','2017-12-06 14:47:29','2','0.1248','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('810','22','0','2017-12-06 15:02:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('811','22','810','2017-12-06 15:02:32','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('812','12','0','2017-12-06 15:03:01','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('813','12','812','2017-12-06 15:03:01','1','0.0156','3','Limpiar 3 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('814','12','812','2017-12-06 15:03:01','2','0.0156','3','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('815','25','0','2017-12-06 15:50:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('816','25','815','2017-12-06 15:50:29','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('817','18','0','2017-12-11 09:09:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('818','18','817','2017-12-11 09:09:07','2','0.0779998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('819','19','0','2017-12-11 09:09:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('820','19','819','2017-12-11 09:09:15','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('821','5','0','2017-12-11 09:10:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('822','5','821','2017-12-11 09:10:21','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('823','6','0','2017-12-11 09:10:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('824','6','823','2017-12-11 09:10:38','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('825','17','0','2017-12-11 09:10:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('826','17','825','2017-12-11 09:10:49','2','0.0156012','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('827','21','0','2017-12-11 09:11:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('828','21','827','2017-12-11 09:11:19','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('829','9','0','2017-12-11 10:34:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('830','9','829','2017-12-11 10:34:46','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('831','22','0','2017-12-11 11:19:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('832','22','831','2017-12-11 11:19:10','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('833','13','0','2017-12-12 10:26:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('834','13','833','2017-12-12 10:26:11','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('835','14','0','2017-12-14 13:53:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('836','14','835','2017-12-14 13:53:13','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('837','20','0','2017-12-15 08:44:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('838','20','837','2017-12-15 08:44:52','2','0.1248','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('839','24','0','2017-12-20 15:00:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('840','24','839','2017-12-20 15:00:34','1','0.0936','2','Limpiar 2 archivos temporales creados hace más de 3600 segundos
');
INSERT INTO `glpi_crontasklogs` VALUES ('841','24','839','2017-12-20 15:00:34','2','0.0936','2','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('842','23','0','2017-12-20 15:00:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('843','23','842','2017-12-20 15:00:39','2','0.0156','33','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('844','15','0','2017-12-20 15:23:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('845','15','844','2017-12-20 15:23:46','2','0.0312009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('846','16','0','2017-12-20 15:55:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('847','16','846','2017-12-20 15:55:31','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('848','12','0','2017-12-22 17:54:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('849','12','848','2017-12-22 17:54:15','1','0.0935998','16','Limpiar 16 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('850','12','848','2017-12-22 17:54:15','2','0.0935998','16','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('851','25','0','2017-12-22 17:54:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('852','25','851','2017-12-22 17:54:44','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('853','17','0','2017-12-22 17:55:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('854','17','853','2017-12-22 17:55:13','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('855','21','0','2017-12-22 17:56:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('856','21','855','2017-12-22 17:56:20','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('857','9','0','2017-12-22 17:59:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('858','9','857','2017-12-22 17:59:05','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('859','22','0','2017-12-22 17:59:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('860','22','859','2017-12-22 17:59:17','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('861','18','0','2017-12-22 17:59:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('862','18','861','2017-12-22 17:59:59','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('863','19','0','2017-12-23 18:51:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('864','19','863','2017-12-23 18:51:12','2','0.093601','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('865','5','0','2018-01-02 22:37:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('866','5','865','2018-01-02 22:37:34','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('867','6','0','2018-01-03 15:30:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('868','6','867','2018-01-03 15:30:33','2','0.0779998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('869','13','0','2018-01-10 16:13:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('870','13','869','2018-01-10 16:13:35','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('871','8','0','2018-01-12 11:49:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('872','8','871','2018-01-12 11:49:19','2','0.842402','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('873','14','0','2018-01-12 11:50:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('874','14','873','2018-01-12 11:50:20','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('875','20','0','2018-01-12 11:50:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('876','20','875','2018-01-12 11:50:28','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('877','24','0','2018-01-12 11:50:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('878','24','877','2018-01-12 11:50:37','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('879','15','0','2018-01-12 19:02:35','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('880','15','879','2018-01-12 19:02:35','2','0.0312011','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('881','16','0','2018-01-15 16:02:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('882','16','881','2018-01-15 16:02:12','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('883','23','0','2018-01-16 18:21:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('884','23','883','2018-01-16 18:21:09','2','0.0624001','70','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('885','17','0','2018-01-17 16:26:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('886','17','885','2018-01-17 16:26:08','2','0.0779998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('887','22','0','2018-01-17 21:00:46','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('888','22','887','2018-01-17 21:00:46','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('889','21','0','2018-01-18 14:54:48','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('890','21','889','2018-01-18 14:54:48','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('891','9','0','2018-01-18 16:37:52','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('892','9','891','2018-01-18 16:37:52','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('893','12','0','2018-01-18 16:38:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('894','12','893','2018-01-18 16:38:43','1','0.0624001','35','Limpiar 35 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('895','12','893','2018-01-18 16:38:43','2','0.0624001','35','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('896','25','0','2018-01-18 16:39:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('897','25','896','2018-01-18 16:39:55','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('898','18','0','2018-01-18 16:40:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('899','18','898','2018-01-18 16:40:14','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('900','19','0','2018-01-18 16:45:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('901','19','900','2018-01-18 16:45:27','2','0','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('902','5','0','2018-01-18 16:48:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('903','5','902','2018-01-18 16:48:03','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('904','6','0','2018-01-23 21:12:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('905','6','904','2018-01-23 21:12:09','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('906','13','0','2018-01-24 15:09:51','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('907','13','906','2018-01-24 15:09:51','2','0.0935998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('908','14','0','2018-01-24 15:10:09','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('909','14','908','2018-01-24 15:10:09','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('910','20','0','2018-01-24 15:10:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('911','20','910','2018-01-24 15:10:28','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('912','24','0','2018-01-24 15:12:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('913','24','912','2018-01-24 15:12:07','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('914','15','0','2018-01-24 15:12:21','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('915','15','914','2018-01-24 15:12:21','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('916','16','0','2018-01-24 15:12:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('917','16','916','2018-01-24 15:12:33','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('918','17','0','2018-01-24 15:19:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('919','17','918','2018-01-24 15:19:24','2','0.0156012','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('920','23','0','2018-01-26 14:39:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('921','23','920','2018-01-26 14:39:36','2','0.0623999','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('922','22','0','2018-01-29 15:36:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('923','22','922','2018-01-29 15:36:43','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('924','21','0','2018-01-29 15:37:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('925','21','924','2018-01-29 15:37:05','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('926','9','0','2018-01-29 18:06:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('927','9','926','2018-01-29 18:06:12','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('928','8','0','2018-01-29 18:22:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('929','8','928','2018-01-29 18:22:43','2','0.436801','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('930','12','0','2018-01-29 20:07:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('931','12','930','2018-01-29 20:07:56','1','0.0780001','22','Limpiar 22 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('932','12','930','2018-01-29 20:07:56','2','0.0936','22','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('933','25','0','2018-01-30 11:44:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('934','25','933','2018-01-30 11:44:17','2','0.093601','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('935','18','0','2018-01-30 16:19:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('936','18','935','2018-01-30 16:19:28','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('937','19','0','2018-01-31 09:49:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('938','19','937','2018-01-31 09:49:41','2','0.0311999','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('939','5','0','2018-02-01 14:53:40','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('940','5','939','2018-02-01 14:53:40','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('941','17','0','2018-02-02 08:38:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('942','17','941','2018-02-02 08:38:05','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('943','13','0','2018-02-02 08:40:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('944','13','943','2018-02-02 08:40:25','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('945','14','0','2018-02-02 08:41:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('946','14','945','2018-02-02 08:41:03','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('947','20','0','2018-02-03 16:31:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('948','20','947','2018-02-03 16:31:28','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('949','24','0','2018-02-06 19:34:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('950','24','949','2018-02-06 19:34:44','2','0.0936','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('951','6','0','2018-02-07 08:06:13','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('952','6','951','2018-02-07 08:06:13','2','0.0780001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('953','15','0','2018-02-08 16:04:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('954','15','953','2018-02-08 16:04:32','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('955','16','0','2018-02-09 18:08:47','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('956','16','955','2018-02-09 18:08:47','2','0.0624011','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('957','23','0','2018-02-10 17:02:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('958','23','957','2018-02-10 17:02:28','2','0.0312009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('959','22','0','2018-02-10 17:06:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('960','22','959','2018-02-10 17:06:06','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('961','21','0','2018-02-13 15:16:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('962','21','961','2018-02-13 15:16:02','2','0.1404','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('963','9','0','2018-02-13 15:16:38','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('964','9','963','2018-02-13 15:16:38','2','0.0779998','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('965','12','0','2018-02-14 05:55:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('966','12','965','2018-02-14 05:55:36','1','0.0779998','27','Limpiar 27 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('967','12','965','2018-02-14 05:55:36','2','0.0779998','27','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('968','25','0','2018-02-21 14:40:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('969','25','968','2018-02-21 14:40:49','2','0.0936','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('970','18','0','2018-02-21 22:37:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('971','18','970','2018-02-21 22:37:18','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('972','19','0','2018-02-21 22:41:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('973','19','972','2018-02-21 22:41:25','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('974','17','0','2018-02-21 22:42:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('975','17','974','2018-02-21 22:42:10','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('976','13','0','2018-02-21 22:43:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('977','13','976','2018-02-21 22:43:07','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('978','14','0','2018-02-21 22:45:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('979','14','978','2018-02-21 22:45:41','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('980','5','0','2018-02-21 22:49:57','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('981','5','980','2018-02-21 22:49:57','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('982','20','0','2018-02-21 23:01:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('983','20','982','2018-02-21 23:01:16','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('984','8','0','2018-02-21 23:02:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('985','8','984','2018-02-21 23:02:29','2','1.2792','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('986','24','0','2018-02-21 23:47:12','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('987','24','986','2018-02-21 23:47:12','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('988','6','0','2018-02-21 23:48:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('989','6','988','2018-02-21 23:48:30','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('990','15','0','2018-02-21 23:48:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('991','15','990','2018-02-21 23:48:56','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('992','16','0','2018-02-25 21:05:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('993','16','992','2018-02-25 21:05:18','2','0.0936','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('994','22','0','2018-02-28 10:11:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('995','22','994','2018-02-28 10:11:59','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('996','23','0','2018-02-28 10:13:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('997','23','996','2018-02-28 10:13:44','2','0','1','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('998','21','0','2018-02-28 10:14:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('999','21','998','2018-02-28 10:14:04','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1000','9','0','2018-02-28 10:14:25','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1001','9','1000','2018-02-28 10:14:25','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1002','12','0','2018-02-28 10:15:33','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1003','12','1002','2018-02-28 10:15:33','1','0.0468009','20','Limpiar 20 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('1004','12','1002','2018-02-28 10:15:33','2','0.0468009','20','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('1005','17','0','2018-02-28 10:17:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1006','17','1005','2018-02-28 10:17:43','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1007','13','0','2018-02-28 10:21:24','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1008','13','1007','2018-02-28 10:21:24','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1009','14','0','2018-02-28 10:21:29','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1010','14','1009','2018-02-28 10:21:29','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1011','20','0','2018-02-28 10:31:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1012','20','1011','2018-02-28 10:31:30','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1013','24','0','2018-02-28 10:31:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1014','24','1013','2018-02-28 10:31:42','2','0','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1015','15','0','2018-03-01 13:20:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1016','15','1015','2018-03-01 13:20:03','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1017','25','0','2018-03-01 13:21:39','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1018','25','1017','2018-03-01 13:21:39','2','0.0156009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1019','18','0','2018-03-01 13:23:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1020','18','1019','2018-03-01 13:23:41','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1021','19','0','2018-03-01 13:26:15','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1022','19','1021','2018-03-01 13:26:15','2','0.0156','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('1023','5','0','2018-03-01 13:28:54','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1024','5','1023','2018-03-01 13:28:54','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1025','6','0','2018-03-01 13:29:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1026','6','1025','2018-03-01 13:29:03','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1027','16','0','2018-03-01 13:33:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1028','16','1027','2018-03-01 13:33:31','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1029','22','0','2018-03-01 13:33:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1030','22','1029','2018-03-01 13:33:49','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1031','21','0','2018-03-01 13:34:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1032','21','1031','2018-03-01 13:34:02','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1033','17','0','2018-03-01 13:38:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1034','17','1033','2018-03-01 13:38:59','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1035','9','0','2018-03-01 13:42:16','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1036','9','1035','2018-03-01 13:42:16','2','0.0467999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1037','13','0','2018-03-01 18:36:05','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1038','13','1037','2018-03-01 18:36:05','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1039','14','0','2018-03-01 18:47:11','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1040','14','1039','2018-03-01 18:47:11','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1041','20','0','2018-03-01 18:47:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1042','20','1041','2018-03-01 18:47:36','2','0.0156002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1043','24','0','2018-03-02 10:29:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1044','24','1043','2018-03-02 10:29:08','2','0.0624001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1045','8','0','2018-03-02 13:45:30','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1046','8','1045','2018-03-02 13:45:30','2','0.655201','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('1047','23','0','2018-03-02 13:51:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1048','23','1047','2018-03-02 13:51:19','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1049','12','0','2018-03-06 13:47:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1050','12','1049','2018-03-06 13:47:42','1','0.1092','21','Limpiar 21 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('1051','12','1049','2018-03-06 13:47:42','2','0.1092','21','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('1052','22','0','2018-03-06 14:21:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1053','22','1052','2018-03-06 14:21:53','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1054','21','0','2018-03-06 14:22:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1055','21','1054','2018-03-06 14:22:27','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1056','17','0','2018-03-06 17:29:55','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1057','17','1056','2018-03-06 17:29:55','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1058','9','0','2018-03-07 04:09:20','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1059','9','1058','2018-03-07 04:09:20','2','0.0623999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1060','13','0','2018-03-07 09:20:02','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1061','13','1060','2018-03-07 09:20:02','2','0.0156009','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1062','14','0','2018-03-07 09:20:08','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1063','14','1062','2018-03-07 09:20:08','2','0.0468001','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1064','20','0','2018-03-07 09:20:17','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1065','20','1064','2018-03-07 09:20:17','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1066','15','0','2018-03-08 18:17:22','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1067','15','1066','2018-03-08 18:17:22','2','0.0312002','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1068','16','0','2018-03-09 07:21:26','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1069','16','1068','2018-03-09 07:21:26','2','0.0936','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1070','24','0','2018-03-13 10:24:23','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1071','24','1070','2018-03-13 10:24:23','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1072','25','0','2018-03-13 10:27:06','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1073','25','1072','2018-03-13 10:27:06','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1074','18','0','2018-03-13 15:02:03','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1075','18','1074','2018-03-13 15:02:03','2','0.0311999','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1076','19','0','2018-03-14 09:03:50','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1077','19','1076','2018-03-14 09:03:50','2','0.0468011','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('1078','5','0','2018-03-15 07:52:07','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1079','5','1078','2018-03-15 07:52:07','2','0.1092','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1080','6','0','2018-03-15 16:10:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1081','6','1080','2018-03-15 16:10:44','2','0.0156','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1082','23','0','2018-03-20 20:01:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1083','23','1082','2018-03-20 20:01:53','2','0.144718','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1084','22','0','2018-03-20 20:05:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1085','22','1084','2018-03-20 20:05:27','2','0.0102658','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1086','21','0','2018-03-20 20:06:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1087','21','1086','2018-03-20 20:06:31','2','0.0523891','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1088','17','0','2018-03-20 20:06:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1089','17','1088','2018-03-20 20:06:44','2','0.0360699','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1090','9','0','2018-03-20 20:08:27','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1091','9','1090','2018-03-20 20:08:27','2','0.0309689','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1092','13','0','2018-03-20 20:08:36','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1093','13','1092','2018-03-20 20:08:36','2','0.010577','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1094','14','0','2018-03-20 21:31:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1095','14','1094','2018-03-20 21:31:43','2','0.265345','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1096','20','0','2018-03-20 21:45:14','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1097','20','1096','2018-03-20 21:45:14','2','0.107716','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1098','12','0','2018-03-20 22:38:28','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1099','12','1098','2018-03-20 22:38:28','1','0.171076','31','Limpiar 31 archivos de sesión creados hace mas de 1440 segundos.
');
INSERT INTO `glpi_crontasklogs` VALUES ('1100','12','1098','2018-03-20 22:38:28','2','0.171987','31','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('1101','15','0','2018-03-20 22:50:18','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1102','15','1101','2018-03-20 22:50:18','2','0.0397639','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1103','8','0','2018-03-20 22:50:43','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1104','8','1103','2018-03-20 22:50:43','2','1.30489','245','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('1105','16','0','2018-03-22 20:13:31','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1106','16','1105','2018-03-22 20:13:31','2','0.405613','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1107','24','0','2018-03-22 20:40:44','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1108','24','1107','2018-03-22 20:40:44','2','0.0122159','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1109','25','0','2018-03-22 21:38:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1110','25','1109','2018-03-22 21:38:37','2','0.0107841','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1111','18','0','2018-03-22 21:43:53','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1112','18','1111','2018-03-22 21:43:53','2','0.0324678','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1113','19','0','2018-03-22 22:03:41','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1114','19','1113','2018-03-22 22:03:41','2','0.0246019','0','Action completed, fully processed');
INSERT INTO `glpi_crontasklogs` VALUES ('1115','5','0','2018-03-22 22:26:34','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1116','5','1115','2018-03-22 22:26:34','2','0.0513532','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1117','6','0','2018-03-22 22:31:56','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1118','6','1117','2018-03-22 22:31:56','2','0.0437641','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1119','22','0','2018-03-22 22:36:59','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1120','22','1119','2018-03-22 22:36:59','2','0.103703','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1121','17','0','2018-03-22 22:44:42','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1122','17','1121','2018-03-22 22:44:42','2','0.0104289','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1123','21','0','2018-03-22 22:50:37','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1124','21','1123','2018-03-22 22:50:37','2','0.010916','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1125','9','0','2018-04-02 15:27:49','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1126','9','1125','2018-04-02 15:27:49','2','1.27242','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1127','13','0','2018-04-02 15:32:32','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1128','13','1127','2018-04-02 15:32:32','2','0.0370989','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1129','14','0','2018-04-02 15:51:04','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1130','14','1129','2018-04-02 15:51:04','2','0.0437081','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1131','20','0','2018-04-02 15:56:19','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1132','20','1131','2018-04-02 15:56:19','2','0.102511','0','Action completed, no processing required');
INSERT INTO `glpi_crontasklogs` VALUES ('1133','15','0','2018-04-02 16:42:10','0','0','0','Run mode: GLPI');
INSERT INTO `glpi_crontasklogs` VALUES ('1134','15','1133','2018-04-02 16:42:10','2','0.112506','0','Action completed, no processing required');

### Dump table glpi_crontasks

DROP TABLE IF EXISTS `glpi_crontasks`;
CREATE TABLE `glpi_crontasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(150) COLLATE utf8_unicode_ci NOT NULL COMMENT 'task name',
  `frequency` int(11) NOT NULL COMMENT 'second between launch',
  `param` int(11) DEFAULT NULL COMMENT 'task specify parameter',
  `state` int(11) NOT NULL DEFAULT '1' COMMENT '0:disabled, 1:waiting, 2:running',
  `mode` int(11) NOT NULL DEFAULT '1' COMMENT '1:internal, 2:external',
  `allowmode` int(11) NOT NULL DEFAULT '3' COMMENT '1:internal, 2:external, 3:both',
  `hourmin` int(11) NOT NULL DEFAULT '0',
  `hourmax` int(11) NOT NULL DEFAULT '24',
  `logs_lifetime` int(11) NOT NULL DEFAULT '30' COMMENT 'number of days',
  `lastrun` datetime DEFAULT NULL COMMENT 'last run date',
  `lastcode` int(11) DEFAULT NULL COMMENT 'last run return code',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`name`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Task run by internal / external cron.';

INSERT INTO `glpi_crontasks` VALUES ('2','CartridgeItem','cartridge','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('3','ConsumableItem','consumable','86400','10','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('4','SoftwareLicense','software','86400',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('5','Contract','contract','86400',NULL,'1','1','3','0','24','30','2018-03-22 16:26:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('6','InfoCom','infocom','86400',NULL,'1','1','3','0','24','30','2018-03-22 16:31:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('7','CronTask','logs','86400','30','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('8','CronTask','optimize','604800',NULL,'1','1','3','0','24','30','2018-03-20 16:50:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('9','MailCollector','mailgate','600','10','1','1','3','0','24','30','2018-04-02 08:27:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('10','DBconnection','checkdbreplicate','300',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('11','CronTask','checkupdate','604800',NULL,'0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('12','CronTask','session','86400',NULL,'1','1','3','0','24','30','2018-03-20 16:38:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('13','CronTask','graph','3600',NULL,'1','1','3','0','24','30','2018-04-02 08:32:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('14','ReservationItem','reservation','3600',NULL,'1','1','3','0','24','30','2018-04-02 08:51:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('15','Ticket','closeticket','43200',NULL,'1','1','3','0','24','30','2018-04-02 09:42:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('16','Ticket','alertnotclosed','43200',NULL,'1','1','3','0','24','30','2018-03-22 14:13:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('17','SlaLevel_Ticket','slaticket','300',NULL,'1','1','3','0','24','30','2018-03-22 16:44:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('18','Ticket','createinquest','86400',NULL,'1','1','3','0','24','30','2018-03-22 15:43:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('19','Crontask','watcher','86400',NULL,'1','1','3','0','24','30','2018-03-22 16:03:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('20','TicketRecurrent','ticketrecurrent','3600',NULL,'1','1','3','0','24','30','2018-04-02 08:56:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('21','PlanningRecall','planningrecall','300',NULL,'1','1','3','0','24','30','2018-03-22 16:50:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('22','QueuedMail','queuedmail','60','50','1','1','3','0','24','30','2018-03-22 16:37:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('23','QueuedMail','queuedmailclean','86400','30','1','1','3','0','24','30','2018-03-20 14:01:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('24','Crontask','temp','3600',NULL,'1','1','3','0','24','30','2018-03-22 14:40:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('25','MailCollector','mailgateerror','86400',NULL,'1','1','3','0','24','30','2018-03-22 15:38:00',NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('26','Crontask','circularlogs','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_crontasks` VALUES ('27','ObjectLock','unlockobject','86400','4','0','1','3','0','24','30',NULL,NULL,NULL,NULL,NULL);

### Dump table glpi_devicecases

DROP TABLE IF EXISTS `glpi_devicecases`;
CREATE TABLE `glpi_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecasetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicecasetypes_id` (`devicecasetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecasetypes

DROP TABLE IF EXISTS `glpi_devicecasetypes`;
CREATE TABLE `glpi_devicecasetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicecontrols

DROP TABLE IF EXISTS `glpi_devicecontrols`;
CREATE TABLE `glpi_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_raid` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicedrives

DROP TABLE IF EXISTS `glpi_devicedrives`;
CREATE TABLE `glpi_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_writer` tinyint(1) NOT NULL DEFAULT '1',
  `speed` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicegraphiccards

DROP TABLE IF EXISTS `glpi_devicegraphiccards`;
CREATE TABLE `glpi_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `memory_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `chipset` (`chipset`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceharddrives

DROP TABLE IF EXISTS `glpi_deviceharddrives`;
CREATE TABLE `glpi_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rpm` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interfacetypes_id` int(11) NOT NULL DEFAULT '0',
  `cache` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `capacity_default` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `interfacetypes_id` (`interfacetypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememories

DROP TABLE IF EXISTS `glpi_devicememories`;
CREATE TABLE `glpi_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `size_default` int(11) NOT NULL DEFAULT '0',
  `devicememorytypes_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `devicememorytypes_id` (`devicememorytypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicememorytypes

DROP TABLE IF EXISTS `glpi_devicememorytypes`;
CREATE TABLE `glpi_devicememorytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_devicememorytypes` VALUES ('1','EDO',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('2','DDR',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('3','SDRAM',NULL,NULL,NULL);
INSERT INTO `glpi_devicememorytypes` VALUES ('4','SDRAM-2',NULL,NULL,NULL);

### Dump table glpi_devicemotherboards

DROP TABLE IF EXISTS `glpi_devicemotherboards`;
CREATE TABLE `glpi_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `chipset` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicenetworkcards

DROP TABLE IF EXISTS `glpi_devicenetworkcards`;
CREATE TABLE `glpi_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bandwidth` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `mac_default` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepcis

DROP TABLE IF EXISTS `glpi_devicepcis`;
CREATE TABLE `glpi_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicepowersupplies

DROP TABLE IF EXISTS `glpi_devicepowersupplies`;
CREATE TABLE `glpi_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `power` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_atx` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_deviceprocessors

DROP TABLE IF EXISTS `glpi_deviceprocessors`;
CREATE TABLE `glpi_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `frequence` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `frequency_default` int(11) NOT NULL DEFAULT '0',
  `nbcores_default` int(11) DEFAULT NULL,
  `nbthreads_default` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_devicesoundcards

DROP TABLE IF EXISTS `glpi_devicesoundcards`;
CREATE TABLE `glpi_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `designation` (`designation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_displaypreferences

DROP TABLE IF EXISTS `glpi_displaypreferences`;
CREATE TABLE `glpi_displaypreferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `num` int(11) NOT NULL DEFAULT '0',
  `rank` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`itemtype`,`num`),
  KEY `rank` (`rank`),
  KEY `num` (`num`),
  KEY `itemtype` (`itemtype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_displaypreferences` VALUES ('32','Computer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('34','Computer','45','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('33','Computer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('31','Computer','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('30','Computer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('86','DocumentType','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('49','Monitor','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('50','Monitor','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('51','Monitor','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('52','Monitor','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('44','Printer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('38','NetworkEquipment','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('39','NetworkEquipment','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('45','Printer','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('46','Printer','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('63','Software','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('62','Software','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('61','Software','23','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('83','CartridgeItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('82','CartridgeItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('57','Peripheral','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('56','Peripheral','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('55','Peripheral','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('29','Computer','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('35','Computer','3','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('36','Computer','19','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('37','Computer','17','9','0');
INSERT INTO `glpi_displaypreferences` VALUES ('40','NetworkEquipment','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('41','NetworkEquipment','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('42','NetworkEquipment','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('43','NetworkEquipment','19','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('47','Printer','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('48','Printer','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('53','Monitor','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('54','Monitor','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('58','Peripheral','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('59','Peripheral','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('60','Peripheral','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('64','Contact','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('65','Contact','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('66','Contact','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('67','Contact','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('68','Contact','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('69','Supplier','9','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('70','Supplier','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('71','Supplier','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('72','Supplier','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('73','Supplier','10','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('74','Supplier','6','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('75','Contract','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('76','Contract','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('77','Contract','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('78','Contract','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('79','Contract','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('80','Contract','11','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('84','CartridgeItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('85','CartridgeItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('88','DocumentType','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('89','DocumentType','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('90','DocumentType','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('91','Document','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('92','Document','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('93','Document','7','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('94','Document','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('95','Document','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('96','User','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('98','User','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('99','User','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('100','User','3','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('101','ConsumableItem','34','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('102','ConsumableItem','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('103','ConsumableItem','23','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('104','ConsumableItem','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('105','NetworkEquipment','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('106','Printer','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('107','Monitor','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('108','Peripheral','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('109','User','8','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('110','Phone','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('111','Phone','23','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('112','Phone','3','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('113','Phone','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('114','Phone','40','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('115','Phone','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('116','Phone','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('117','Group','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('118','AllAssets','31','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('119','ReservationItem','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('120','ReservationItem','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('125','Budget','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('122','Software','72','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('123','Software','163','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('124','Budget','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('126','Budget','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('127','Budget','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('128','Crontask','8','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('129','Crontask','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('130','Crontask','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('131','Crontask','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('132','RequestType','14','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('133','RequestType','15','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('134','NotificationTemplate','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('135','NotificationTemplate','16','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('136','Notification','5','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('137','Notification','6','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('138','Notification','2','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('139','Notification','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('140','Notification','80','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('141','Notification','86','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('142','MailCollector','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('143','MailCollector','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('144','AuthLDAP','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('145','AuthLDAP','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('146','AuthMail','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('147','AuthMail','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('210','IPNetwork','18','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('209','WifiNetwork','10','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('150','Profile','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('151','Profile','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('152','Profile','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('153','Transfer','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('154','TicketValidation','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('155','TicketValidation','2','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('156','TicketValidation','8','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('157','TicketValidation','4','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('158','TicketValidation','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('159','TicketValidation','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('160','NotImportedEmail','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('161','NotImportedEmail','5','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('162','NotImportedEmail','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('163','NotImportedEmail','6','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('164','NotImportedEmail','16','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('165','NotImportedEmail','19','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('166','RuleRightParameter','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('167','Ticket','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('168','Ticket','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('169','Ticket','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('170','Ticket','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('171','Ticket','4','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('172','Ticket','5','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('173','Ticket','7','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('174','Calendar','19','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('175','Holiday','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('176','Holiday','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('177','Holiday','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('178','SLA','4','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('179','Ticket','18','8','0');
INSERT INTO `glpi_displaypreferences` VALUES ('180','AuthLdap','30','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('181','AuthMail','6','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('208','FQDN','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('183','FieldUnicity','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('184','FieldUnicity','80','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('185','FieldUnicity','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('186','FieldUnicity','3','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('187','FieldUnicity','86','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('188','FieldUnicity','30','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('189','Problem','21','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('190','Problem','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('191','Problem','19','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('192','Problem','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('193','Problem','3','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('194','Problem','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('195','Problem','18','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('196','Vlan','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('197','TicketRecurrent','11','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('198','TicketRecurrent','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('199','TicketRecurrent','13','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('200','TicketRecurrent','15','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('201','TicketRecurrent','14','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('202','Reminder','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('203','Reminder','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('204','Reminder','4','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('205','Reminder','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('206','Reminder','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('207','Reminder','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('211','IPNetwork','10','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('212','IPNetwork','11','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('213','IPNetwork','12','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('214','IPNetwork','17','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('215','NetworkName','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('216','NetworkName','13','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('217','RSSFeed','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('218','RSSFeed','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('219','RSSFeed','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('220','RSSFeed','19','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('221','RSSFeed','6','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('222','RSSFeed','7','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('223','Blacklist','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('224','Blacklist','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('225','ReservationItem','5','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('226','QueueMail','16','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('227','QueueMail','7','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('228','QueueMail','20','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('229','QueueMail','21','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('230','QueueMail','22','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('231','QueueMail','15','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('232','Change','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('233','Change','19','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('234','Change','15','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('235','Change','7','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('236','Change','18','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('237','Project','3','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('238','Project','4','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('239','Project','12','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('240','Project','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('241','Project','15','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('242','Project','21','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('243','ProjectState','12','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('244','ProjectState','11','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('245','ProjectTask','2','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('246','ProjectTask','12','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('247','ProjectTask','14','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('248','ProjectTask','5','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('249','ProjectTask','7','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('250','ProjectTask','8','6','0');
INSERT INTO `glpi_displaypreferences` VALUES ('251','ProjectTask','13','7','0');
INSERT INTO `glpi_displaypreferences` VALUES ('252','CartridgeItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('253','ConsumableItem','9','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('254','ReservationItem','9','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('255','SoftwareLicense','1','1','0');
INSERT INTO `glpi_displaypreferences` VALUES ('256','SoftwareLicense','3','2','0');
INSERT INTO `glpi_displaypreferences` VALUES ('257','SoftwareLicense','10','3','0');
INSERT INTO `glpi_displaypreferences` VALUES ('258','SoftwareLicense','162','4','0');
INSERT INTO `glpi_displaypreferences` VALUES ('259','SoftwareLicense','5','5','0');
INSERT INTO `glpi_displaypreferences` VALUES ('260','TicketTemplate','2','1','2');

### Dump table glpi_documentcategories

DROP TABLE IF EXISTS `glpi_documentcategories`;
CREATE TABLE `glpi_documentcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `unicity` (`documentcategories_id`,`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_documents

DROP TABLE IF EXISTS `glpi_documents`;
CREATE TABLE `glpi_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'for display and transfert',
  `filepath` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'file storage path',
  `documentcategories_id` int(11) NOT NULL DEFAULT '0',
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `sha1sum` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_blacklisted` tinyint(1) NOT NULL DEFAULT '0',
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `users_id` (`users_id`),
  KEY `documentcategories_id` (`documentcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `sha1sum` (`sha1sum`),
  KEY `tag` (`tag`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documents` VALUES ('1','0','0','Documento de incidencia 5','Error SISO_16-11-2017.docx','DOCX/3f/0d8d18783641748a72a2537df3efa215de0799.DOCX','0','application/vnd.openxmlformats-officedocument.wordprocessingml.document','2017-11-16 14:59:13',NULL,'0',NULL,'14','5','3f0d8d18783641748a72a2537df3efa215de0799','0','42656944-e83368c6-5a0dee087fb324.02237748','2017-11-16 14:59:13');
INSERT INTO `glpi_documents` VALUES ('2','0','0','Documento de incidencia 6','SS-Noviembre Marin.pdf','PDF/c0/8516df336dc223a164d52d78906f158e416b16.PDF','0','application/pdf','2017-11-23 14:51:37',NULL,'0',NULL,'14','6','c08516df336dc223a164d52d78906f158e416b16','0','42656944-e83368c6-5a1726c2d295c5.91510523','2017-11-23 14:51:37');
INSERT INTO `glpi_documents` VALUES ('3','0','0','Documento de incidencia 7','SANDRA LARA 43.479.573 salud NOV.pdf','PDF/86/0c960c38e8415c94f9bc57fab870a98b0bb7c4.PDF','0','application/pdf','2017-11-28 11:01:36',NULL,'0',NULL,'14','7','860c960c38e8415c94f9bc57fab870a98b0bb7c4','0','42656944-e83368c6-5a1d88597f8207.18397147','2017-11-28 11:01:36');
INSERT INTO `glpi_documents` VALUES ('4','0','0','Documento de incidencia 8','AjustePlanilla_JohanaPrada.jpg','JPG/9b/cee5e4af3df5c83151dc298f01ba3802a98157.JPG','0','image/jpeg','2017-11-28 11:12:04',NULL,'0',NULL,'14','8','9bcee5e4af3df5c83151dc298f01ba3802a98157','0','42656944-e83368c6-5a1d8a913e0754.59932701','2017-11-28 11:12:04');
INSERT INTO `glpi_documents` VALUES ('5','0','0','Documento de incidencia 9','Ajuste Claudia Viviana Valencia_Noviembre.pdf','PDF/0c/72637be24a9547ab95268c1fdb542792027b06.PDF','0','application/pdf','2017-11-29 14:29:59',NULL,'0',NULL,'14','9','0c72637be24a9547ab95268c1fdb542792027b06','0','42656944-e83368c6-5a1f0ab01514b9.19381817','2017-11-29 14:29:59');
INSERT INTO `glpi_documents` VALUES ('6','0','0','Documento de incidencia 12','SS_DICIEMBRE-Diana Isabel Cano.pdf','PDF/10/227b2191b964619ba8ca347bb462be4b1aeb6a.PDF','0','application/pdf','2017-12-06 14:10:59',NULL,'0',NULL,'14','12','10227b2191b964619ba8ca347bb462be4b1aeb6a','0','42656944-e83368c6-5a283ef1928505.99286956','2017-12-06 14:10:59');
INSERT INTO `glpi_documents` VALUES ('7','0','0','Documento de incidencia 12','SS-Diciembre-Liliana Garcia.pdf','PDF/e4/009b18743298428620fc3525f26e360681ad90.PDF','0','application/pdf','2017-12-06 14:10:59',NULL,'0',NULL,'14','12','e4009b18743298428620fc3525f26e360681ad90','0','42656944-e83368c6-5a283ef8bd7dd9.78279291','2017-12-06 14:10:59');
INSERT INTO `glpi_documents` VALUES ('8','0','0','Documento de incidencia 12','SS-Diciembre-Jhon Smith Arenas.pdf','PDF/0c/0b36b76725f53d0db76258b2fa50186fa317d8.PDF','0','application/pdf','2017-12-06 14:10:59',NULL,'0',NULL,'14','12','0c0b36b76725f53d0db76258b2fa50186fa317d8','0','42656944-e83368c6-5a2840bc8ace66.34733092','2017-12-06 14:10:59');

### Dump table glpi_documents_items

DROP TABLE IF EXISTS `glpi_documents_items`;
CREATE TABLE `glpi_documents_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `documents_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`documents_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`,`entities_id`,`is_recursive`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documents_items` VALUES ('1','1','5','Ticket','0','0','2017-11-16 14:59:13');
INSERT INTO `glpi_documents_items` VALUES ('2','2','6','Ticket','0','0','2017-11-23 14:51:37');
INSERT INTO `glpi_documents_items` VALUES ('5','5','9','Ticket','0','0','2017-11-29 14:29:59');
INSERT INTO `glpi_documents_items` VALUES ('6','6','12','Ticket','0','0','2017-12-06 14:10:59');
INSERT INTO `glpi_documents_items` VALUES ('7','7','12','Ticket','0','0','2017-12-06 14:10:59');
INSERT INTO `glpi_documents_items` VALUES ('8','8','12','Ticket','0','0','2017-12-06 14:10:59');

### Dump table glpi_documenttypes

DROP TABLE IF EXISTS `glpi_documenttypes`;
CREATE TABLE `glpi_documenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ext` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_uploadable` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ext`),
  KEY `name` (`name`),
  KEY `is_uploadable` (`is_uploadable`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_documenttypes` VALUES ('1','JPEG','jpg','jpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('2','PNG','png','png-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('3','GIF','gif','gif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('4','BMP','bmp','bmp-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('5','Photoshop','psd','psd-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('6','TIFF','tif','tif-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('7','AIFF','aiff','aiff-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('8','Windows Media','asf','asf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('9','Windows Media','avi','avi-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('44','C source','c','c-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('27','RealAudio','rm','rm-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('16','Midi','mid','mid-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('17','QuickTime','mov','mov-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('18','MP3','mp3','mp3-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('19','MPEG','mpg','mpg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('20','Ogg Vorbis','ogg','ogg-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('24','QuickTime','qt','qt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('10','BZip','bz2','bz2-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('25','RealAudio','ra','ra-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('26','RealAudio','ram','ram-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('11','Word','doc','doc-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('12','DjVu','djvu','','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('42','MNG','mng','','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('13','PostScript','eps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('14','GZ','gz','gz-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('37','WAV','wav','wav-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('15','HTML','html','html-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('34','Flash','swf','swf-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('21','PDF','pdf','pdf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('22','PowerPoint','ppt','ppt-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('23','PostScript','ps','ps-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('40','Windows Media','wmv','wmv-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('28','RTF','rtf','rtf-dist.png','','1','2004-12-13 19:47:21',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('29','StarOffice','sdd','sdd-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('30','StarOffice','sdw','sdw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('31','Stuffit','sit','sit-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('43','Adobe Illustrator','ai','ai-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('32','OpenOffice Impress','sxi','sxi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('33','OpenOffice','sxw','sxw-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('46','DVI','dvi','dvi-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('35','TGZ','tgz','tgz-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('36','texte','txt','txt-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('49','RedHat/Mandrake/SuSE','rpm','rpm-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('38','Excel','xls','xls-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('39','XML','xml','xml-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('41','Zip','zip','zip-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('45','Debian','deb','deb-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('47','C header','h','h-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('48','Pascal','pas','pas-dist.png','','1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('50','OpenOffice Calc','sxc','sxc-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('51','LaTeX','tex','tex-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('52','GIMP multi-layer','xcf','xcf-dist.png','','1','2004-12-13 19:47:22',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('53','JPEG','jpeg','jpg-dist.png','','1','2005-03-07 22:23:17',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('54','Oasis Open Office Writer','odt','odt-dist.png','','1','2006-01-21 17:41:13',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('55','Oasis Open Office Calc','ods','ods-dist.png','','1','2006-01-21 17:41:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('56','Oasis Open Office Impress','odp','odp-dist.png','','1','2006-01-21 17:42:54',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('57','Oasis Open Office Impress Template','otp','odp-dist.png','','1','2006-01-21 17:43:58',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('58','Oasis Open Office Writer Template','ott','odt-dist.png','','1','2006-01-21 17:44:41',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('59','Oasis Open Office Calc Template','ots','ods-dist.png','','1','2006-01-21 17:45:30',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('60','Oasis Open Office Math','odf','odf-dist.png','','1','2006-01-21 17:48:05',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('61','Oasis Open Office Draw','odg','odg-dist.png','','1','2006-01-21 17:48:31',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('62','Oasis Open Office Draw Template','otg','odg-dist.png','','1','2006-01-21 17:49:46',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('63','Oasis Open Office Base','odb','odb-dist.png','','1','2006-01-21 18:03:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('64','Oasis Open Office HTML','oth','oth-dist.png','','1','2006-01-21 18:05:27',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('65','Oasis Open Office Writer Master','odm','odm-dist.png','','1','2006-01-21 18:06:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('66','Oasis Open Office Chart','odc','','','1','2006-01-21 18:07:48',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('67','Oasis Open Office Image','odi','','','1','2006-01-21 18:08:18',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('68','Word XML','docx','doc-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('69','Excel XML','xlsx','xls-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('70','PowerPoint XML','pptx','ppt-dist.png',NULL,'1','2011-01-18 11:40:42',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('71','Comma-Separated Values','csv','csv-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);
INSERT INTO `glpi_documenttypes` VALUES ('72','Scalable Vector Graphics','svg','svg-dist.png',NULL,'1','2011-12-06 09:48:34',NULL,NULL);

### Dump table glpi_domains

DROP TABLE IF EXISTS `glpi_domains`;
CREATE TABLE `glpi_domains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_dropdowntranslations

DROP TABLE IF EXISTS `glpi_dropdowntranslations`;
CREATE TABLE `glpi_dropdowntranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`language`,`field`),
  KEY `typeid` (`itemtype`,`items_id`),
  KEY `language` (`language`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities

DROP TABLE IF EXISTS `glpi_entities`;
CREATE TABLE `glpi_entities` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_email_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_reply_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notification_subject_tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_dn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `authldaps_id` int(11) NOT NULL DEFAULT '0',
  `mail_domain` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity_ldapfilter` text COLLATE utf8_unicode_ci,
  `mailing_signature` text COLLATE utf8_unicode_ci,
  `cartridges_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `consumables_alert_repeat` int(11) NOT NULL DEFAULT '-2',
  `use_licenses_alert` int(11) NOT NULL DEFAULT '-2',
  `send_licenses_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_contracts_alert` int(11) NOT NULL DEFAULT '-2',
  `send_contracts_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_infocoms_alert` int(11) NOT NULL DEFAULT '-2',
  `send_infocoms_alert_before_delay` int(11) NOT NULL DEFAULT '-2',
  `use_reservations_alert` int(11) NOT NULL DEFAULT '-2',
  `autoclose_delay` int(11) NOT NULL DEFAULT '-2',
  `notclosed_delay` int(11) NOT NULL DEFAULT '-2',
  `calendars_id` int(11) NOT NULL DEFAULT '-2',
  `auto_assign_mode` int(11) NOT NULL DEFAULT '-2',
  `tickettype` int(11) NOT NULL DEFAULT '-2',
  `max_closedate` datetime DEFAULT NULL,
  `inquest_config` int(11) NOT NULL DEFAULT '-2',
  `inquest_rate` int(11) NOT NULL DEFAULT '0',
  `inquest_delay` int(11) NOT NULL DEFAULT '-10',
  `inquest_URL` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `autofill_warranty_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_use_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_buy_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_delivery_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `autofill_order_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '-2',
  `entities_id_software` int(11) NOT NULL DEFAULT '-2',
  `default_contract_alert` int(11) NOT NULL DEFAULT '-2',
  `default_infocom_alert` int(11) NOT NULL DEFAULT '-2',
  `default_cartridges_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `default_consumables_alarm_threshold` int(11) NOT NULL DEFAULT '-2',
  `delay_send_emails` int(11) NOT NULL DEFAULT '-2',
  `is_notif_enable_default` int(11) NOT NULL DEFAULT '-2',
  `inquest_duration` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `autofill_decommission_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '-2',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`name`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_entities` VALUES ('0','FNSP','-1','FNSP',NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'0','0','0','0','0','0','0','0','0','0','0','0','-10','1',NULL,'1','0','0',NULL,'0','0','0','0','0','1','-10','0','0','10','10','0','1','0','2017-07-25 18:23:41',NULL,'0');
INSERT INTO `glpi_entities` VALUES ('1','Soporte técnico','0','FNSP > Soporte técnico','','2','{\"1\":\"1\"}','[\"0\"]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','2017-07-25 22:11:52','-2','0','-10',NULL,'-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','-2','0','2017-07-25 22:11:52','2017-07-25 22:11:52','-2');

### Dump table glpi_entities_knowbaseitems

DROP TABLE IF EXISTS `glpi_entities_knowbaseitems`;
CREATE TABLE `glpi_entities_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_reminders

DROP TABLE IF EXISTS `glpi_entities_reminders`;
CREATE TABLE `glpi_entities_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_entities_rssfeeds

DROP TABLE IF EXISTS `glpi_entities_rssfeeds`;
CREATE TABLE `glpi_entities_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_events

DROP TABLE IF EXISTS `glpi_events`;
CREATE TABLE `glpi_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `service` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) NOT NULL DEFAULT '0',
  `message` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `level` (`level`),
  KEY `item` (`type`,`items_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_events` VALUES ('1','-1','system','2017-06-29 12:17:13','login','3','glpi inicio de sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('2','-1','system','2017-06-29 12:19:40','login','3','glpi inicio de sesión desde la IP 172.22.30.185');
INSERT INTO `glpi_events` VALUES ('3','-1','system','2017-06-29 12:27:39','login','3','glpi inicio de sesión desde la IP 172.22.33.97');
INSERT INTO `glpi_events` VALUES ('4','-1','system','2017-06-29 14:36:58','login','3','glpi inicio de sesión desde la IP 172.22.30.185');
INSERT INTO `glpi_events` VALUES ('5','2','users','2017-06-29 14:37:37','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('6','2','users','2017-06-29 14:38:01','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('7','-1','system','2017-06-29 14:38:39','login','3','glpi inicio de sesión desde la IP 172.22.30.185');
INSERT INTO `glpi_events` VALUES ('8','-1','system','2017-06-29 15:29:00','login','3','glpi inicio de sesión desde la IP 172.22.0.89');
INSERT INTO `glpi_events` VALUES ('9','2','users','2017-06-29 15:30:31','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('10','-1','system','2017-06-29 21:32:00','login','3','glpi inicio de sesión desde la IP 200.118.199.95');
INSERT INTO `glpi_events` VALUES ('11','2','users','2017-06-29 21:33:56','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('12','-1','system','2017-06-30 00:03:54','login','3','glpi inicio de sesión desde la IP 200.118.199.95');
INSERT INTO `glpi_events` VALUES ('13','1','ComputerType','2017-06-30 00:07:29','setup','4','glpi agrega el elemento Portatil');
INSERT INTO `glpi_events` VALUES ('14','2','users','2017-06-30 00:09:41','setup','5','glpi actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('15','-1','system','2017-06-30 00:12:17','login','3','normal inicio de sesión desde la IP 200.118.199.95');
INSERT INTO `glpi_events` VALUES ('16','-1','system','2017-06-30 00:13:03','login','3','tech inicio de sesión desde la IP 200.118.199.95');
INSERT INTO `glpi_events` VALUES ('17','-1','system','2017-06-30 00:13:47','login','3','Inicio de sesión fallido para post-only desde la IP 200.118.199.95');
INSERT INTO `glpi_events` VALUES ('18','-1','system','2017-06-30 00:13:59','login','3','Inicio de sesión fallido para post-only desde la IP 200.118.199.95');
INSERT INTO `glpi_events` VALUES ('19','-1','system','2017-06-30 00:17:00','login','3','admin inicio de sesión desde la IP 200.118.199.95');
INSERT INTO `glpi_events` VALUES ('20','2','users','2017-06-30 00:18:52','setup','5','admin actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('21','2','users','2017-06-30 00:24:42','setup','5','admin actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('22','-1','system','2017-06-30 00:29:50','login','3','admin inicio de sesión desde la IP 200.118.199.95');
INSERT INTO `glpi_events` VALUES ('23','-1','system','2017-06-30 10:24:00','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('24','-1','system','2017-06-30 10:24:13','login','3','admin inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('25','-1','system','2017-06-30 10:54:17','login','3','admin inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('26','2','ComputerType','2017-06-30 10:55:58','setup','4','admin agrega el elemento Escritorio - PC');
INSERT INTO `glpi_events` VALUES ('27','3','ComputerType','2017-06-30 10:56:35','setup','4','admin agrega el elemento Escritorio All in one');
INSERT INTO `glpi_events` VALUES ('28','1','groups','2017-06-30 11:00:21','setup','4','admin agrega el elemento Soporte tecnico ');
INSERT INTO `glpi_events` VALUES ('29','2','groups','2017-06-30 11:00:44','setup','4','admin agrega el elemento Sistemas de información');
INSERT INTO `glpi_events` VALUES ('30','3','groups','2017-06-30 11:00:56','setup','4','admin agrega el elemento Entornos virtuales ');
INSERT INTO `glpi_events` VALUES ('31','4','groups','2017-06-30 11:01:08','setup','4','admin agrega el elemento Portal Web');
INSERT INTO `glpi_events` VALUES ('32','-1','system','2017-06-30 11:02:04','login','3','normal inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('33','-1','system','2017-06-30 11:03:07','login','3','admin inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('34','1','UserTitle','2017-06-30 11:06:00','setup','4','admin agrega el elemento Ingeniero');
INSERT INTO `glpi_events` VALUES ('35','6','users','2017-06-30 11:06:26','setup','4','admin agrega el elemento felipe.becerra');
INSERT INTO `glpi_events` VALUES ('36','6','users','2017-06-30 11:18:17','setup','5','admin actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('37','6','users','2017-06-30 11:20:30','setup','4','admin agrego un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('38','1','Location','2017-06-30 11:29:23','setup','4','admin agrega el elemento Area tecnologica ');
INSERT INTO `glpi_events` VALUES ('39','-1','system','2017-06-30 12:10:55','login','3','Inicio de sesión fallido para glpi desde la IP 172.22.33.97');
INSERT INTO `glpi_events` VALUES ('40','-1','system','2017-06-30 12:11:06','login','3','Inicio de sesión fallido para glpi desde la IP 172.22.33.97');
INSERT INTO `glpi_events` VALUES ('41','-1','system','2017-06-30 12:11:23','login','3','Inicio de sesión fallido para glpi desde la IP 172.22.33.97');
INSERT INTO `glpi_events` VALUES ('42','-1','system','2017-06-30 12:11:35','login','3','Inicio de sesión fallido para glpi desde la IP 172.22.33.97');
INSERT INTO `glpi_events` VALUES ('43','-1','system','2017-06-30 12:11:53','login','3','Inicio de sesión fallido para glpi desde la IP 172.22.33.97');
INSERT INTO `glpi_events` VALUES ('44','-1','system','2017-07-10 09:50:33','login','3','Inicio de sesión fallido para glpi desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('45','-1','system','2017-07-10 09:50:44','login','3','Inicio de sesión fallido para glpi desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('46','-1','system','2017-07-10 09:51:15','login','3','Inicio de sesión fallido para glpi desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('47','-1','system','2017-07-10 09:51:38','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('48','-1','system','2017-07-10 09:56:39','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('49','-1','system','2017-07-10 09:56:47','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('50','-1','system','2017-07-10 09:57:30','login','3','felipe.becerra inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('51','2','users','2017-07-10 09:58:04','setup','5','felipe.becerra actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('52','7','users','2017-07-10 09:59:00','setup','4','felipe.becerra agrega el elemento carlos.tangarife');
INSERT INTO `glpi_events` VALUES ('53','-1','system','2017-07-10 09:59:35','login','3','Inicio de sesión fallido para carlos.tangarife desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('54','-1','system','2017-07-10 09:59:51','login','3','Inicio de sesión fallido para carlos.tangarife desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('55','-1','system','2017-07-10 10:00:02','login','3','admin inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('56','7','users','2017-07-10 10:00:34','setup','5','admin actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('57','8','users','2017-07-10 10:07:32','setup','4','admin agrega el elemento prueba');
INSERT INTO `glpi_events` VALUES ('58','-1','system','2017-07-10 10:08:11','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('59','8','users','2017-07-10 10:10:12','setup','4','admin agrego un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('60','-1','system','2017-07-10 10:10:41','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('61','8','users','2017-07-10 10:11:21','setup','4','admin agrego un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('62','-1','system','2017-07-10 10:11:41','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('63','8','users','2017-07-10 10:12:10','setup','4','admin agrego un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('64','-1','system','2017-07-10 10:12:30','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('65','8','users','2017-07-10 10:16:42','setup','4','admin agrego un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('66','-1','system','2017-07-10 10:17:12','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('67','-1','system','2017-07-10 10:18:53','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('68','-1','system','2017-07-11 09:33:45','login','3','admin inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('69','1','SolutionType','2017-07-11 09:37:33','setup','4','admin agrega el elemento Sistemas de información ');
INSERT INTO `glpi_events` VALUES ('70','-1','system','2017-07-11 10:35:52','login','3','admin inicio de sesión desde la IP 172.22.30.185');
INSERT INTO `glpi_events` VALUES ('71','-1','system','2017-07-11 10:40:14','login','3','admin inicio de sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('72','-1','system','2017-07-11 14:33:26','login','3','admin inicio de sesión desde la IP 172.22.30.185');
INSERT INTO `glpi_events` VALUES ('73','2','users','2017-07-11 14:34:33','setup','5','admin actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('74','7','users','2017-07-11 14:36:16','setup','5','admin actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('75','7','users','2017-07-11 14:37:04','setup','5','admin actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('76','7','users','2017-07-11 14:37:15','setup','5','admin actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('77','3','groups','2017-07-11 14:41:42','setup','4','admin agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('78','3','groups','2017-07-11 14:41:49','setup','4','admin agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('79','2','groups','2017-07-11 14:42:19','setup','4','admin agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('80','2','groups','2017-07-11 14:42:27','setup','4','admin agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('81','1','groups','2017-07-11 14:43:19','setup','4','admin agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('82','1','groups','2017-07-11 14:43:26','setup','4','admin agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('83','-1','system','2017-07-12 10:22:37','login','3','Inicio de sesión fallido para juan.correa2 desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('84','-1','system','2017-07-12 10:22:49','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('85','-1','system','2017-07-12 10:23:05','login','3','Inicio de sesión fallido para juan.correa2 desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('86','-1','system','2017-07-12 10:23:18','login','3','Inicio de sesión fallido para felipe.becerrra desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('87','-1','system','2017-07-12 10:25:37','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('88','1','ITILCategory','2017-07-12 10:41:12','setup','4','juan.correa agrega el elemento Sistemas ');
INSERT INTO `glpi_events` VALUES ('89','2','ITILCategory','2017-07-12 10:41:48','setup','4','juan.correa agrega el elemento Creación de usuarios en un sistema ');
INSERT INTO `glpi_events` VALUES ('90','2','TicketTemplate','2017-07-12 10:45:03','setup','4','juan.correa agrega el elemento Soporte');
INSERT INTO `glpi_events` VALUES ('91','-1','system','2017-07-12 10:46:30','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('92','-1','system','2017-07-12 10:47:34','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('93','2','users','2017-07-12 11:06:01','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('94','5','groups','2017-07-12 11:08:37','setup','4','juan.correa agrega el elemento Solicitante');
INSERT INTO `glpi_events` VALUES ('95','5','groups','2017-07-12 11:09:20','setup','4','juan.correa agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('96','2','notifications','2017-07-12 11:25:42','notification','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('97','8','users','2017-07-12 11:29:41','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('98','2','notifications','2017-07-12 11:31:27','notification','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('99','2','notifications','2017-07-12 11:32:07','notification','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('100','-1','system','2017-07-12 12:04:27','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('101','2','users','2017-07-12 12:05:38','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('102','-1','system','2017-07-12 12:06:56','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('103','-1','system','2017-07-13 09:36:36','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('104','2','users','2017-07-13 09:37:01','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('105','-1','system','2017-07-13 10:53:20','login','3','Inicio de sesión fallido para sdfsdf desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('106','-1','system','2017-07-13 10:57:34','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('107','-1','system','2017-07-13 10:57:44','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('108','-1','system','2017-07-13 15:59:44','login','3','Inicio de sesión fallido para prueba desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('109','-1','system','2017-07-13 15:59:53','login','3','Inicio de sesión fallido para prueba desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('110','-1','system','2017-07-13 16:00:04','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('111','-1','system','2017-07-13 16:03:15','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('112','-1','system','2017-07-13 16:03:26','login','3','Inicio de sesión fallido para prueba desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('113','-1','system','2017-07-13 16:03:36','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('114','8','users','2017-07-13 16:08:05','setup','4','juan.correa agrego un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('115','0','Entity','2017-07-13 16:09:10','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('116','-1','system','2017-07-14 13:33:46','login','3','Inicio de sesión fallido para felipe desde la IP 172.22.32.10');
INSERT INTO `glpi_events` VALUES ('117','-1','system','2017-07-14 13:33:57','login','3','felipe.becerra inicio de sesión desde la IP 172.22.32.10');
INSERT INTO `glpi_events` VALUES ('118','-1','system','2017-07-18 09:37:31','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('119','-1','system','2017-07-18 09:37:44','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('120','9','users','2017-07-18 09:44:37','setup','4','juan.correa agrega el elemento alberto.lopez');
INSERT INTO `glpi_events` VALUES ('121','-1','system','2017-07-18 09:56:42','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('122','-1','system','2017-07-25 15:20:42','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('123','-1','system','2017-07-25 15:21:00','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('124','-1','system','2017-07-25 15:21:12','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('125','3','Location','2017-07-25 15:26:43','setup','4','juan.correa agrega el elemento Piso 4');
INSERT INTO `glpi_events` VALUES ('126','1','Location','2017-07-25 15:26:56','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('127','2','Location','2017-07-25 15:27:07','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('128','4','Location','2017-07-25 15:27:52','setup','4','juan.correa agrega el elemento 33-406 Asistencia de planeación');
INSERT INTO `glpi_events` VALUES ('129','5','Location','2017-07-25 15:29:59','setup','4','juan.correa agrega el elemento 33-413 Posgrados');
INSERT INTO `glpi_events` VALUES ('130','6','Location','2017-07-25 15:30:25','setup','4','juan.correa agrega el elemento 33-418 Coordinación posgrados');
INSERT INTO `glpi_events` VALUES ('131','7','Location','2017-07-25 15:30:49','setup','4','juan.correa agrega el elemento 33-417A Sala Videoconferencia');
INSERT INTO `glpi_events` VALUES ('132','8','Location','2017-07-25 15:31:15','setup','4','juan.correa agrega el elemento 33-401 Aula');
INSERT INTO `glpi_events` VALUES ('133','9','Location','2017-07-25 15:31:27','setup','4','juan.correa agrega el elemento 33-402 Aula');
INSERT INTO `glpi_events` VALUES ('134','10','Location','2017-07-25 15:31:46','setup','4','juan.correa agrega el elemento 33-404 Aula');
INSERT INTO `glpi_events` VALUES ('135','8','Location','2017-07-25 15:32:02','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('136','9','Location','2017-07-25 15:32:15','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('137','11','Location','2017-07-25 15:32:44','setup','4','juan.correa agrega el elemento 33-407 Aula');
INSERT INTO `glpi_events` VALUES ('138','12','Location','2017-07-25 15:32:58','setup','4','juan.correa agrega el elemento 33-410 Aula');
INSERT INTO `glpi_events` VALUES ('139','13','Location','2017-07-25 15:33:10','setup','4','juan.correa agrega el elemento 33-412 Aula');
INSERT INTO `glpi_events` VALUES ('140','14','Location','2017-07-25 15:58:59','setup','4','juan.correa agrega el elemento Piso 2');
INSERT INTO `glpi_events` VALUES ('141','15','Location','2017-07-25 15:59:10','setup','4','juan.correa agrega el elemento Piso 3');
INSERT INTO `glpi_events` VALUES ('142','16','Location','2017-07-25 15:59:17','setup','4','juan.correa agrega el elemento Piso 1');
INSERT INTO `glpi_events` VALUES ('143','3','ITILCategory','2017-07-25 16:13:03','setup','4','juan.correa agrega el elemento Entornos virtuales');
INSERT INTO `glpi_events` VALUES ('144','4','ITILCategory','2017-07-25 16:13:29','setup','4','juan.correa agrega el elemento Soporte técnico ');
INSERT INTO `glpi_events` VALUES ('145','1','PrinterType','2017-07-25 17:45:17','setup','4','juan.correa agrega el elemento Impresora Laser B/N');
INSERT INTO `glpi_events` VALUES ('146','2','PrinterType','2017-07-25 17:45:32','setup','4','juan.correa agrega el elemento Impresora Laser Color');
INSERT INTO `glpi_events` VALUES ('147','3','PrinterType','2017-07-25 17:45:42','setup','4','juan.correa agrega el elemento Impresora Multifuncional ');
INSERT INTO `glpi_events` VALUES ('148','4','PrinterType','2017-07-25 17:46:28','setup','4','juan.correa agrega el elemento Impresora de inyección de tinta');
INSERT INTO `glpi_events` VALUES ('149','1','Manufacturer','2017-07-25 17:49:48','setup','4','juan.correa agrega el elemento HP');
INSERT INTO `glpi_events` VALUES ('150','2','Manufacturer','2017-07-25 17:49:53','setup','4','juan.correa agrega el elemento EPSON');
INSERT INTO `glpi_events` VALUES ('151','3','Manufacturer','2017-07-25 17:50:21','setup','4','juan.correa agrega el elemento Kyocera');
INSERT INTO `glpi_events` VALUES ('152','1','PrinterModel','2017-07-25 17:55:51','setup','4','juan.correa agrega el elemento Kyosera ECOSYS M2030dn');
INSERT INTO `glpi_events` VALUES ('153','-1','system','2017-07-25 18:03:45','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('154','-1','system','2017-07-25 18:03:55','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('155','-1','system','2017-07-25 18:04:04','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('156','8','users','2017-07-25 18:04:29','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('157','-1','system','2017-07-25 18:04:38','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('158','-1','system','2017-07-25 18:07:08','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('159','-1','system','2017-07-25 18:08:08','login','3','Inicio de sesión fallido para pruebas desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('160','-1','system','2017-07-25 18:08:22','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('161','-1','system','2017-07-25 18:09:05','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('162','-1','system','2017-07-25 18:09:58','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('163','-1','system','2017-07-25 18:11:14','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('164','1','OperatingSystem','2017-07-25 18:17:38','setup','4','juan.correa agrega el elemento Windows 7');
INSERT INTO `glpi_events` VALUES ('165','2','OperatingSystem','2017-07-25 18:17:45','setup','4','juan.correa agrega el elemento Windows 8');
INSERT INTO `glpi_events` VALUES ('166','3','OperatingSystem','2017-07-25 18:17:54','setup','4','juan.correa agrega el elemento Windows 8.1');
INSERT INTO `glpi_events` VALUES ('167','4','OperatingSystem','2017-07-25 18:18:05','setup','4','juan.correa agrega el elemento Windows 10');
INSERT INTO `glpi_events` VALUES ('168','5','OperatingSystem','2017-07-25 18:19:25','setup','4','juan.correa agrega el elemento Windows Server 2008 R2');
INSERT INTO `glpi_events` VALUES ('169','6','users','2017-07-25 18:19:56','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('170','9','users','2017-07-25 18:20:28','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('171','0','Entity','2017-07-25 18:23:41','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('172','-1','system','2017-07-25 22:09:27','login','3','Inicio de sesión fallido para juan.correa2 desde la IP 181.49.94.139');
INSERT INTO `glpi_events` VALUES ('173','-1','system','2017-07-25 22:09:48','login','3','juan.correa inicio de sesión desde la IP 181.49.94.139');
INSERT INTO `glpi_events` VALUES ('174','1','Entity','2017-07-25 22:11:52','setup','4','juan.correa agrega el elemento Soporte técnico');
INSERT INTO `glpi_events` VALUES ('175','-1','system','2017-07-25 22:18:55','login','3','prueba inicio de sesión desde la IP 181.49.94.139');
INSERT INTO `glpi_events` VALUES ('176','-1','system','2017-07-25 22:43:06','login','3','juan.correa inicio de sesión desde la IP 181.49.94.139');
INSERT INTO `glpi_events` VALUES ('177','-1','system','2017-07-25 23:24:26','login','3','juan.correa inicio de sesión desde la IP 181.49.94.139');
INSERT INTO `glpi_events` VALUES ('178','-1','system','2017-07-26 00:22:35','login','3','juan.correa inicio de sesión desde la IP 181.49.94.139');
INSERT INTO `glpi_events` VALUES ('179','10','users','2017-07-26 00:24:49','setup','4','juan.correa agrega el elemento paula.hincapie');
INSERT INTO `glpi_events` VALUES ('180','5','ITILCategory','2017-07-26 00:25:45','setup','4','juan.correa agrega el elemento Capacitación EVA y Moodle');
INSERT INTO `glpi_events` VALUES ('181','6','ITILCategory','2017-07-26 00:26:42','setup','4','juan.correa agrega el elemento montaje o edición de curso ');
INSERT INTO `glpi_events` VALUES ('182','7','ITILCategory','2017-07-26 00:27:24','setup','4','juan.correa agrega el elemento Publicación portales Web');
INSERT INTO `glpi_events` VALUES ('183','6','ITILCategory','2017-07-26 00:27:41','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('184','8','ITILCategory','2017-07-26 00:28:37','setup','4','juan.correa agrega el elemento Dificultades con usuario de un sistema');
INSERT INTO `glpi_events` VALUES ('185','9','ITILCategory','2017-07-26 00:29:06','setup','4','juan.correa agrega el elemento Modificar información ');
INSERT INTO `glpi_events` VALUES ('186','10','ITILCategory','2017-07-26 00:29:24','setup','4','juan.correa agrega el elemento Generar informe');
INSERT INTO `glpi_events` VALUES ('187','11','ITILCategory','2017-07-26 00:29:46','setup','4','juan.correa agrega el elemento Capacitar sobre uso de un sistema');
INSERT INTO `glpi_events` VALUES ('188','12','ITILCategory','2017-07-26 00:30:28','setup','4','juan.correa agrega el elemento Sistema fuera de linea');
INSERT INTO `glpi_events` VALUES ('189','13','ITILCategory','2017-07-26 00:31:58','setup','4','juan.correa agrega el elemento Impresora no funciona');
INSERT INTO `glpi_events` VALUES ('190','14','ITILCategory','2017-07-26 00:32:16','setup','4','juan.correa agrega el elemento Instalar software');
INSERT INTO `glpi_events` VALUES ('191','15','ITILCategory','2017-07-26 00:32:34','setup','4','juan.correa agrega el elemento Computador no funciona');
INSERT INTO `glpi_events` VALUES ('192','16','ITILCategory','2017-07-26 00:32:52','setup','4','juan.correa agrega el elemento Problemas de red');
INSERT INTO `glpi_events` VALUES ('193','17','ITILCategory','2017-07-26 00:34:17','setup','4','juan.correa agrega el elemento Reserva sala Webex');
INSERT INTO `glpi_events` VALUES ('194','-1','system','2017-07-26 09:34:37','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('195','7','ITILCategory','2017-07-26 09:44:16','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('196','7','ITILCategory','2017-07-26 09:44:20','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('197','18','ITILCategory','2017-07-26 09:45:11','setup','4','juan.correa agrega el elemento Publicación portal Campus virtual Salud Pública CVSP');
INSERT INTO `glpi_events` VALUES ('198','7','ITILCategory','2017-07-26 09:48:36','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('199','19','ITILCategory','2017-07-26 09:49:00','setup','4','juan.correa agrega el elemento Comunicaciones ');
INSERT INTO `glpi_events` VALUES ('200','6','ITILCategory','2017-07-26 09:49:47','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('201','20','ITILCategory','2017-07-26 09:50:54','setup','4','juan.correa agrega el elemento Implementación recurso educativo ');
INSERT INTO `glpi_events` VALUES ('202','21','ITILCategory','2017-07-26 09:54:57','setup','4','juan.correa agrega el elemento Edición y ajustes curso EVA');
INSERT INTO `glpi_events` VALUES ('203','22','ITILCategory','2017-07-26 09:55:20','setup','4','juan.correa agrega el elemento Capacitación en Webex');
INSERT INTO `glpi_events` VALUES ('204','17','ITILCategory','2017-07-26 09:56:54','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('205','23','ITILCategory','2017-07-26 09:57:28','setup','4','juan.correa agrega el elemento Apoyo en videoconferencia ');
INSERT INTO `glpi_events` VALUES ('206','2','users','2017-07-26 09:59:50','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('207','-1','system','2017-07-26 10:01:04','login','3','Inicio de sesión fallido para juan.correa2 desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('208','-1','system','2017-07-26 10:01:26','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('209','8','ITILCategory','2017-07-26 10:02:25','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('210','9','ITILCategory','2017-07-26 10:03:50','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('211','9','ITILCategory','2017-07-26 10:04:18','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('212','2','ITILCategory','2017-07-26 10:05:06','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('213','2','ITILCategory','2017-07-26 10:05:57','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('214','4','Manufacturer','2017-07-26 10:09:07','setup','4','juan.correa agrega el elemento Lenovo');
INSERT INTO `glpi_events` VALUES ('215','5','Manufacturer','2017-07-26 10:09:16','setup','4','juan.correa agrega el elemento Apple');
INSERT INTO `glpi_events` VALUES ('216','6','Manufacturer','2017-07-26 10:09:21','setup','4','juan.correa agrega el elemento Asus');
INSERT INTO `glpi_events` VALUES ('217','7','Manufacturer','2017-07-26 10:09:29','setup','4','juan.correa agrega el elemento Cisco');
INSERT INTO `glpi_events` VALUES ('218','8','Manufacturer','2017-07-26 10:09:36','setup','4','juan.correa agrega el elemento LG');
INSERT INTO `glpi_events` VALUES ('219','9','Manufacturer','2017-07-26 10:09:53','setup','4','juan.correa agrega el elemento Toshiba');
INSERT INTO `glpi_events` VALUES ('220','10','Manufacturer','2017-07-26 10:10:08','setup','4','juan.correa agrega el elemento Dell');
INSERT INTO `glpi_events` VALUES ('221','11','Manufacturer','2017-07-26 10:10:37','setup','4','juan.correa agrega el elemento Panasonic');
INSERT INTO `glpi_events` VALUES ('222','4','ComputerType','2017-07-26 10:15:49','setup','4','juan.correa agrega el elemento Servidor');
INSERT INTO `glpi_events` VALUES ('223','5','ComputerType','2017-07-26 10:16:06','setup','4','juan.correa agrega el elemento Table PC');
INSERT INTO `glpi_events` VALUES ('224','6','ComputerType','2017-07-26 10:16:51','setup','4','juan.correa agrega el elemento Tablet entretenimiento');
INSERT INTO `glpi_events` VALUES ('225','1','PeripheralType','2017-07-26 10:17:55','setup','4','juan.correa agrega el elemento Camara Web ');
INSERT INTO `glpi_events` VALUES ('226','1','PeripheralType','2017-07-26 10:18:56','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('227','2','PeripheralType','2017-07-26 10:19:25','setup','4','juan.correa agrega el elemento Tripode');
INSERT INTO `glpi_events` VALUES ('228','3','PeripheralType','2017-07-26 10:19:59','setup','4','juan.correa agrega el elemento Micrófonos de ambiente');
INSERT INTO `glpi_events` VALUES ('229','5','ComputerType','2017-07-26 10:20:28','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('230','7','ComputerType','2017-07-26 10:21:18','setup','4','juan.correa agrega el elemento Portátil Ultrabook');
INSERT INTO `glpi_events` VALUES ('231','8','ComputerType','2017-07-26 10:22:05','setup','4','juan.correa agrega el elemento Estación de trabajo');
INSERT INTO `glpi_events` VALUES ('232','1','NetworkEquipmentType','2017-07-26 10:22:23','setup','4','juan.correa agrega el elemento Router');
INSERT INTO `glpi_events` VALUES ('233','2','NetworkEquipmentType','2017-07-26 10:22:34','setup','4','juan.correa agrega el elemento Access Point');
INSERT INTO `glpi_events` VALUES ('234','3','NetworkEquipmentType','2017-07-26 10:22:59','setup','4','juan.correa agrega el elemento Switch router');
INSERT INTO `glpi_events` VALUES ('235','4','NetworkEquipmentType','2017-07-26 10:23:10','setup','4','juan.correa agrega el elemento Hub concentrador');
INSERT INTO `glpi_events` VALUES ('236','5','NetworkEquipmentType','2017-07-26 10:23:20','setup','4','juan.correa agrega el elemento Briigde');
INSERT INTO `glpi_events` VALUES ('237','6','NetworkEquipmentType','2017-07-26 10:24:00','setup','4','juan.correa agrega el elemento Router inalámbrico ');
INSERT INTO `glpi_events` VALUES ('238','5','NetworkEquipmentType','2017-07-26 10:24:14','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('239','3','PrinterType','2017-07-26 10:24:51','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('240','5','PrinterType','2017-07-26 10:25:06','setup','4','juan.correa agrega el elemento Impresora Multifuncional inyección de tinta');
INSERT INTO `glpi_events` VALUES ('241','4','PeripheralType','2017-07-26 10:26:24','setup','4','juan.correa agrega el elemento Escaner');
INSERT INTO `glpi_events` VALUES ('242','1','State','2017-07-26 10:36:01','setup','4','juan.correa agrega el elemento Activo');
INSERT INTO `glpi_events` VALUES ('243','2','State','2017-07-26 10:36:12','setup','4','juan.correa agrega el elemento En mantenimiento ');
INSERT INTO `glpi_events` VALUES ('244','3','State','2017-07-26 10:36:38','setup','4','juan.correa agrega el elemento Reintegrado');
INSERT INTO `glpi_events` VALUES ('245','7','NetworkEquipmentType','2017-07-26 10:39:37','setup','4','juan.correa agrega el elemento NAS');
INSERT INTO `glpi_events` VALUES ('246','6','OperatingSystem','2017-07-26 10:40:43','setup','4','juan.correa agrega el elemento IOS');
INSERT INTO `glpi_events` VALUES ('247','24','ITILCategory','2017-07-26 10:47:48','setup','4','juan.correa agrega el elemento Periferico no funciona');
INSERT INTO `glpi_events` VALUES ('248','25','ITILCategory','2017-07-26 10:49:17','setup','4','juan.correa agrega el elemento Problema de sistema operativo ');
INSERT INTO `glpi_events` VALUES ('249','26','ITILCategory','2017-07-26 10:50:29','setup','4','juan.correa agrega el elemento Problemas de seguridad y virus ');
INSERT INTO `glpi_events` VALUES ('250','27','ITILCategory','2017-07-26 10:51:38','setup','4','juan.correa agrega el elemento Problemas de software de aplicación ');
INSERT INTO `glpi_events` VALUES ('251','-1','system','2017-07-26 10:53:10','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('252','-1','system','2017-07-26 10:54:02','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('253','-1','system','2017-07-27 10:18:59','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('254','-1','system','2017-07-27 10:19:17','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('255','-1','system','2017-07-27 10:19:27','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('256','-1','system','2017-07-27 10:30:25','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('257','11','users','2017-07-27 11:25:52','setup','4','juan.correa agrega el elemento 43157733');
INSERT INTO `glpi_events` VALUES ('258','6','groups','2017-07-27 11:27:42','setup','4','juan.correa agrega el elemento Comunicaciones');
INSERT INTO `glpi_events` VALUES ('259','8','users','2017-07-27 11:35:48','setup','4','juan.correa agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('260','-1','system','2017-07-27 11:36:02','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('261','-1','system','2017-08-10 10:11:34','login','3','Inicio de sesión fallido para felipe desde la IP 172.22.32.10');
INSERT INTO `glpi_events` VALUES ('262','-1','system','2017-08-10 10:11:52','login','3','Inicio de sesión fallido para felipe desde la IP 172.22.32.10');
INSERT INTO `glpi_events` VALUES ('263','-1','system','2017-08-10 10:12:05','login','3','Inicio de sesión fallido para  desde la IP 172.22.32.10');
INSERT INTO `glpi_events` VALUES ('264','-1','system','2017-08-10 10:12:45','login','3','felipe.becerra inicio de sesión desde la IP 172.22.32.10');
INSERT INTO `glpi_events` VALUES ('265','-1','system','2017-08-10 10:36:58','login','3','felipe.becerra inicio de sesión desde la IP 172.22.32.10');
INSERT INTO `glpi_events` VALUES ('266','-1','system','2017-08-10 10:38:44','login','3','felipe.becerra inicio de sesión desde la IP 172.22.0.95');
INSERT INTO `glpi_events` VALUES ('267','1','ComputerModel','2017-08-10 10:43:35','setup','4','felipe.becerra agrega el elemento Acer-Aspire-E5-471');
INSERT INTO `glpi_events` VALUES ('268','2','ComputerModel','2017-08-10 10:43:59','setup','4','felipe.becerra agrega el elemento Acer_Aspire-V5-131');
INSERT INTO `glpi_events` VALUES ('269','3','ComputerModel','2017-08-10 10:44:10','setup','4','felipe.becerra agrega el elemento Acer_Aspire-4935');
INSERT INTO `glpi_events` VALUES ('270','4','ComputerModel','2017-08-10 10:44:35','setup','4','felipe.becerra agrega el elemento Lenovo_ThinkCentre-M72e');
INSERT INTO `glpi_events` VALUES ('271','5','ComputerModel','2017-08-10 10:44:48','setup','4','felipe.becerra agrega el elemento Lenovo_ThinkPad-SL410');
INSERT INTO `glpi_events` VALUES ('272','6','ComputerModel','2017-08-10 10:45:14','setup','4','felipe.becerra agrega el elemento Lenovo_C50-30');
INSERT INTO `glpi_events` VALUES ('273','7','ComputerModel','2017-08-10 10:46:04','setup','4','felipe.becerra agrega el elemento Lenovo_ThinkCentre-E73');
INSERT INTO `glpi_events` VALUES ('274','8','ComputerModel','2017-08-10 10:46:16','setup','4','felipe.becerra agrega el elemento Lenovo_ThinkCentre-M700');
INSERT INTO `glpi_events` VALUES ('275','9','ComputerModel','2017-08-10 10:46:34','setup','4','felipe.becerra agrega el elemento Lenovo_IdeaPad-310');
INSERT INTO `glpi_events` VALUES ('276','10','ComputerModel','2017-08-10 10:46:46','setup','4','felipe.becerra agrega el elemento Lenovo_IdeaPad-510');
INSERT INTO `glpi_events` VALUES ('277','11','ComputerModel','2017-08-10 10:47:01','setup','4','felipe.becerra agrega el elemento Lenovo_G40-80');
INSERT INTO `glpi_events` VALUES ('278','12','ComputerModel','2017-08-10 10:47:21','setup','4','felipe.becerra agrega el elemento Dell_Optiplex-745');
INSERT INTO `glpi_events` VALUES ('279','13','ComputerModel','2017-08-10 10:47:41','setup','4','felipe.becerra agrega el elemento Dell_Optiplex-990');
INSERT INTO `glpi_events` VALUES ('280','14','ComputerModel','2017-08-10 10:48:01','setup','4','felipe.becerra agrega el elemento Dell_Optiplex-9010');
INSERT INTO `glpi_events` VALUES ('281','15','ComputerModel','2017-08-10 10:48:14','setup','4','felipe.becerra agrega el elemento HP_Compaq-6005-Pro-SFF');
INSERT INTO `glpi_events` VALUES ('282','16','ComputerModel','2017-08-10 10:48:27','setup','4','felipe.becerra agrega el elemento HP_Compaq-dc5750-SFF');
INSERT INTO `glpi_events` VALUES ('283','17','ComputerModel','2017-08-10 10:49:39','setup','4','felipe.becerra agrega el elemento HP_AIO-20R006LA');
INSERT INTO `glpi_events` VALUES ('284','18','ComputerModel','2017-08-10 10:49:55','setup','4','felipe.becerra agrega el elemento HP_AIO-23R003LA');
INSERT INTO `glpi_events` VALUES ('285','19','ComputerModel','2017-08-10 10:53:50','setup','4','felipe.becerra agrega el elemento Sure_GA-G41MT-S2');
INSERT INTO `glpi_events` VALUES ('286','20','ComputerModel','2017-08-10 10:54:11','setup','4','felipe.becerra agrega el elemento Sure_GA-G31M-S2C');
INSERT INTO `glpi_events` VALUES ('287','21','ComputerModel','2017-08-10 10:55:00','setup','4','felipe.becerra agrega el elemento Sure_GA-H61M-D2P-B3');
INSERT INTO `glpi_events` VALUES ('288','22','ComputerModel','2017-08-10 10:55:19','setup','4','felipe.becerra agrega el elemento Sure_945G');
INSERT INTO `glpi_events` VALUES ('289','23','ComputerModel','2017-08-10 10:55:41','setup','4','felipe.becerra agrega el elemento Sure_ECS-945GZT-M');
INSERT INTO `glpi_events` VALUES ('290','24','ComputerModel','2017-08-10 10:58:59','setup','4','felipe.becerra agrega el elemento Sure_ECS-H61H2-M3');
INSERT INTO `glpi_events` VALUES ('291','25','ComputerModel','2017-08-10 10:59:16','setup','4','felipe.becerra agrega el elemento Sure_Intel-DG31PR');
INSERT INTO `glpi_events` VALUES ('292','65','PrinterModel','2017-08-10 11:02:11','setup','4','felipe.becerra agrega el elemento HP OfficeJet 7612');
INSERT INTO `glpi_events` VALUES ('293','26','ComputerModel','2017-08-10 11:04:55','setup','4','felipe.becerra agrega el elemento HP Color LaserJet MFP M277dw');
INSERT INTO `glpi_events` VALUES ('294','27','ComputerModel','2017-08-10 11:05:28','setup','4','felipe.becerra agrega el elemento HP OfficeJet 7612');
INSERT INTO `glpi_events` VALUES ('295','28','ComputerModel','2017-08-10 11:06:11','setup','4','felipe.becerra agrega el elemento HP OfficeJet Pro 8620');
INSERT INTO `glpi_events` VALUES ('296','66','PrinterModel','2017-08-10 11:06:49','setup','4','felipe.becerra agrega el elemento HP OfficeJet Pro 8620');
INSERT INTO `glpi_events` VALUES ('297','28','ComputerModel','2017-08-10 11:06:53','setup','4','felipe.becerra elimina un elemento');
INSERT INTO `glpi_events` VALUES ('298','67','PrinterModel','2017-08-10 11:07:10','setup','4','felipe.becerra agrega el elemento HP OfficeJet 7612');
INSERT INTO `glpi_events` VALUES ('299','27','ComputerModel','2017-08-10 11:07:13','setup','4','felipe.becerra elimina un elemento');
INSERT INTO `glpi_events` VALUES ('300','68','PrinterModel','2017-08-10 11:07:30','setup','4','felipe.becerra agrega el elemento HP Color LaserJet MFP M277dw');
INSERT INTO `glpi_events` VALUES ('301','26','ComputerModel','2017-08-10 11:07:35','setup','4','felipe.becerra elimina un elemento');
INSERT INTO `glpi_events` VALUES ('302','65','PrinterModel','2017-08-10 11:13:43','setup','4','felipe.becerra elimina un elemento');
INSERT INTO `glpi_events` VALUES ('303','1','PhoneModel','2017-08-10 11:25:19','setup','4','felipe.becerra agrega el elemento Alcatel 4018 ipTouch');
INSERT INTO `glpi_events` VALUES ('304','1','OperatingSystemArchitecture','2017-08-10 11:28:35','setup','4','felipe.becerra agrega el elemento x86');
INSERT INTO `glpi_events` VALUES ('305','2','OperatingSystemArchitecture','2017-08-10 11:28:46','setup','4','felipe.becerra agrega el elemento x64');
INSERT INTO `glpi_events` VALUES ('306','-1','system','2017-08-15 22:40:46','login','3','Inicio de sesión fallido para juan.correa desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('307','-1','system','2017-08-15 22:41:01','login','3','juan.correa inicio de sesión desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('308','11','users','2017-08-15 22:43:28','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('309','-1','system','2017-08-15 22:43:36','login','3','43157733 inicio de sesión desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('310','-1','system','2017-08-15 22:45:13','login','3','Inicio de sesión fallido para 71797978 desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('311','-1','system','2017-08-15 22:45:24','login','3','Inicio de sesión fallido para juan.correa desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('312','-1','system','2017-08-15 22:45:41','login','3','Inicio de sesión fallido para juan.correa2 desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('313','-1','system','2017-08-15 22:45:55','login','3','Inicio de sesión fallido para juan.correa2 desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('314','-1','system','2017-08-15 22:46:14','login','3','juan.correa inicio de sesión desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('315','3','TicketTemplate','2017-08-15 22:48:13','setup','4','juan.correa agrega el elemento Entornos virtuales');
INSERT INTO `glpi_events` VALUES ('316','3','ITILCategory','2017-08-15 22:48:28','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('317','2','notifications','2017-08-15 22:54:51','notification','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('318','-1','system','2017-08-15 22:56:51','login','3','43157733 inicio de sesión desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('319','1','tickettemplate','2017-08-15 22:59:21','maintain','4','juan.correa agregar campo predefinido');
INSERT INTO `glpi_events` VALUES ('320','1','tickettemplate','2017-08-15 22:59:35','maintain','4','juan.correa agregar campo predefinido');
INSERT INTO `glpi_events` VALUES ('321','1','tickettemplate','2017-08-15 22:59:50','maintain','4','juan.correa agregar campo predefinido');
INSERT INTO `glpi_events` VALUES ('322','1','tickettemplate','2017-08-15 22:59:58','maintain','4','juan.correa agregar campo predefinido');
INSERT INTO `glpi_events` VALUES ('323','22','ITILCategory','2017-08-15 23:04:42','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('324','2','notifications','2017-08-15 23:06:05','notification','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('325','-1','system','2017-08-15 23:07:55','login','3','43157733 inicio de sesión desde la IP 186.86.165.245');
INSERT INTO `glpi_events` VALUES ('326','3','TicketTemplate','2017-08-15 23:17:03','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('327','1','ticket','2017-08-15 23:57:38','tracking','4','43157733 agrega el elemento 1');
INSERT INTO `glpi_events` VALUES ('328','1','ticket','2017-08-15 23:59:29','tracking','4','43157733 actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('329','1','ticket','2017-08-16 00:00:23','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('330','1','ticket','2017-08-16 00:01:12','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('331','-1','system','2017-08-16 08:15:45','login','3','Inicio de sesión fallido para claudia.jaramillo desde la IP 172.22.34.109');
INSERT INTO `glpi_events` VALUES ('332','-1','system','2017-08-16 08:15:57','login','3','Inicio de sesión fallido para claudia.jaramillo desde la IP 172.22.34.109');
INSERT INTO `glpi_events` VALUES ('333','-1','system','2017-08-18 10:52:33','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('334','-1','system','2017-08-18 10:56:40','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('335','-1','system','2017-08-18 11:09:22','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('336','-1','system','2017-08-18 11:10:55','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('337','-1','system','2017-08-18 11:18:38','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('338','19','ITILCategory','2017-08-18 11:21:23','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('339','28','ITILCategory','2017-08-18 12:56:21','setup','4','juan.correa agrega el elemento Diseño de piezas gráfica');
INSERT INTO `glpi_events` VALUES ('340','11','users','2017-08-18 12:56:47','setup','4','juan.correa agrega un usuario a un grupo');
INSERT INTO `glpi_events` VALUES ('341','29','ITILCategory','2017-08-18 12:58:27','setup','4','juan.correa agrega el elemento Producción de video');
INSERT INTO `glpi_events` VALUES ('342','30','ITILCategory','2017-08-18 12:58:48','setup','4','juan.correa agrega el elemento Cubrimiento comunicacional de evento');
INSERT INTO `glpi_events` VALUES ('343','31','ITILCategory','2017-08-18 12:59:28','setup','4','juan.correa agrega el elemento Publicación en medios institucionales');
INSERT INTO `glpi_events` VALUES ('344','32','ITILCategory','2017-08-18 13:00:33','setup','4','juan.correa agrega el elemento Apoyo o coordinación de eventos');
INSERT INTO `glpi_events` VALUES ('345','33','ITILCategory','2017-08-18 13:00:49','setup','4','juan.correa agrega el elemento Cubrimiento comunicacional de evento');
INSERT INTO `glpi_events` VALUES ('346','34','ITILCategory','2017-08-18 13:01:17','setup','4','juan.correa agrega el elemento Producción periodística para boletines');
INSERT INTO `glpi_events` VALUES ('347','35','ITILCategory','2017-08-18 13:01:25','setup','4','juan.correa agrega el elemento Asesoría y consultoría en comunicaciones');
INSERT INTO `glpi_events` VALUES ('348','-1','system','2017-08-18 13:03:17','login','3','43157733 inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('349','-1','system','2017-08-18 13:03:51','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('350','11','users','2017-08-18 13:06:16','setup','4','juan.correa agrego un usuario a una entidad');
INSERT INTO `glpi_events` VALUES ('351','11','users','2017-08-18 13:06:25','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('352','-1','system','2017-08-18 13:06:34','login','3','43157733 inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('353','-1','system','2017-08-18 13:07:10','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('354','32','ITILCategory','2017-08-18 13:07:26','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('355','35','ITILCategory','2017-08-18 13:07:37','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('356','30','ITILCategory','2017-08-18 13:07:45','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('357','33','ITILCategory','2017-08-18 13:07:52','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('358','28','ITILCategory','2017-08-18 13:08:00','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('359','29','ITILCategory','2017-08-18 13:08:07','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('360','34','ITILCategory','2017-08-18 13:08:14','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('361','31','ITILCategory','2017-08-18 13:08:21','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('362','3','ITILCategory','2017-08-18 13:08:35','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('363','19','ITILCategory','2017-08-18 13:08:55','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('364','19','ITILCategory','2017-08-18 13:10:51','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('365','3','ITILCategory','2017-08-18 13:11:52','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('366','3','ITILCategory','2017-08-18 13:12:24','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('367','1','ITILCategory','2017-08-18 13:12:43','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('368','1','ITILCategory','2017-08-18 13:13:06','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('369','4','ITILCategory','2017-08-18 13:13:29','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('370','-1','system','2017-08-18 13:24:43','login','3','43157733 inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('371','-1','system','2017-11-02 15:09:35','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('372','-1','system','2017-11-02 15:13:30','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('373','-1','system','2017-11-02 15:13:37','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('374','-1','system','2017-11-02 15:14:38','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('375','8','users','2017-11-02 15:46:51','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('376','-1','system','2017-11-02 15:46:57','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('377','2','ticket','2017-11-02 15:48:00','tracking','4','prueba agrega el elemento 2');
INSERT INTO `glpi_events` VALUES ('378','-1','system','2017-11-03 11:25:33','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('379','-1','system','2017-11-03 11:26:41','login','3','Inicio de sesión fallido para juan.correa2 desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('380','-1','system','2017-11-03 11:27:02','login','3','Inicio de sesión fallido para  desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('381','-1','system','2017-11-03 11:27:14','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('382','2','ticket','2017-11-03 11:28:16','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('383','-1','system','2017-11-03 12:03:58','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('384','-1','system','2017-11-07 15:39:00','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('385','-1','system','2017-11-07 15:39:08','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('386','12','users','2017-11-07 15:41:31','setup','4','juan.correa agrega el elemento 43431665');
INSERT INTO `glpi_events` VALUES ('387','-1','system','2017-11-07 15:41:46','login','3','43431665 inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('388','-1','system','2017-11-07 15:43:07','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('389','13','users','2017-11-07 15:45:09','setup','4','juan.correa agrega el elemento 1017133754');
INSERT INTO `glpi_events` VALUES ('390','14','users','2017-11-07 15:46:31','setup','4','juan.correa agrega el elemento 43695135');
INSERT INTO `glpi_events` VALUES ('391','-1','system','2017-11-07 15:50:05','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('392','-1','system','2017-11-07 15:55:06','login','3','43431665 inicio de sesión desde la IP 172.22.33.99');
INSERT INTO `glpi_events` VALUES ('393','-1','system','2017-11-07 15:59:23','login','3','juan.correa inicio de sesión desde la IP 172.22.35.111');
INSERT INTO `glpi_events` VALUES ('394','15','users','2017-11-07 16:00:37','setup','4','juan.correa agrega el elemento 32258827');
INSERT INTO `glpi_events` VALUES ('395','-1','system','2017-11-07 16:00:44','login','3','32258827 inicio de sesión desde la IP 172.22.35.111');
INSERT INTO `glpi_events` VALUES ('396','-1','system','2017-11-07 16:02:35','login','3','juan.correa inicio de sesión desde la IP 172.22.35.111');
INSERT INTO `glpi_events` VALUES ('397','16','users','2017-11-07 16:03:49','setup','4','juan.correa agrega el elemento 1128395590');
INSERT INTO `glpi_events` VALUES ('398','-1','system','2017-11-07 16:03:55','login','3','1128395590 inicio de sesión desde la IP 172.22.35.111');
INSERT INTO `glpi_events` VALUES ('399','-1','system','2017-11-07 16:07:16','login','3','juan.correa inicio de sesión desde la IP 172.22.31.209');
INSERT INTO `glpi_events` VALUES ('400','17','users','2017-11-07 16:08:23','setup','4','juan.correa agrega el elemento 43075826');
INSERT INTO `glpi_events` VALUES ('401','-1','system','2017-11-07 16:08:31','login','3','43075826 inicio de sesión desde la IP 172.22.31.209');
INSERT INTO `glpi_events` VALUES ('402','3','ticket','2017-11-07 16:14:00','tracking','4','43075826 agrega el elemento 3');
INSERT INTO `glpi_events` VALUES ('403','-1','system','2017-11-07 16:14:43','login','3','43075826 inicio de sesión desde la IP 172.22.31.209');
INSERT INTO `glpi_events` VALUES ('404','-1','system','2017-11-07 16:59:43','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('405','4','ITILCategory','2017-11-07 17:02:43','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('406','4','ITILCategory','2017-11-07 17:03:42','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('407','-1','system','2017-11-08 09:48:56','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('408','-1','system','2017-11-08 10:11:13','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('409','-1','system','2017-11-08 18:03:22','login','3','Inicio de sesión fallido para 71363237 desde la IP 172.22.0.95');
INSERT INTO `glpi_events` VALUES ('410','-1','system','2017-11-08 22:36:59','login','3','Inicio de sesión fallido para juan.correa desde la IP 186.86.30.161');
INSERT INTO `glpi_events` VALUES ('411','-1','system','2017-11-08 22:37:26','login','3','juan.correa inicio de sesión desde la IP 186.86.30.161');
INSERT INTO `glpi_events` VALUES ('412','-1','system','2017-11-14 10:19:36','login','3','Inicio de sesión fallido para juana.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('413','-1','system','2017-11-14 10:19:53','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('414','-1','system','2017-11-14 10:20:02','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('415','-1','system','2017-11-14 10:27:06','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('416','13','users','2017-11-14 10:28:30','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('417','-1','system','2017-11-14 10:38:06','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('418','4','ticket','2017-11-14 10:40:42','tracking','4','43695135 agrega el elemento 4');
INSERT INTO `glpi_events` VALUES ('419','13','users','2017-11-14 10:41:21','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('420','2','users','2017-11-14 10:41:45','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('421','2','users','2017-11-14 10:41:56','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('422','-1','system','2017-11-14 12:12:48','login','3','Inicio de sesión fallido para paula.hincapie desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('423','-1','system','2017-11-14 15:46:01','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('424','78','Location','2017-11-14 15:59:42','setup','4','juan.correa agrega el elemento 33-232 Jefe Centro investigación');
INSERT INTO `glpi_events` VALUES ('425','47','Location','2017-11-14 16:00:28','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('426','78','Location','2017-11-14 16:00:48','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('427','47','Location','2017-11-14 16:01:03','setup','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('428','4','ticket','2017-11-14 16:04:18','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('429','4','ticket','2017-11-14 16:05:32','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('430','1','change','2017-11-14 16:06:07','maintain','4','juan.correa agrega el elemento Activación reporte en SISREC');
INSERT INTO `glpi_events` VALUES ('431','1','change','2017-11-14 16:06:32','maintain','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('432','1','change','2017-11-14 16:07:51','maintain','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('433','-1','system','2017-11-15 10:09:30','login','3','Inicio de sesión fallido para paula.hincapie desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('434','-1','system','2017-11-16 14:56:35','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('435','5','ticket','2017-11-16 14:59:13','tracking','4','43695135 agrega el elemento 5');
INSERT INTO `glpi_events` VALUES ('436','5','ticket','2017-11-16 15:01:42','tracking','4','43695135 actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('437','-1','system','2017-11-16 16:46:17','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('438','5','ticket','2017-11-16 16:48:47','tracking','4','juan.correa agrga unseguimiento');
INSERT INTO `glpi_events` VALUES ('439','5','ticket','2017-11-16 16:49:56','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('440','5','ticket','2017-11-16 16:51:52','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('441','5','ticket','2017-11-16 16:52:29','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('442','5','ticket','2017-11-16 16:53:00','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('443','-1','system','2017-11-23 14:47:38','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('444','6','ticket','2017-11-23 14:51:37','tracking','4','43695135 agrega el elemento 6');
INSERT INTO `glpi_events` VALUES ('445','-1','system','2017-11-23 15:47:21','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('446','-1','system','2017-11-24 14:35:57','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('447','6','ticket','2017-11-24 14:41:41','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('448','5','ticket','2017-11-24 14:42:59','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('449','-1','system','2017-11-28 10:57:53','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('450','7','ticket','2017-11-28 11:01:36','tracking','4','43695135 agrega el elemento 7');
INSERT INTO `glpi_events` VALUES ('451','-1','system','2017-11-28 11:09:24','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('452','8','ticket','2017-11-28 11:12:04','tracking','4','43695135 agrega el elemento 8');
INSERT INTO `glpi_events` VALUES ('453','-1','system','2017-11-29 14:27:16','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('454','9','ticket','2017-11-29 14:29:59','tracking','4','43695135 agrega el elemento 9');
INSERT INTO `glpi_events` VALUES ('455','-1','system','2017-12-05 10:25:19','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('456','10','ticket','2017-12-05 10:26:41','tracking','4','43695135 agrega el elemento 10');
INSERT INTO `glpi_events` VALUES ('457','-1','system','2017-12-05 13:48:45','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('458','11','ticket','2017-12-05 13:50:44','tracking','4','43695135 agrega el elemento 11');
INSERT INTO `glpi_events` VALUES ('459','-1','system','2017-12-06 14:00:06','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('460','12','ticket','2017-12-06 14:10:59','tracking','4','43695135 agrega el elemento 12');
INSERT INTO `glpi_events` VALUES ('461','-1','system','2017-12-06 14:18:38','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('462','12','ticket','2017-12-06 14:24:29','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('463','11','ticket','2017-12-06 14:30:21','tracking','4','juan.correa agrega una tarea');
INSERT INTO `glpi_events` VALUES ('464','11','ticket','2017-12-06 14:31:01','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('465','11','ticket','2017-12-06 14:31:58','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('466','9','ticket','2017-12-06 14:33:18','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('467','9','ticket','2017-12-06 14:34:38','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('468','8','ticket','2017-12-06 14:35:34','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('469','8','ticket','2017-12-06 14:36:29','tracking','4','juan.correa agrega una tarea');
INSERT INTO `glpi_events` VALUES ('470','7','ticket','2017-12-06 14:37:20','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('471','7','ticket','2017-12-06 14:37:42','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('472','7','ticket','2017-12-06 14:40:17','tracking','4','juan.correa agrega una tarea');
INSERT INTO `glpi_events` VALUES ('473','7','ticket','2017-12-06 14:40:28','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('474','11','ticket','2017-12-06 14:44:06','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('475','11','ticket','2017-12-06 14:50:41','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('476','7','ticket','2017-12-06 14:51:12','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('477','8','ticket','2017-12-06 14:51:52','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('478','10','ticket','2017-12-06 15:02:44','tracking','4','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('479','-1','system','2017-12-11 09:09:11','login','3','Inicio de sesión fallido para raul.munoz desde la IP 172.22.39.173');
INSERT INTO `glpi_events` VALUES ('480','-1','system','2017-12-11 09:10:15','login','3','Inicio de sesión fallido para raul.munoz desde la IP 172.22.39.173');
INSERT INTO `glpi_events` VALUES ('481','-1','system','2017-12-11 09:10:34','login','3','Inicio de sesión fallido para raul.munoz desde la IP 172.22.39.173');
INSERT INTO `glpi_events` VALUES ('482','-1','system','2017-12-11 10:34:52','login','3','43695135 inicio de sesión desde la IP 172.22.31.173');
INSERT INTO `glpi_events` VALUES ('483','-1','system','2017-12-12 10:26:22','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('484','-1','system','2017-12-20 15:00:36','login','3','Inicio de sesión fallido para 71363237 desde la IP 190.251.238.104');
INSERT INTO `glpi_events` VALUES ('485','-1','system','2017-12-20 15:55:24','login','3','Inicio de sesión fallido para alberto.lopez desde la IP 190.251.238.104');
INSERT INTO `glpi_events` VALUES ('486','-1','system','2017-12-20 15:55:36','login','3','Inicio de sesión fallido para 71363237 desde la IP 190.251.238.104');
INSERT INTO `glpi_events` VALUES ('487','-1','system','2017-12-22 17:54:38','login','3','Inicio de sesión fallido para juan.correa desde la IP 186.86.31.98');
INSERT INTO `glpi_events` VALUES ('488','-1','system','2017-12-22 17:59:13','login','3','Inicio de sesión fallido para juan.correa desde la IP 186.86.31.98');
INSERT INTO `glpi_events` VALUES ('489','-1','system','2017-12-22 17:59:30','login','3','juan.correa inicio de sesión desde la IP 186.86.31.98');
INSERT INTO `glpi_events` VALUES ('490','9','users','2017-12-22 18:02:41','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('491','-1','system','2018-01-12 11:50:15','login','3','tech inicio de sesión desde la IP 190.131.201.196');
INSERT INTO `glpi_events` VALUES ('492','-1','system','2018-01-12 11:50:25','login','3','Inicio de sesión fallido para glpi desde la IP 190.131.201.196');
INSERT INTO `glpi_events` VALUES ('493','-1','system','2018-01-12 11:50:35','login','3','Inicio de sesión fallido para admin desde la IP 190.131.201.196');
INSERT INTO `glpi_events` VALUES ('494','-1','system','2018-01-17 21:01:02','login','3','Inicio de sesión fallido para Andres.guerra desde la IP 181.33.147.120');
INSERT INTO `glpi_events` VALUES ('495','-1','system','2018-01-18 16:39:49','login','3','Inicio de sesión fallido para  desde la IP 172.22.33.97');
INSERT INTO `glpi_events` VALUES ('496','-1','system','2018-01-18 16:40:10','login','3','Inicio de sesión fallido para 71726029 desde la IP 172.22.33.97');
INSERT INTO `glpi_events` VALUES ('497','-1','system','2018-01-24 15:10:06','login','3','Inicio de sesión fallido para 71797978 desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('498','-1','system','2018-01-24 15:12:19','login','3','Inicio de sesión fallido para 71797978 desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('499','-1','system','2018-01-24 15:12:31','login','3','Inicio de sesión fallido para admin desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('500','-1','system','2018-01-24 15:12:45','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('501','7','users','2018-01-24 15:19:56','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('502','-1','system','2018-01-29 15:37:14','login','3','Inicio de sesión fallido para 43626346 desde la IP 181.51.116.139');
INSERT INTO `glpi_events` VALUES ('503','-1','system','2018-01-29 18:06:28','login','3','Inicio de sesión fallido para glpi desde la IP 172.16.20.12');
INSERT INTO `glpi_events` VALUES ('504','-1','system','2018-02-02 08:38:56','login','3','Inicio de sesión fallido para jaider.diaz desde la IP 186.159.80.137');
INSERT INTO `glpi_events` VALUES ('505','-1','system','2018-02-02 08:40:44','login','3','Inicio de sesión fallido para jaider.diaz desde la IP 186.159.80.137');
INSERT INTO `glpi_events` VALUES ('506','-1','system','2018-02-13 15:16:34','login','3','Inicio de sesión fallido para jedison.castano@udea.edu.co desde la IP 172.22.39.229');
INSERT INTO `glpi_events` VALUES ('507','-1','system','2018-02-21 22:40:00','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('508','-1','system','2018-02-21 22:41:57','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('509','-1','system','2018-02-21 22:42:45','login','3','Inicio de sesión fallido para fnsp123 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('510','-1','system','2018-02-21 22:43:33','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('511','-1','system','2018-02-21 22:47:55','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('512','-1','system','2018-02-21 22:51:23','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('513','-1','system','2018-02-21 23:02:02','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('514','-1','system','2018-02-21 23:03:29','login','3','Inicio de sesión fallido para 43521o79 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('515','-1','system','2018-02-21 23:47:49','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('516','-1','system','2018-02-21 23:48:23','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('517','-1','system','2018-02-21 23:48:50','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('518','-1','system','2018-02-21 23:49:10','login','3','Inicio de sesión fallido para 43521079 desde la IP 190.85.133.81');
INSERT INTO `glpi_events` VALUES ('519','-1','system','2018-02-28 10:13:40','login','3','Inicio de sesión fallido para juan.correa2 desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('520','-1','system','2018-02-28 10:14:02','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('521','-1','system','2018-02-28 10:15:41','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('522','8','users','2018-02-28 10:17:39','setup','5','juan.correa actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('523','-1','system','2018-02-28 10:17:50','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('524','13','ticket','2018-02-28 10:20:35','tracking','4','prueba agrega el elemento 13');
INSERT INTO `glpi_events` VALUES ('525','-1','system','2018-02-28 10:21:28','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('526','-1','system','2018-02-28 10:21:38','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('527','-1','system','2018-02-28 10:31:50','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('528','-1','system','2018-03-01 13:20:28','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('529','-1','system','2018-03-01 13:21:45','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('530','-1','system','2018-03-01 13:23:53','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('531','-1','system','2018-03-01 13:29:13','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('532','-1','system','2018-03-01 13:33:45','login','3','Inicio de sesión fallido para juan.correa desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('533','-1','system','2018-03-01 13:33:53','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('534','-1','system','2018-03-01 18:47:03','login','3','Inicio de sesión fallido para glpi desde la IP 181.141.172.213');
INSERT INTO `glpi_events` VALUES ('535','-1','system','2018-03-01 18:47:28','login','3','post-only inicio de sesión desde la IP 181.141.172.213');
INSERT INTO `glpi_events` VALUES ('536','-1','system','2018-03-01 18:47:49','login','3','Inicio de sesión fallido para post-only desde la IP 181.141.172.213');
INSERT INTO `glpi_events` VALUES ('537','-1','system','2018-03-02 13:45:33','login','3','juan.correa inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('538','-1','system','2018-03-02 13:51:28','login','3','prueba inicio de sesión desde la IP 172.22.133.1');
INSERT INTO `glpi_events` VALUES ('539','-1','system','2018-03-20 20:05:23','login','3','Inicio de sesión fallido para glpi desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('540','-1','system','2018-03-20 20:06:29','login','3','Inicio de sesión fallido para post-only desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('541','-1','system','2018-03-20 20:06:41','login','3','Inicio de sesión fallido para post-only desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('542','-1','system','2018-03-20 20:08:25','login','3','post-only inicio de sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('543','-1','system','2018-03-20 20:08:34','login','3','Inicio de sesión fallido para post-only desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('544','-1','system','2018-03-20 22:50:14','login','3','Inicio de sesión fallido para glpi desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('545','-1','system','2018-03-20 22:50:39','login','3','Inicio de sesión fallido para $2y$10$eOKyUIze275BWCrst4O5ZewF14dkwmVvykx2KKfLo3eYZF0.DJuGK desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('546','-1','system','2018-03-20 22:54:09','login','3','paola inicio de sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('547','-1','system','2018-03-22 20:14:32','login','3','paola inicio de sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('548','4','TicketTemplate','2018-03-22 22:51:33','setup','4','paola agrega el elemento Soporte técnico');
INSERT INTO `glpi_events` VALUES ('549','5','TicketTemplate','2018-03-22 22:51:50','setup','4','paola agrega el elemento Sistemas');
INSERT INTO `glpi_events` VALUES ('550','6','TicketTemplate','2018-03-22 22:52:04','setup','4','paola agrega el elemento Comunicaciones');
INSERT INTO `glpi_events` VALUES ('551','-1','system','2018-04-02 15:28:28','login','3','paola inicio de sesión desde la IP ::1');
INSERT INTO `glpi_events` VALUES ('552','2','users','2018-04-02 15:32:23','setup','5','paola actualiza un elemento');
INSERT INTO `glpi_events` VALUES ('553','-1','system','2018-04-02 15:32:42','login','3','paola inicio de sesión desde la IP ::1');

### Dump table glpi_fieldblacklists

DROP TABLE IF EXISTS `glpi_fieldblacklists`;
CREATE TABLE `glpi_fieldblacklists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_fieldunicities

DROP TABLE IF EXISTS `glpi_fieldunicities`;
CREATE TABLE `glpi_fieldunicities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `fields` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `action_refuse` tinyint(1) NOT NULL DEFAULT '0',
  `action_notify` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Stores field unicity criterias';


### Dump table glpi_filesystems

DROP TABLE IF EXISTS `glpi_filesystems`;
CREATE TABLE `glpi_filesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_filesystems` VALUES ('1','ext',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('2','ext2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('3','ext3',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('4','ext4',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('5','FAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('6','FAT32',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('7','VFAT',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('8','HFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('9','HPFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('10','HTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('11','JFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('12','JFS2',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('13','NFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('14','NTFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('15','ReiserFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('16','SMBFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('17','UDF',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('18','UFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('19','XFS',NULL,NULL,NULL);
INSERT INTO `glpi_filesystems` VALUES ('20','ZFS',NULL,NULL,NULL);

### Dump table glpi_fqdns

DROP TABLE IF EXISTS `glpi_fqdns`;
CREATE TABLE `glpi_fqdns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `fqdn` (`fqdn`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups

DROP TABLE IF EXISTS `glpi_groups`;
CREATE TABLE `glpi_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `ldap_field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ldap_value` text COLLATE utf8_unicode_ci,
  `ldap_group_dn` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_requester` tinyint(1) NOT NULL DEFAULT '1',
  `is_assign` tinyint(1) NOT NULL DEFAULT '1',
  `is_notify` tinyint(1) NOT NULL DEFAULT '1',
  `is_itemgroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_usergroup` tinyint(1) NOT NULL DEFAULT '1',
  `is_manager` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  `is_task` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `ldap_field` (`ldap_field`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `ldap_value` (`ldap_value`(200)),
  KEY `ldap_group_dn` (`ldap_group_dn`(200)),
  KEY `groups_id` (`groups_id`),
  KEY `is_requester` (`is_requester`),
  KEY `is_assign` (`is_assign`),
  KEY `is_notify` (`is_notify`),
  KEY `is_itemgroup` (`is_itemgroup`),
  KEY `is_usergroup` (`is_usergroup`),
  KEY `is_manager` (`is_manager`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_groups` VALUES ('1','0','0','Soporte tecnico','',NULL,NULL,NULL,'2017-06-30 11:00:21','0','Soporte tecnico','1','[]','{\"1\":\"1\"}','1','1','1','1','1','1','2017-06-30 11:00:21','0');
INSERT INTO `glpi_groups` VALUES ('2','0','0','Sistemas de información','',NULL,NULL,NULL,'2017-06-30 11:00:44','0','Sistemas de información','1','[]','{\"2\":\"2\"}','1','1','1','1','1','1','2017-06-30 11:00:44','0');
INSERT INTO `glpi_groups` VALUES ('3','0','0','Entornos virtuales','',NULL,NULL,NULL,'2017-06-30 11:00:56','0','Entornos virtuales','1','[]','{\"3\":\"3\"}','1','1','1','1','1','1','2017-06-30 11:00:56','0');
INSERT INTO `glpi_groups` VALUES ('4','0','0','Portal Web','',NULL,NULL,NULL,'2017-06-30 11:01:08','0','Portal Web','1',NULL,NULL,'1','1','1','1','1','1','2017-06-30 11:01:08','0');
INSERT INTO `glpi_groups` VALUES ('5','0','0','Solicitante','',NULL,NULL,NULL,'2017-07-12 11:08:37','0','Solicitante','1','[]','{\"5\":\"5\"}','1','1','1','1','1','1','2017-07-12 11:08:37','0');
INSERT INTO `glpi_groups` VALUES ('6','0','0','Comunicaciones','Atención a solicitudes de área de comunicaciones de la FNSP',NULL,NULL,NULL,'2017-07-27 11:27:42','0','Comunicaciones','1','[]','{\"6\":\"6\"}','1','1','1','1','1','1','2017-07-27 11:27:42','0');

### Dump table glpi_groups_knowbaseitems

DROP TABLE IF EXISTS `glpi_groups_knowbaseitems`;
CREATE TABLE `glpi_groups_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_problems

DROP TABLE IF EXISTS `glpi_groups_problems`;
CREATE TABLE `glpi_groups_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_reminders

DROP TABLE IF EXISTS `glpi_groups_reminders`;
CREATE TABLE `glpi_groups_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_rssfeeds

DROP TABLE IF EXISTS `glpi_groups_rssfeeds`;
CREATE TABLE `glpi_groups_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `groups_id` (`groups_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_tickets

DROP TABLE IF EXISTS `glpi_groups_tickets`;
CREATE TABLE `glpi_groups_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`groups_id`),
  KEY `group` (`groups_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_groups_users

DROP TABLE IF EXISTS `glpi_groups_users`;
CREATE TABLE `glpi_groups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `is_manager` tinyint(1) NOT NULL DEFAULT '0',
  `is_userdelegate` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`groups_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_manager` (`is_manager`),
  KEY `is_userdelegate` (`is_userdelegate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_groups_users` VALUES ('1','7','3','0','1','0');
INSERT INTO `glpi_groups_users` VALUES ('2','6','3','0','0','1');
INSERT INTO `glpi_groups_users` VALUES ('3','7','2','0','1','0');
INSERT INTO `glpi_groups_users` VALUES ('4','2','2','0','0','1');
INSERT INTO `glpi_groups_users` VALUES ('8','8','1','0','0','0');
INSERT INTO `glpi_groups_users` VALUES ('7','8','5','0','0','0');
INSERT INTO `glpi_groups_users` VALUES ('9','11','6','0','1','1');

### Dump table glpi_holidays

DROP TABLE IF EXISTS `glpi_holidays`;
CREATE TABLE `glpi_holidays` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `is_perpetual` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `is_perpetual` (`is_perpetual`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_infocoms

DROP TABLE IF EXISTS `glpi_infocoms`;
CREATE TABLE `glpi_infocoms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `buy_date` date DEFAULT NULL,
  `use_date` date DEFAULT NULL,
  `warranty_duration` int(11) NOT NULL DEFAULT '0',
  `warranty_info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `order_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivery_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `immo_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `warranty_value` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `sink_time` int(11) NOT NULL DEFAULT '0',
  `sink_type` int(11) NOT NULL DEFAULT '0',
  `sink_coeff` float NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `bill` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `alert` int(11) NOT NULL DEFAULT '0',
  `order_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `inventory_date` date DEFAULT NULL,
  `warranty_date` date DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `decommission_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`),
  KEY `buy_date` (`buy_date`),
  KEY `alert` (`alert`),
  KEY `budgets_id` (`budgets_id`),
  KEY `suppliers_id` (`suppliers_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_interfacetypes

DROP TABLE IF EXISTS `glpi_interfacetypes`;
CREATE TABLE `glpi_interfacetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_interfacetypes` VALUES ('1','IDE',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('2','SATA',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('3','SCSI',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('4','USB',NULL,NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('5','AGP','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('6','PCI','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('7','PCIe','',NULL,NULL);
INSERT INTO `glpi_interfacetypes` VALUES ('8','PCI-X','',NULL,NULL);

### Dump table glpi_ipaddresses

DROP TABLE IF EXISTS `glpi_ipaddresses`;
CREATE TABLE `glpi_ipaddresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `binary_0` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_1` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_2` int(10) unsigned NOT NULL DEFAULT '0',
  `binary_3` int(10) unsigned NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `mainitems_id` int(11) NOT NULL DEFAULT '0',
  `mainitemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `textual` (`name`),
  KEY `binary` (`binary_0`,`binary_1`,`binary_2`,`binary_3`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `mainitem` (`mainitemtype`,`mainitems_id`,`is_deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipaddresses_ipnetworks

DROP TABLE IF EXISTS `glpi_ipaddresses_ipnetworks`;
CREATE TABLE `glpi_ipaddresses_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipaddresses_id` int(11) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`ipaddresses_id`,`ipnetworks_id`),
  KEY `ipnetworks_id` (`ipnetworks_id`),
  KEY `ipaddresses_id` (`ipaddresses_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipnetworks

DROP TABLE IF EXISTS `glpi_ipnetworks`;
CREATE TABLE `glpi_ipnetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `addressable` tinyint(1) NOT NULL DEFAULT '0',
  `version` tinyint(3) unsigned DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_0` int(10) unsigned NOT NULL DEFAULT '0',
  `address_1` int(10) unsigned NOT NULL DEFAULT '0',
  `address_2` int(10) unsigned NOT NULL DEFAULT '0',
  `address_3` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `netmask_0` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_1` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_2` int(10) unsigned NOT NULL DEFAULT '0',
  `netmask_3` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gateway_0` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_1` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_2` int(10) unsigned NOT NULL DEFAULT '0',
  `gateway_3` int(10) unsigned NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `network_definition` (`entities_id`,`address`,`netmask`),
  KEY `address` (`address_0`,`address_1`,`address_2`,`address_3`),
  KEY `netmask` (`netmask_0`,`netmask_1`,`netmask_2`,`netmask_3`),
  KEY `gateway` (`gateway_0`,`gateway_1`,`gateway_2`,`gateway_3`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ipnetworks_vlans

DROP TABLE IF EXISTS `glpi_ipnetworks_vlans`;
CREATE TABLE `glpi_ipnetworks_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ipnetworks_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `link` (`ipnetworks_id`,`vlans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecases

DROP TABLE IF EXISTS `glpi_items_devicecases`;
CREATE TABLE `glpi_items_devicecases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecases_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecases_id` (`devicecases_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicecontrols

DROP TABLE IF EXISTS `glpi_items_devicecontrols`;
CREATE TABLE `glpi_items_devicecontrols` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicecontrols_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicecontrols_id` (`devicecontrols_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicedrives

DROP TABLE IF EXISTS `glpi_items_devicedrives`;
CREATE TABLE `glpi_items_devicedrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicedrives_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicedrives_id` (`devicedrives_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicegraphiccards

DROP TABLE IF EXISTS `glpi_items_devicegraphiccards`;
CREATE TABLE `glpi_items_devicegraphiccards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicegraphiccards_id` int(11) NOT NULL DEFAULT '0',
  `memory` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicegraphiccards_id` (`devicegraphiccards_id`),
  KEY `specificity` (`memory`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceharddrives

DROP TABLE IF EXISTS `glpi_items_deviceharddrives`;
CREATE TABLE `glpi_items_deviceharddrives` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceharddrives_id` int(11) NOT NULL DEFAULT '0',
  `capacity` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceharddrives_id` (`deviceharddrives_id`),
  KEY `specificity` (`capacity`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicememories

DROP TABLE IF EXISTS `glpi_items_devicememories`;
CREATE TABLE `glpi_items_devicememories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicememories_id` int(11) NOT NULL DEFAULT '0',
  `size` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicememories_id` (`devicememories_id`),
  KEY `specificity` (`size`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicemotherboards

DROP TABLE IF EXISTS `glpi_items_devicemotherboards`;
CREATE TABLE `glpi_items_devicemotherboards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicemotherboards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicemotherboards_id` (`devicemotherboards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicenetworkcards

DROP TABLE IF EXISTS `glpi_items_devicenetworkcards`;
CREATE TABLE `glpi_items_devicenetworkcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicenetworkcards_id` (`devicenetworkcards_id`),
  KEY `specificity` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepcis

DROP TABLE IF EXISTS `glpi_items_devicepcis`;
CREATE TABLE `glpi_items_devicepcis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepcis_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepcis_id` (`devicepcis_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicepowersupplies

DROP TABLE IF EXISTS `glpi_items_devicepowersupplies`;
CREATE TABLE `glpi_items_devicepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicepowersupplies_id` (`devicepowersupplies_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_deviceprocessors

DROP TABLE IF EXISTS `glpi_items_deviceprocessors`;
CREATE TABLE `glpi_items_deviceprocessors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deviceprocessors_id` int(11) NOT NULL DEFAULT '0',
  `frequency` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `nbcores` int(11) DEFAULT NULL,
  `nbthreads` int(11) DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `deviceprocessors_id` (`deviceprocessors_id`),
  KEY `specificity` (`frequency`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `nbcores` (`nbcores`),
  KEY `nbthreads` (`nbthreads`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_devicesoundcards

DROP TABLE IF EXISTS `glpi_items_devicesoundcards`;
CREATE TABLE `glpi_items_devicesoundcards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `devicesoundcards_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `busID` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `computers_id` (`items_id`),
  KEY `devicesoundcards_id` (`devicesoundcards_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `serial` (`serial`),
  KEY `busID` (`busID`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_problems

DROP TABLE IF EXISTS `glpi_items_problems`;
CREATE TABLE `glpi_items_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_projects

DROP TABLE IF EXISTS `glpi_items_projects`;
CREATE TABLE `glpi_items_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_items_tickets

DROP TABLE IF EXISTS `glpi_items_tickets`;
CREATE TABLE `glpi_items_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_itilcategories

DROP TABLE IF EXISTS `glpi_itilcategories`;
CREATE TABLE `glpi_itilcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `tickettemplates_id_incident` int(11) NOT NULL DEFAULT '0',
  `tickettemplates_id_demand` int(11) NOT NULL DEFAULT '0',
  `is_incident` int(11) NOT NULL DEFAULT '1',
  `is_request` int(11) NOT NULL DEFAULT '1',
  `is_problem` int(11) NOT NULL DEFAULT '1',
  `is_change` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `tickettemplates_id_incident` (`tickettemplates_id_incident`),
  KEY `tickettemplates_id_demand` (`tickettemplates_id_demand`),
  KEY `is_incident` (`is_incident`),
  KEY `is_request` (`is_request`),
  KEY `is_problem` (`is_problem`),
  KEY `is_change` (`is_change`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_itilcategories` VALUES ('1','0','1','0','Sistemas','Sistemas','','1','0','2','2',NULL,'{\"1\":\"1\",\"2\":\"2\",\"9\":\"9\",\"11\":\"11\",\"10\":\"10\",\"12\":\"12\",\"8\":\"8\"}','0','0','0','0','0','0','0','2017-08-18 13:12:43','2017-07-12 10:41:12');
INSERT INTO `glpi_itilcategories` VALUES ('2','0','0','1','Activación y modificación de usuarios de un sistema','Sistemas > Activación y modificación de usuarios de un sistema','','2','0','2','0',NULL,'{\"2\":\"2\"}','1','0','0','1','1','1','1','2017-07-26 10:05:57','2017-07-12 10:41:48');
INSERT INTO `glpi_itilcategories` VALUES ('3','0','1','0','Entornos virtuales','Entornos virtuales','','1','0','10','3',NULL,'{\"3\":\"3\",\"23\":\"23\",\"22\":\"22\",\"5\":\"5\",\"21\":\"21\",\"20\":\"20\",\"6\":\"6\",\"18\":\"18\",\"7\":\"7\",\"17\":\"17\"}','0','0','0','0','0','0','0','2017-08-18 13:12:24','2017-07-25 16:13:03');
INSERT INTO `glpi_itilcategories` VALUES ('4','0','0','0','Soporte técnico','Soporte técnico','','1','0','6','1',NULL,'{\"4\":\"4\",\"15\":\"15\",\"13\":\"13\",\"14\":\"14\",\"24\":\"24\",\"25\":\"25\",\"16\":\"16\",\"26\":\"26\",\"27\":\"27\"}','0','0','0','0','0','0','0','2017-11-07 17:03:42','2017-07-25 16:13:29');
INSERT INTO `glpi_itilcategories` VALUES ('5','0','0','3','Capacitación EVA y Moodle','Entornos virtuales > Capacitación EVA y Moodle','','2','0','10','3',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 00:25:45','2017-07-26 00:25:45');
INSERT INTO `glpi_itilcategories` VALUES ('6','0','0','3','Montaje de curso','Entornos virtuales > Montaje de curso','','2','0','10','3',NULL,'{\"6\":\"6\"}','1','0','0','1','1','1','1','2017-07-26 09:49:47','2017-07-26 00:26:42');
INSERT INTO `glpi_itilcategories` VALUES ('7','0','0','3','Publicación Portal Web U de A','Entornos virtuales > Publicación Portal Web U de A','','2','0','10','4',NULL,'{\"7\":\"7\"}','1','0','0','1','1','1','1','2017-07-26 09:48:36','2017-07-26 00:27:24');
INSERT INTO `glpi_itilcategories` VALUES ('20','0','0','3','Implementación recurso educativo','Entornos virtuales > Implementación recurso educativo','','2','0','10','3',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 09:50:54','2017-07-26 09:50:54');
INSERT INTO `glpi_itilcategories` VALUES ('8','0','0','1','Soporte de software','Sistemas > Soporte de software','','2','0','2','2',NULL,'{\"8\":\"8\"}','1','0','0','1','1','1','1','2017-07-26 10:02:25','2017-07-26 00:28:37');
INSERT INTO `glpi_itilcategories` VALUES ('9','0','0','1','Actualizar información en base de datos','Sistemas > Actualizar información en base de datos','','2','0','2','2',NULL,'{\"9\":\"9\"}','1','0','0','1','1','1','1','2017-07-26 10:04:18','2017-07-26 00:29:06');
INSERT INTO `glpi_itilcategories` VALUES ('10','0','0','1','Generar informe','Sistemas > Generar informe','','2','0','2','2',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 00:29:24','2017-07-26 00:29:24');
INSERT INTO `glpi_itilcategories` VALUES ('11','0','0','1','Capacitar sobre uso de un sistema','Sistemas > Capacitar sobre uso de un sistema','','2','0','2','2',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 00:29:46','2017-07-26 00:29:46');
INSERT INTO `glpi_itilcategories` VALUES ('12','0','0','1','Sistema fuera de linea','Sistemas > Sistema fuera de linea','','2','0','2','2',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 00:30:28','2017-07-26 00:30:28');
INSERT INTO `glpi_itilcategories` VALUES ('14','0','0','4','Instalar software','Soporte técnico > Instalar software','','2','0','6','1',NULL,'{\"14\":\"14\"}','1','0','0','1','1','1','1','2017-07-26 00:32:16','2017-07-26 00:32:16');
INSERT INTO `glpi_itilcategories` VALUES ('13','0','0','4','Impresora no funciona','Soporte técnico > Impresora no funciona','','2','0','6','1',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 00:31:58','2017-07-26 00:31:58');
INSERT INTO `glpi_itilcategories` VALUES ('15','0','0','4','Computador no funciona','Soporte técnico > Computador no funciona','','2','0','6','1',NULL,'{\"15\":\"15\"}','1','0','0','1','1','1','1','2017-07-26 00:32:34','2017-07-26 00:32:34');
INSERT INTO `glpi_itilcategories` VALUES ('16','0','0','4','Problemas de red','Soporte técnico > Problemas de red','','2','0','6','1',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 00:32:52','2017-07-26 00:32:52');
INSERT INTO `glpi_itilcategories` VALUES ('17','0','0','3','Reserva sala Webex y sala de videoconferencia 417','Entornos virtuales > Reserva sala Webex y sala de videoconferencia 417','','2','0','10','3',NULL,'{\"17\":\"17\"}','1','0','0','1','1','1','1','2017-07-26 09:56:54','2017-07-26 00:34:17');
INSERT INTO `glpi_itilcategories` VALUES ('18','0','0','3','Publicación portal Campus virtual Salud Pública CVSP','Entornos virtuales > Publicación portal Campus virtual Salud Pública CVSP','','2','0','10','4',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 09:45:11','2017-07-26 09:45:11');
INSERT INTO `glpi_itilcategories` VALUES ('19','0','1','0','Comunicaciones','Comunicaciones','','1','0','0','6',NULL,'{\"19\":\"19\",\"32\":\"32\",\"35\":\"35\",\"30\":\"30\",\"33\":\"33\",\"28\":\"28\",\"29\":\"29\",\"34\":\"34\",\"31\":\"31\"}','0','0','0','0','0','0','0','2017-08-18 13:10:51','2017-07-26 09:49:00');
INSERT INTO `glpi_itilcategories` VALUES ('21','0','0','3','Edición y ajustes curso EVA','Entornos virtuales > Edición y ajustes curso EVA','','2','0','10','3',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 09:54:57','2017-07-26 09:54:57');
INSERT INTO `glpi_itilcategories` VALUES ('22','0','0','3','Capacitación en Webex','Entornos virtuales > Capacitación en Webex','','2','0','10','3',NULL,'{\"22\":\"22\"}','1','3','0','1','1','1','1','2017-08-15 23:04:42','2017-07-26 09:55:20');
INSERT INTO `glpi_itilcategories` VALUES ('23','0','0','3','Apoyo en videoconferencia','Entornos virtuales > Apoyo en videoconferencia','','2','0','10','3',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 09:57:28','2017-07-26 09:57:28');
INSERT INTO `glpi_itilcategories` VALUES ('24','0','0','4','Periferico no funciona','Soporte técnico > Periferico no funciona','','2','0','6','0',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 10:47:48','2017-07-26 10:47:48');
INSERT INTO `glpi_itilcategories` VALUES ('25','0','0','4','Problema de sistema operativo','Soporte técnico > Problema de sistema operativo','','2','0','6','0',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 10:49:17','2017-07-26 10:49:17');
INSERT INTO `glpi_itilcategories` VALUES ('26','0','0','4','Problemas de seguridad y virus','Soporte técnico > Problemas de seguridad y virus','','2','0','6','1',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 10:50:29','2017-07-26 10:50:29');
INSERT INTO `glpi_itilcategories` VALUES ('27','0','0','4','Problemas de software de aplicación','Soporte técnico > Problemas de software de aplicación','','2','0','6','1',NULL,NULL,'1','0','0','1','1','1','1','2017-07-26 10:51:38','2017-07-26 10:51:38');
INSERT INTO `glpi_itilcategories` VALUES ('29','0','0','19','Producción de video','Comunicaciones > Producción de video','','2','0','11','0',NULL,'{\"29\":\"29\"}','1','0','0','1','1','1','1','2017-08-18 13:08:07','2017-08-18 12:58:27');
INSERT INTO `glpi_itilcategories` VALUES ('28','0','0','19','Diseño de piezas gráfica','Comunicaciones > Diseño de piezas gráfica','','2','0','11','0',NULL,'{\"28\":\"28\"}','1','0','0','1','1','1','1','2017-08-18 13:08:00','2017-08-18 12:56:21');
INSERT INTO `glpi_itilcategories` VALUES ('30','0','0','19','Cubrimiento comunicacional de evento','Comunicaciones > Cubrimiento comunicacional de evento','','2','0','11','0',NULL,'{\"30\":\"30\"}','1','0','0','1','1','1','1','2017-08-18 13:07:45','2017-08-18 12:58:48');
INSERT INTO `glpi_itilcategories` VALUES ('31','0','0','19','Publicación en medios institucionales','Comunicaciones > Publicación en medios institucionales','','2','0','11','0',NULL,'{\"31\":\"31\"}','1','0','0','1','1','1','1','2017-08-18 13:08:21','2017-08-18 12:59:28');
INSERT INTO `glpi_itilcategories` VALUES ('32','0','0','19','Apoyo o coordinación de eventos','Comunicaciones > Apoyo o coordinación de eventos','','2','0','11','0',NULL,'{\"32\":\"32\"}','1','0','0','1','1','1','1','2017-08-18 13:07:26','2017-08-18 13:00:33');
INSERT INTO `glpi_itilcategories` VALUES ('33','0','0','19','Cubrimiento comunicacional de evento','Comunicaciones > Cubrimiento comunicacional de evento','','2','0','11','0',NULL,'{\"33\":\"33\"}','1','0','0','1','1','1','1','2017-08-18 13:07:52','2017-08-18 13:00:49');
INSERT INTO `glpi_itilcategories` VALUES ('34','0','0','19','Producción periodística para boletines','Comunicaciones > Producción periodística para boletines','','2','0','11','0',NULL,'{\"34\":\"34\"}','1','0','0','1','1','1','1','2017-08-18 13:08:14','2017-08-18 13:01:17');
INSERT INTO `glpi_itilcategories` VALUES ('35','0','0','19','Asesoría y consultoría en comunicaciones','Comunicaciones > Asesoría y consultoría en comunicaciones','','2','0','11','0',NULL,'{\"35\":\"35\"}','1','0','0','1','1','1','1','2017-08-18 13:07:37','2017-08-18 13:01:25');

### Dump table glpi_knowbaseitemcategories

DROP TABLE IF EXISTS `glpi_knowbaseitemcategories`;
CREATE TABLE `glpi_knowbaseitemcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`knowbaseitemcategories_id`,`name`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems

DROP TABLE IF EXISTS `glpi_knowbaseitems`;
CREATE TABLE `glpi_knowbaseitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitemcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  `is_faq` tinyint(1) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `view` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `knowbaseitemcategories_id` (`knowbaseitemcategories_id`),
  KEY `is_faq` (`is_faq`),
  KEY `date_mod` (`date_mod`),
  FULLTEXT KEY `fulltext` (`name`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_profiles

DROP TABLE IF EXISTS `glpi_knowbaseitems_profiles`;
CREATE TABLE `glpi_knowbaseitems_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitems_users

DROP TABLE IF EXISTS `glpi_knowbaseitems_users`;
CREATE TABLE `glpi_knowbaseitems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `knowbaseitems_id` (`knowbaseitems_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_knowbaseitemtranslations

DROP TABLE IF EXISTS `glpi_knowbaseitemtranslations`;
CREATE TABLE `glpi_knowbaseitemtranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `knowbaseitems_id` int(11) NOT NULL DEFAULT '0',
  `language` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `answer` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`knowbaseitems_id`,`language`),
  FULLTEXT KEY `fulltext` (`name`,`answer`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links

DROP TABLE IF EXISTS `glpi_links`;
CREATE TABLE `glpi_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `open_window` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_links_itemtypes

DROP TABLE IF EXISTS `glpi_links_itemtypes`;
CREATE TABLE `glpi_links_itemtypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `links_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`links_id`),
  KEY `links_id` (`links_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_locations

DROP TABLE IF EXISTS `glpi_locations`;
CREATE TABLE `glpi_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `building` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `room` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `altitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`entities_id`,`locations_id`,`name`),
  KEY `locations_id` (`locations_id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_locations` VALUES ('1','0','0','33-417 Area tecnologica','3','Piso 4 > 33-417 Area tecnologica','','2','{\"3\":\"3\"}','{\"1\":\"1\"}','33-417','33-417','','','','2017-07-25 15:26:56','2017-06-30 11:29:23');
INSERT INTO `glpi_locations` VALUES ('2','0','0','33-414 Soporte sistemas','3','Piso 4 > 33-414 Soporte sistemas',NULL,'2','{\"3\":\"3\"}','{\"2\":\"2\"}','33-414','33-414',NULL,NULL,NULL,'2017-07-25 15:27:07',NULL);
INSERT INTO `glpi_locations` VALUES ('3','0','0','Piso 4','0','Piso 4','','1','[]',NULL,'','','','','','2017-07-25 15:26:43','2017-07-25 15:26:43');
INSERT INTO `glpi_locations` VALUES ('4','0','0','33-406 Asistencia de planeación','3','Piso 4 > 33-406 Asistencia de planeación','','2',NULL,NULL,'33-406','33-406','','','','2017-07-25 15:27:52','2017-07-25 15:27:52');
INSERT INTO `glpi_locations` VALUES ('5','0','0','33-413 Posgrados','3','Piso 4 > 33-413 Posgrados','','2',NULL,NULL,'33-413','33-413','','','','2017-07-25 15:29:59','2017-07-25 15:29:59');
INSERT INTO `glpi_locations` VALUES ('6','0','0','33-418 Coordinación posgrados','3','Piso 4 > 33-418 Coordinación posgrados','','2',NULL,NULL,'33-418','33-418','','','','2017-07-25 15:30:25','2017-07-25 15:30:25');
INSERT INTO `glpi_locations` VALUES ('7','0','0','33-417A Sala Videoconferencia','3','Piso 4 > 33-417A Sala Videoconferencia','','2',NULL,NULL,'33-417A','33-417A','','','','2017-07-25 15:30:49','2017-07-25 15:30:49');
INSERT INTO `glpi_locations` VALUES ('8','0','0','33-401 Aula','3','Piso 4 > 33-401 Aula','','2',NULL,'{\"8\":\"8\"}','33-401','33-401','','','','2017-07-25 15:32:02','2017-07-25 15:31:15');
INSERT INTO `glpi_locations` VALUES ('9','0','0','33-402 Aula','3','Piso 4 > 33-402 Aula','','2',NULL,'{\"9\":\"9\"}','33-402','33-402','','','','2017-07-25 15:32:15','2017-07-25 15:31:27');
INSERT INTO `glpi_locations` VALUES ('10','0','0','33-404 Aula','3','Piso 4 > 33-404 Aula','','2',NULL,NULL,'33-404','33-404','','','','2017-07-25 15:31:46','2017-07-25 15:31:46');
INSERT INTO `glpi_locations` VALUES ('11','0','0','33-407 Aula','3','Piso 4 > 33-407 Aula','','2',NULL,NULL,'33-407','33-407','','','','2017-07-25 15:32:44','2017-07-25 15:32:44');
INSERT INTO `glpi_locations` VALUES ('12','0','0','33-410 Aula','3','Piso 4 > 33-410 Aula','','2',NULL,NULL,'33-410','33-410','','','','2017-07-25 15:32:58','2017-07-25 15:32:58');
INSERT INTO `glpi_locations` VALUES ('13','0','0','33-412 Aula','3','Piso 4 > 33-412 Aula','','2',NULL,NULL,'33-412 ','33-412 ','','','','2017-07-25 15:33:10','2017-07-25 15:33:10');
INSERT INTO `glpi_locations` VALUES ('14','0','0','Piso 2','0','Piso 2','','1',NULL,NULL,'Piso 2','Piso 2','','','','2017-07-25 15:58:59','2017-07-25 15:58:59');
INSERT INTO `glpi_locations` VALUES ('15','0','0','Piso 3','0','Piso 3','','1',NULL,NULL,'Piso 3','Piso 3','','','','2017-07-25 15:59:10','2017-07-25 15:59:10');
INSERT INTO `glpi_locations` VALUES ('16','0','0','Piso 1','0','Piso 1','','1',NULL,NULL,'Piso 1','Piso 1','','','','2017-07-25 15:59:17','2017-07-25 15:59:17');
INSERT INTO `glpi_locations` VALUES ('17','0','0','33-100 Decanatura','16','Piso 1 > 33-100 Decanatura',NULL,'2',NULL,'{\"17\":\"17\"}','33-100','33-100',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('18','0','0','33-100 Vicedecanatura','16','Piso 1 > 33-100 Vicedecanatura',NULL,'2',NULL,NULL,'33-100','33-100',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('19','0','0','33-103 Salon Consejos','16','Piso 1 > 33-103 Salon Consejos',NULL,'2',NULL,NULL,'33-103','33-103',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('20','0','0','33-104 Comunicaciones','16','Piso 1 > 33-104 Comunicaciones',NULL,'2',NULL,NULL,'33-104','33-104',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('21','0','0','33-104 ULAF','16','Piso 1 > 33-104 ULAF',NULL,'2',NULL,NULL,'33-104','33-104',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('22','0','0','33-105 Registro academico ','16','Piso 1 > 33-105 Registro academico ',NULL,'2',NULL,NULL,'33-105','33-105',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('23','0','0','33-106 Centro de Extensión','16','Piso 1 > 33-106 Centro de Extensión',NULL,'2',NULL,NULL,'33-106','33-106',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('24','0','0','33-108 ULAF','16','Piso 1 > 33-108 ULAF',NULL,'2',NULL,NULL,'33-108','33-108',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('25','0','0','33-111 Lab Salud ocupacional','16','Piso 1 > 33-111 Lab Salud ocupacional',NULL,'2',NULL,NULL,'33-111','33-111',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('26','0','0','33-116 Oficina','16','Piso 1 > 33-116 Oficina',NULL,'2',NULL,NULL,'33-116','33-116',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('27','0','0','33-117 Auditorio','16','Piso 1 > 33-117 Auditorio',NULL,'2',NULL,NULL,'33-117','33-117',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('28','0','0','33-122 Lab Salud Publica','16','Piso 1 > 33-122 Lab Salud Publica',NULL,'2',NULL,NULL,'33-122','33-122',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('29','0','0','33-200 Depto ciencias especificas','14','Piso 2 > 33-200 Depto ciencias especificas',NULL,'2',NULL,NULL,'33-200','33-200',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('30','0','0','33-201 Oficina','14','Piso 2 > 33-201 Oficina',NULL,'2',NULL,NULL,'33-201','33-201',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('31','0','0','33-202 Oficina','14','Piso 2 > 33-202 Oficina',NULL,'2',NULL,NULL,'33-202','33-202',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('32','0','0','33-203 Oficina','14','Piso 2 > 33-203 Oficina',NULL,'2',NULL,NULL,'33-203','33-203',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('33','0','0','33-204 Oficina','14','Piso 2 > 33-204 Oficina',NULL,'2',NULL,NULL,'33-204','33-204',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('34','0','0','33-205 Oficina','14','Piso 2 > 33-205 Oficina',NULL,'2',NULL,NULL,'33-205','33-205',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('35','0','0','33-206 Oficina','14','Piso 2 > 33-206 Oficina',NULL,'2',NULL,NULL,'33-206','33-206',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('36','0','0','33-207 Oficina','14','Piso 2 > 33-207 Oficina',NULL,'2',NULL,NULL,'33-207','33-207',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('37','0','0','33-208 Oficina','14','Piso 2 > 33-208 Oficina',NULL,'2',NULL,NULL,'33-208','33-208',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('38','0','0','33-209 Oficina','14','Piso 2 > 33-209 Oficina',NULL,'2',NULL,NULL,'33-209','33-209',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('39','0','0','33-210 Oficina','14','Piso 2 > 33-210 Oficina',NULL,'2',NULL,NULL,'33-210','33-210',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('40','0','0','33-218 Aula','14','Piso 2 > 33-218 Aula',NULL,'2',NULL,NULL,'33-218','33-218',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('41','0','0','33-219 Aula','14','Piso 2 > 33-219 Aula',NULL,'2',NULL,NULL,'33-219','33-219',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('42','0','0','33-220 Aula','14','Piso 2 > 33-220 Aula',NULL,'2',NULL,NULL,'33-220','33-220',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('43','0','0','33-221 Aula','14','Piso 2 > 33-221 Aula',NULL,'2',NULL,NULL,'33-221','33-221',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('44','0','0','33-223 Aula','14','Piso 2 > 33-223 Aula',NULL,'2',NULL,NULL,'33-223','33-223',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('45','0','0','33-224 Aula','14','Piso 2 > 33-224 Aula',NULL,'2',NULL,'{\"45\":\"45\"}','33-224','33-224',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('46','0','0','33-225 Of Congreso','14','Piso 2 > 33-225 Of Congreso',NULL,'2',NULL,'{\"46\":\"46\"}','33-225','33-225',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('47','0','0','33-237 Asistencia CI- FNSP','14','Piso 2 > 33-237 Asistencia CI- FNSP',NULL,'2',NULL,'{\"47\":\"47\"}','33-237','33-237',NULL,NULL,NULL,'2017-11-14 16:01:03',NULL);
INSERT INTO `glpi_locations` VALUES ('48','0','0','33-233 Aula Informatica','14','Piso 2 > 33-233 Aula Informatica',NULL,'2',NULL,NULL,'33-233','33-233',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('49','0','0','33-235 Aula Informatica','14','Piso 2 > 33-235 Aula Informatica',NULL,'2',NULL,NULL,'33-235','33-235',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('50','0','0','33-300 Depto Ciencias basicas ','15','Piso 3 > 33-300 Depto Ciencias basicas ',NULL,'2',NULL,NULL,'33-300','33-300',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('51','0','0','33-301 Oficina','15','Piso 3 > 33-301 Oficina',NULL,'2',NULL,NULL,'33-301','33-301',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('52','0','0','33-302 Oficina','15','Piso 3 > 33-302 Oficina',NULL,'2',NULL,NULL,'33-302','33-302',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('53','0','0','33-303 Oficina','15','Piso 3 > 33-303 Oficina',NULL,'2',NULL,NULL,'33-303','33-303',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('54','0','0','33-304 Oficina','15','Piso 3 > 33-304 Oficina',NULL,'2',NULL,NULL,'33-304','33-304',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('55','0','0','33-305 Oficina','15','Piso 3 > 33-305 Oficina',NULL,'2',NULL,NULL,'33-305','33-305',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('56','0','0','33-306 Oficina','15','Piso 3 > 33-306 Oficina',NULL,'2',NULL,NULL,'33-306','33-306',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('57','0','0','33-307 Oficina','15','Piso 3 > 33-307 Oficina',NULL,'2',NULL,NULL,'33-307','33-307',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('58','0','0','33-308 Oficina','15','Piso 3 > 33-308 Oficina',NULL,'2',NULL,NULL,'33-308','33-308',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('59','0','0','33-309 Oficina','15','Piso 3 > 33-309 Oficina',NULL,'2',NULL,NULL,'33-309','33-309',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('60','0','0','33-310 Oficina','15','Piso 3 > 33-310 Oficina',NULL,'2',NULL,NULL,'33-310','33-310',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('61','0','0','33-313-314 Oficina','15','Piso 3 > 33-313-314 Oficina',NULL,'2',NULL,NULL,'33-313','33-313',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('62','0','0','33-318 Aula','15','Piso 3 > 33-318 Aula',NULL,'2',NULL,NULL,'33-318','33-318',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('63','0','0','33-319 Aula','15','Piso 3 > 33-319 Aula',NULL,'2',NULL,NULL,'33-319','33-319',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('64','0','0','33-322 Aula','15','Piso 3 > 33-322 Aula',NULL,'2',NULL,NULL,'33-322','33-322',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('65','0','0','33-323 Aula','15','Piso 3 > 33-323 Aula',NULL,'2',NULL,NULL,'33-323','33-323',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('66','0','0','33-324 Aula','15','Piso 3 > 33-324 Aula',NULL,'2',NULL,NULL,'33-324','33-324',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('67','0','0','33-325 Oficina','15','Piso 3 > 33-325 Oficina',NULL,'2',NULL,NULL,'33-325','33-325',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('68','0','0','33-326 Aula','15','Piso 3 > 33-326 Aula',NULL,'2',NULL,NULL,'33-326','33-326',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('69','0','0','33-327 Aula','15','Piso 3 > 33-327 Aula',NULL,'2',NULL,NULL,'33-327','33-327',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('70','0','0','33-328-A Oficina','15','Piso 3 > 33-328-A Oficina',NULL,'2',NULL,NULL,'33-328','33-328',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('71','0','0','33-329-330 Oficina','15','Piso 3 > 33-329-330 Oficina',NULL,'2',NULL,NULL,'33-329','33-329',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('72','0','0','33-333 Mesanini','15','Piso 3 > 33-333 Mesanini',NULL,'2',NULL,NULL,'33-333','33-333',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('73','0','0','33-333 Modulo 1','15','Piso 3 > 33-333 Modulo 1',NULL,'2',NULL,NULL,'33-333','33-333',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('74','0','0','33-333 Modulo 2','15','Piso 3 > 33-333 Modulo 2',NULL,'2',NULL,NULL,'33-333','33-333',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('75','0','0','33-333 Modulo 3','15','Piso 3 > 33-333 Modulo 3',NULL,'2',NULL,NULL,'33-333','33-333',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('76','0','0','33-333 Modulo 4','15','Piso 3 > 33-333 Modulo 4',NULL,'2',NULL,NULL,'33-333','33-333',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('77','0','0','33-333 Modulo 5','15','Piso 3 > 33-333 Modulo 5',NULL,'2',NULL,NULL,'33-333','33-333',NULL,NULL,NULL,NULL,NULL);
INSERT INTO `glpi_locations` VALUES ('78','0','0','33-232 Jefe Centro investigación','14','Piso 2 > 33-232 Jefe Centro investigación','','2',NULL,'{\"78\":\"78\"}','33-232','33-232','','','','2017-11-14 16:00:48','2017-11-14 15:59:42');

### Dump table glpi_logs

DROP TABLE IF EXISTS `glpi_logs`;
CREATE TABLE `glpi_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype_link` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `linked_action` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php HISTORY_* constant',
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `id_search_option` int(11) NOT NULL DEFAULT '0' COMMENT 'see search.constant.php for value',
  `old_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `new_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `itemtype_link` (`itemtype_link`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_logs` VALUES ('1','ComputerType','1','0','20','glpi (2)','2017-06-30 00:07:29','0','','');
INSERT INTO `glpi_logs` VALUES ('2','User','2','','0','admin (2)','2017-06-30 00:09:41','1','glpi','admin');
INSERT INTO `glpi_logs` VALUES ('3','User','5','','0','normal (5)','2017-06-30 00:12:17','15','0','1');
INSERT INTO `glpi_logs` VALUES ('4','User','4','','0','tech (4)','2017-06-30 00:13:03','15','0','1');
INSERT INTO `glpi_logs` VALUES ('5','User','2','','0','Correa Juan David (2)','2017-06-30 00:24:42','34','','Correa');
INSERT INTO `glpi_logs` VALUES ('6','User','2','','0','Correa Juan David (2)','2017-06-30 00:24:42','9','','Juan David');
INSERT INTO `glpi_logs` VALUES ('7','User','2','','0','Correa Juan David (2)','2017-06-30 00:24:42','6','','2196889');
INSERT INTO `glpi_logs` VALUES ('8','User','2','UserEmail','17','Correa Juan David (2)','2017-06-30 00:24:42','0','','juan.corea2@udea.edu.co (1)');
INSERT INTO `glpi_logs` VALUES ('9','UserEmail','1','0','20','Correa Juan David (2)','2017-06-30 00:24:42','0','','');
INSERT INTO `glpi_logs` VALUES ('10','ComputerType','2','0','20','Correa Juan David (2)','2017-06-30 10:55:58','0','','');
INSERT INTO `glpi_logs` VALUES ('11','ComputerType','3','0','20','Correa Juan David (2)','2017-06-30 10:56:35','0','','');
INSERT INTO `glpi_logs` VALUES ('12','Group','1','0','20','Correa Juan David (2)','2017-06-30 11:00:21','0','','');
INSERT INTO `glpi_logs` VALUES ('13','Group','2','0','20','Correa Juan David (2)','2017-06-30 11:00:44','0','','');
INSERT INTO `glpi_logs` VALUES ('14','Group','3','0','20','Correa Juan David (2)','2017-06-30 11:00:56','0','','');
INSERT INTO `glpi_logs` VALUES ('15','Group','4','0','20','Correa Juan David (2)','2017-06-30 11:01:08','0','','');
INSERT INTO `glpi_logs` VALUES ('16','UserTitle','1','0','20','Correa Juan David (2)','2017-06-30 11:06:00','0','','');
INSERT INTO `glpi_logs` VALUES ('17','User','6','UserEmail','17','Correa Juan David (2)','2017-06-30 11:06:26','0','','felipe.becerra@udea.edu.co (2)');
INSERT INTO `glpi_logs` VALUES ('18','UserEmail','2','0','20','Correa Juan David (2)','2017-06-30 11:06:26','0','','');
INSERT INTO `glpi_logs` VALUES ('19','User','6','Profile','17','Correa Juan David (2)','2017-06-30 11:06:26','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('20','User','6','0','20','Correa Juan David (2)','2017-06-30 11:06:26','0','','');
INSERT INTO `glpi_logs` VALUES ('21','User','6','Profile','17','Correa Juan David (2)','2017-06-30 11:20:30','0','','Super-Admin (4)');
INSERT INTO `glpi_logs` VALUES ('22','User','6','Profile','19','Correa Juan David (2)','2017-06-30 11:20:48','0','Self-Service (1)','');
INSERT INTO `glpi_logs` VALUES ('23','Location','1','0','20','Correa Juan David (2)','2017-06-30 11:29:23','0','','');
INSERT INTO `glpi_logs` VALUES ('24','User','7','UserEmail','17','Becerra Felipe (6)','2017-07-10 09:59:00','0','','ctangar@gmail.com (3)');
INSERT INTO `glpi_logs` VALUES ('25','UserEmail','3','0','20','Becerra Felipe (6)','2017-07-10 09:59:00','0','','');
INSERT INTO `glpi_logs` VALUES ('26','User','7','Profile','17','Becerra Felipe (6)','2017-07-10 09:59:00','0','','Super-Admin (4)');
INSERT INTO `glpi_logs` VALUES ('27','User','7','0','20','Becerra Felipe (6)','2017-07-10 09:59:00','0','','');
INSERT INTO `glpi_logs` VALUES ('28','User','7','','0','Correa Juan David (2)','2017-07-10 10:00:34','20','&nbsp; (0)','Super-Admin (4)');
INSERT INTO `glpi_logs` VALUES ('29','User','8','Profile','17','Correa Juan David (2)','2017-07-10 10:07:32','0','','Self-Service (1)');
INSERT INTO `glpi_logs` VALUES ('30','User','8','0','20','Correa Juan David (2)','2017-07-10 10:07:32','0','','');
INSERT INTO `glpi_logs` VALUES ('31','User','8','Profile','17','Correa Juan David (2)','2017-07-10 10:10:12','0','','Hotliner (5)');
INSERT INTO `glpi_logs` VALUES ('32','User','8','Profile','19','Correa Juan David (2)','2017-07-10 10:10:24','0','Self-Service (1)','');
INSERT INTO `glpi_logs` VALUES ('33','User','8','Profile','17','Correa Juan David (2)','2017-07-10 10:11:21','0','','Read-Only (8)');
INSERT INTO `glpi_logs` VALUES ('34','User','8','Profile','19','Correa Juan David (2)','2017-07-10 10:11:28','0','Hotliner (5)','');
INSERT INTO `glpi_logs` VALUES ('35','User','8','Profile','17','Correa Juan David (2)','2017-07-10 10:12:10','0','','Observer (2)');
INSERT INTO `glpi_logs` VALUES ('36','User','8','Profile','19','Correa Juan David (2)','2017-07-10 10:12:17','0','Read-Only (8)','');
INSERT INTO `glpi_logs` VALUES ('354','ProfileRight','956','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('352','ProfileRight','955','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('353','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','search_config (956)');
INSERT INTO `glpi_logs` VALUES ('351','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rule_ticket (955)');
INSERT INTO `glpi_logs` VALUES ('349','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rule_softwarecategories (954)');
INSERT INTO `glpi_logs` VALUES ('350','ProfileRight','954','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('348','ProfileRight','953','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('346','ProfileRight','952','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('347','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rule_mailcollector (953)');
INSERT INTO `glpi_logs` VALUES ('344','ProfileRight','951','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('345','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rule_ldap (952)');
INSERT INTO `glpi_logs` VALUES ('343','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rule_import (951)');
INSERT INTO `glpi_logs` VALUES ('341','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rule_dictionnary_software (950)');
INSERT INTO `glpi_logs` VALUES ('342','ProfileRight','950','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('340','ProfileRight','949','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('338','ProfileRight','948','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('339','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rule_dictionnary_printer (949)');
INSERT INTO `glpi_logs` VALUES ('337','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rule_dictionnary_dropdown (948)');
INSERT INTO `glpi_logs` VALUES ('335','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','rssfeed_public (947)');
INSERT INTO `glpi_logs` VALUES ('336','ProfileRight','947','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('334','ProfileRight','946','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('332','ProfileRight','945','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('333','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','reservation (946)');
INSERT INTO `glpi_logs` VALUES ('330','ProfileRight','944','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('331','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','reports (945)');
INSERT INTO `glpi_logs` VALUES ('329','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','reminder_public (944)');
INSERT INTO `glpi_logs` VALUES ('327','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','queuedmail (943)');
INSERT INTO `glpi_logs` VALUES ('328','ProfileRight','943','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('326','ProfileRight','942','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('324','ProfileRight','941','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('325','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','projecttask (942)');
INSERT INTO `glpi_logs` VALUES ('323','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','project (941)');
INSERT INTO `glpi_logs` VALUES ('321','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','profile (940)');
INSERT INTO `glpi_logs` VALUES ('322','ProfileRight','940','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('320','ProfileRight','939','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('318','ProfileRight','938','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('319','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','problem (939)');
INSERT INTO `glpi_logs` VALUES ('316','ProfileRight','937','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('317','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','printer (938)');
INSERT INTO `glpi_logs` VALUES ('315','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','planning (937)');
INSERT INTO `glpi_logs` VALUES ('313','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','phone (936)');
INSERT INTO `glpi_logs` VALUES ('314','ProfileRight','936','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('312','ProfileRight','935','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('310','ProfileRight','934','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('311','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','peripheral (935)');
INSERT INTO `glpi_logs` VALUES ('309','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','password_update (934)');
INSERT INTO `glpi_logs` VALUES ('307','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','notification (933)');
INSERT INTO `glpi_logs` VALUES ('308','ProfileRight','933','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('306','ProfileRight','932','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('304','ProfileRight','931','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('305','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','networking (932)');
INSERT INTO `glpi_logs` VALUES ('302','ProfileRight','930','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('303','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','netpoint (931)');
INSERT INTO `glpi_logs` VALUES ('301','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','monitor (930)');
INSERT INTO `glpi_logs` VALUES ('299','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','logs (929)');
INSERT INTO `glpi_logs` VALUES ('300','ProfileRight','929','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('298','ProfileRight','928','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('296','ProfileRight','927','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('297','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','location (928)');
INSERT INTO `glpi_logs` VALUES ('294','ProfileRight','926','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('295','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','link (927)');
INSERT INTO `glpi_logs` VALUES ('293','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','license (926)');
INSERT INTO `glpi_logs` VALUES ('291','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','knowbasecategory (925)');
INSERT INTO `glpi_logs` VALUES ('292','ProfileRight','925','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('290','ProfileRight','924','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('288','ProfileRight','923','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('289','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','knowbase (924)');
INSERT INTO `glpi_logs` VALUES ('286','ProfileRight','922','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('287','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','itilcategory (923)');
INSERT INTO `glpi_logs` VALUES ('285','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','internet (922)');
INSERT INTO `glpi_logs` VALUES ('283','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','infocom (921)');
INSERT INTO `glpi_logs` VALUES ('284','ProfileRight','921','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('282','ProfileRight','920','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('280','ProfileRight','919','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('281','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','group (920)');
INSERT INTO `glpi_logs` VALUES ('278','ProfileRight','918','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('279','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','followup (919)');
INSERT INTO `glpi_logs` VALUES ('276','ProfileRight','917','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('277','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','entity (918)');
INSERT INTO `glpi_logs` VALUES ('275','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','dropdown (917)');
INSERT INTO `glpi_logs` VALUES ('273','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','domain (916)');
INSERT INTO `glpi_logs` VALUES ('274','ProfileRight','916','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('271','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','document (915)');
INSERT INTO `glpi_logs` VALUES ('272','ProfileRight','915','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('270','ProfileRight','914','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('268','ProfileRight','913','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('269','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','device (914)');
INSERT INTO `glpi_logs` VALUES ('266','ProfileRight','912','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('267','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','contract (913)');
INSERT INTO `glpi_logs` VALUES ('265','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','contact_enterprise (912)');
INSERT INTO `glpi_logs` VALUES ('263','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','consumable (911)');
INSERT INTO `glpi_logs` VALUES ('264','ProfileRight','911','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('262','ProfileRight','910','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('260','ProfileRight','909','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('261','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','config (910)');
INSERT INTO `glpi_logs` VALUES ('258','ProfileRight','908','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('259','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','computer (909)');
INSERT INTO `glpi_logs` VALUES ('257','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','changevalidation (908)');
INSERT INTO `glpi_logs` VALUES ('255','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','change (907)');
INSERT INTO `glpi_logs` VALUES ('256','ProfileRight','907','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('254','ProfileRight','906','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('252','ProfileRight','905','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('253','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','cartridge (906)');
INSERT INTO `glpi_logs` VALUES ('251','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','calendar (905)');
INSERT INTO `glpi_logs` VALUES ('249','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','budget (904)');
INSERT INTO `glpi_logs` VALUES ('250','ProfileRight','904','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('248','ProfileRight','903','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('246','ProfileRight','902','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('247','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','bookmark_public (903)');
INSERT INTO `glpi_logs` VALUES ('244','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:04:55','45','31','23');
INSERT INTO `glpi_logs` VALUES ('245','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','backup (902)');
INSERT INTO `glpi_logs` VALUES ('243','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:04:55','52','3103','3072');
INSERT INTO `glpi_logs` VALUES ('241','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:04:55','46','159','23');
INSERT INTO `glpi_logs` VALUES ('242','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:04:55','106','31','23');
INSERT INTO `glpi_logs` VALUES ('240','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:04:55','42','31','23');
INSERT INTO `glpi_logs` VALUES ('182','User','8','Profile','17','Correa Juan David (2)','2017-07-10 10:16:42','0','','Solicitante (9)');
INSERT INTO `glpi_logs` VALUES ('183','User','8','Profile','19','Correa Juan David (2)','2017-07-10 10:16:57','0','Observer (2)','');
INSERT INTO `glpi_logs` VALUES ('239','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:04:55','44','31','22');
INSERT INTO `glpi_logs` VALUES ('238','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:04:55','47','31','3');
INSERT INTO `glpi_logs` VALUES ('237','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:04:55','107','31','23');
INSERT INTO `glpi_logs` VALUES ('188','User','3','0','13','Correa Juan David (2)','2017-07-11 14:34:19','0','','');
INSERT INTO `glpi_logs` VALUES ('189','User','4','0','13','Correa Juan David (2)','2017-07-11 14:34:19','0','','');
INSERT INTO `glpi_logs` VALUES ('190','User','5','0','13','Correa Juan David (2)','2017-07-11 14:34:19','0','','');
INSERT INTO `glpi_logs` VALUES ('191','User','2','','0','Correa Juan David (2)','2017-07-11 14:34:33','1','admin','juan.correa');
INSERT INTO `glpi_logs` VALUES ('192','User','7','','0','Correa Juan David (2)','2017-07-11 14:36:16','6','','2196832');
INSERT INTO `glpi_logs` VALUES ('193','User','7','','0','Correa Juan David (2)','2017-07-11 14:36:16','81','&nbsp; (0)','Ingeniero (1)');
INSERT INTO `glpi_logs` VALUES ('194','User','7','Group','15','Correa Juan David (2)','2017-07-11 14:41:42','0','','Entornos virtuales (3)');
INSERT INTO `glpi_logs` VALUES ('195','Group','3','User','15','Correa Juan David (2)','2017-07-11 14:41:42','0','','Carlos Alberto Tangarife (7)');
INSERT INTO `glpi_logs` VALUES ('196','User','6','Group','15','Correa Juan David (2)','2017-07-11 14:41:49','0','','Entornos virtuales (3)');
INSERT INTO `glpi_logs` VALUES ('197','Group','3','User','15','Correa Juan David (2)','2017-07-11 14:41:49','0','','Felipe Becerra (6)');
INSERT INTO `glpi_logs` VALUES ('198','User','7','Group','15','Correa Juan David (2)','2017-07-11 14:42:19','0','','Sistemas de información (2)');
INSERT INTO `glpi_logs` VALUES ('199','Group','2','User','15','Correa Juan David (2)','2017-07-11 14:42:19','0','','Carlos Alberto Tangarife (7)');
INSERT INTO `glpi_logs` VALUES ('200','User','2','Group','15','Correa Juan David (2)','2017-07-11 14:42:27','0','','Sistemas de información (2)');
INSERT INTO `glpi_logs` VALUES ('201','Group','2','User','15','Correa Juan David (2)','2017-07-11 14:42:27','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('202','User','7','Group','15','Correa Juan David (2)','2017-07-11 14:43:19','0','','Soporte tecnico (1)');
INSERT INTO `glpi_logs` VALUES ('203','Group','1','User','15','Correa Juan David (2)','2017-07-11 14:43:19','0','','Carlos Alberto Tangarife (7)');
INSERT INTO `glpi_logs` VALUES ('204','User','6','Group','15','Correa Juan David (2)','2017-07-11 14:43:26','0','','Soporte tecnico (1)');
INSERT INTO `glpi_logs` VALUES ('205','Group','1','User','15','Correa Juan David (2)','2017-07-11 14:43:26','0','','Felipe Becerra (6)');
INSERT INTO `glpi_logs` VALUES ('206','User','6','Group_User#is_userdelegate','21','Correa Juan David (2)','2017-07-11 14:43:57','0','0','1');
INSERT INTO `glpi_logs` VALUES ('207','Group','1','Group_User#is_userdelegate','21','Correa Juan David (2)','2017-07-11 14:43:57','0','0','1');
INSERT INTO `glpi_logs` VALUES ('208','ITILCategory','1','0','20','Juan David Correa (2)','2017-07-12 10:41:12','0','','');
INSERT INTO `glpi_logs` VALUES ('209','ITILCategory','1','ITILCategory','17','Juan David Correa (2)','2017-07-12 10:41:48','0','','Creación de usuarios en un sistema');
INSERT INTO `glpi_logs` VALUES ('210','ITILCategory','2','0','20','Juan David Correa (2)','2017-07-12 10:41:48','0','','');
INSERT INTO `glpi_logs` VALUES ('361','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','solutiontemplate (960)');
INSERT INTO `glpi_logs` VALUES ('362','ProfileRight','960','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('360','ProfileRight','959','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('679','User','10','Profile','17','Juan David Correa (2)','2017-07-26 00:24:49','0','','Administrador (4)');
INSERT INTO `glpi_logs` VALUES ('359','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','software (959)');
INSERT INTO `glpi_logs` VALUES ('358','ProfileRight','958','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('357','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','sla (958)');
INSERT INTO `glpi_logs` VALUES ('356','ProfileRight','957','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('355','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','show_group_hardware (957)');
INSERT INTO `glpi_logs` VALUES ('222','User','2','','0','Juan David Correa (2)','2017-07-12 11:06:01','3','&nbsp; (0)','Area tecnologica (1)');
INSERT INTO `glpi_logs` VALUES ('223','Group','5','0','20','Juan David Correa (2)','2017-07-12 11:08:37','0','','');
INSERT INTO `glpi_logs` VALUES ('224','User','8','Group','15','Juan David Correa (2)','2017-07-12 11:09:20','0','','Solicitante (5)');
INSERT INTO `glpi_logs` VALUES ('225','Group','5','User','15','Juan David Correa (2)','2017-07-12 11:09:20','0','','prueba prueba (8)');
INSERT INTO `glpi_logs` VALUES ('236','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:03:59','118','0','1');
INSERT INTO `glpi_logs` VALUES ('235','Profile','4','','0','Juan David Correa (2)','2017-07-13 16:03:59','1','Super-Admin','Administrador');
INSERT INTO `glpi_logs` VALUES ('229','Notification','2','','0','Juan David Correa (2)','2017-07-12 11:25:42','86','1','0');
INSERT INTO `glpi_logs` VALUES ('230','Notification','2','','0','Juan David Correa (2)','2017-07-12 11:25:42','1','New Ticket','Nuevo Ticket');
INSERT INTO `glpi_logs` VALUES ('231','User','8','','0','Juan David Correa (2)','2017-07-12 11:29:41','3','&nbsp; (0)','Area tecnologica (1)');
INSERT INTO `glpi_logs` VALUES ('232','User','8','','0','Juan David Correa (2)','2017-07-12 11:29:41','20','&nbsp; (0)','Solicitante (9)');
INSERT INTO `glpi_logs` VALUES ('233','Notification','2','','0','Juan David Correa (2)','2017-07-12 11:31:27','4','Tickets (4)','Tickets (Simple) (5)');
INSERT INTO `glpi_logs` VALUES ('234','Notification','2','','0','Juan David Correa (2)','2017-07-12 11:32:07','4','Tickets (Simple) (5)','Tickets (4)');
INSERT INTO `glpi_logs` VALUES ('363','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','state (961)');
INSERT INTO `glpi_logs` VALUES ('364','ProfileRight','961','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('365','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','statistic (962)');
INSERT INTO `glpi_logs` VALUES ('366','ProfileRight','962','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('367','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','task (963)');
INSERT INTO `glpi_logs` VALUES ('368','ProfileRight','963','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('369','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','taskcategory (964)');
INSERT INTO `glpi_logs` VALUES ('370','ProfileRight','964','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('371','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','ticket (965)');
INSERT INTO `glpi_logs` VALUES ('372','ProfileRight','965','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('373','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','ticketcost (966)');
INSERT INTO `glpi_logs` VALUES ('374','ProfileRight','966','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('375','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','ticketrecurrent (967)');
INSERT INTO `glpi_logs` VALUES ('376','ProfileRight','967','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('377','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','tickettemplate (968)');
INSERT INTO `glpi_logs` VALUES ('378','ProfileRight','968','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('379','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','ticketvalidation (969)');
INSERT INTO `glpi_logs` VALUES ('380','ProfileRight','969','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('381','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','transfer (970)');
INSERT INTO `glpi_logs` VALUES ('382','ProfileRight','970','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('383','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','typedoc (971)');
INSERT INTO `glpi_logs` VALUES ('384','ProfileRight','971','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('385','Profile','10','ProfileRight','17','Juan David Correa (2)','2017-07-13 16:05:35','0','','user (972)');
INSERT INTO `glpi_logs` VALUES ('386','ProfileRight','972','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('387','Profile','10','0','20','Juan David Correa (2)','2017-07-13 16:05:35','0','','');
INSERT INTO `glpi_logs` VALUES ('388','Profile','10','','0','Juan David Correa (2)','2017-07-13 16:06:42','86','0','1');
INSERT INTO `glpi_logs` VALUES ('389','Profile','10','','0','Juan David Correa (2)','2017-07-13 16:06:42','87','','[\"Computer\",\"Monitor\",\"Printer\",\"Software\"]');
INSERT INTO `glpi_logs` VALUES ('390','Profile','10','','0','Juan David Correa (2)','2017-07-13 16:06:42','102','0','5');
INSERT INTO `glpi_logs` VALUES ('391','User','8','Profile','17','Juan David Correa (2)','2017-07-13 16:08:05','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('392','Entity','0','','0','Juan David Correa (2)','2017-07-13 16:09:10','14','Root entity','Categoría Ppal');
INSERT INTO `glpi_logs` VALUES ('393','Entity','0','','0','Juan David Correa (2)','2017-07-13 16:09:10','1','Root entity','Categoría Ppal');
INSERT INTO `glpi_logs` VALUES ('394','User','9','UserEmail','17','Juan David Correa (2)','2017-07-18 09:44:37','0','','aljelova@gmail.com (4)');
INSERT INTO `glpi_logs` VALUES ('395','UserEmail','4','0','20','Juan David Correa (2)','2017-07-18 09:44:37','0','','');
INSERT INTO `glpi_logs` VALUES ('396','User','9','Profile','17','Juan David Correa (2)','2017-07-18 09:44:37','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('397','User','9','0','20','Juan David Correa (2)','2017-07-18 09:44:37','0','','');
INSERT INTO `glpi_logs` VALUES ('398','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','backup (973)');
INSERT INTO `glpi_logs` VALUES ('399','ProfileRight','973','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('400','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','bookmark_public (974)');
INSERT INTO `glpi_logs` VALUES ('401','ProfileRight','974','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('402','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','budget (975)');
INSERT INTO `glpi_logs` VALUES ('403','ProfileRight','975','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('404','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','calendar (976)');
INSERT INTO `glpi_logs` VALUES ('405','ProfileRight','976','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('406','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','cartridge (977)');
INSERT INTO `glpi_logs` VALUES ('407','ProfileRight','977','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('408','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','change (978)');
INSERT INTO `glpi_logs` VALUES ('409','ProfileRight','978','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('410','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','changevalidation (979)');
INSERT INTO `glpi_logs` VALUES ('411','ProfileRight','979','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('412','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','computer (980)');
INSERT INTO `glpi_logs` VALUES ('413','ProfileRight','980','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('414','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','config (981)');
INSERT INTO `glpi_logs` VALUES ('415','ProfileRight','981','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('416','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','consumable (982)');
INSERT INTO `glpi_logs` VALUES ('417','ProfileRight','982','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('418','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','contact_enterprise (983)');
INSERT INTO `glpi_logs` VALUES ('419','ProfileRight','983','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('420','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','contract (984)');
INSERT INTO `glpi_logs` VALUES ('421','ProfileRight','984','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('422','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','device (985)');
INSERT INTO `glpi_logs` VALUES ('423','ProfileRight','985','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('424','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','document (986)');
INSERT INTO `glpi_logs` VALUES ('425','ProfileRight','986','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('426','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','domain (987)');
INSERT INTO `glpi_logs` VALUES ('427','ProfileRight','987','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('428','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','dropdown (988)');
INSERT INTO `glpi_logs` VALUES ('429','ProfileRight','988','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('430','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','entity (989)');
INSERT INTO `glpi_logs` VALUES ('431','ProfileRight','989','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('432','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','followup (990)');
INSERT INTO `glpi_logs` VALUES ('433','ProfileRight','990','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('434','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','group (991)');
INSERT INTO `glpi_logs` VALUES ('435','ProfileRight','991','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('436','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','infocom (992)');
INSERT INTO `glpi_logs` VALUES ('437','ProfileRight','992','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('438','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','internet (993)');
INSERT INTO `glpi_logs` VALUES ('439','ProfileRight','993','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('440','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','itilcategory (994)');
INSERT INTO `glpi_logs` VALUES ('441','ProfileRight','994','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('442','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','knowbase (995)');
INSERT INTO `glpi_logs` VALUES ('443','ProfileRight','995','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('444','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','knowbasecategory (996)');
INSERT INTO `glpi_logs` VALUES ('445','ProfileRight','996','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('446','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','license (997)');
INSERT INTO `glpi_logs` VALUES ('447','ProfileRight','997','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('448','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','link (998)');
INSERT INTO `glpi_logs` VALUES ('449','ProfileRight','998','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('450','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','location (999)');
INSERT INTO `glpi_logs` VALUES ('451','ProfileRight','999','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('452','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','logs (1000)');
INSERT INTO `glpi_logs` VALUES ('453','ProfileRight','1000','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('454','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','monitor (1001)');
INSERT INTO `glpi_logs` VALUES ('455','ProfileRight','1001','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('456','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','netpoint (1002)');
INSERT INTO `glpi_logs` VALUES ('457','ProfileRight','1002','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('458','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','networking (1003)');
INSERT INTO `glpi_logs` VALUES ('459','ProfileRight','1003','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('460','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','notification (1004)');
INSERT INTO `glpi_logs` VALUES ('461','ProfileRight','1004','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('462','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','password_update (1005)');
INSERT INTO `glpi_logs` VALUES ('463','ProfileRight','1005','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('464','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','peripheral (1006)');
INSERT INTO `glpi_logs` VALUES ('465','ProfileRight','1006','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('466','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','phone (1007)');
INSERT INTO `glpi_logs` VALUES ('467','ProfileRight','1007','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('468','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','planning (1008)');
INSERT INTO `glpi_logs` VALUES ('469','ProfileRight','1008','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('470','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','printer (1009)');
INSERT INTO `glpi_logs` VALUES ('471','ProfileRight','1009','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('472','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','problem (1010)');
INSERT INTO `glpi_logs` VALUES ('473','ProfileRight','1010','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('474','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','profile (1011)');
INSERT INTO `glpi_logs` VALUES ('475','ProfileRight','1011','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('476','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','project (1012)');
INSERT INTO `glpi_logs` VALUES ('477','ProfileRight','1012','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('478','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','projecttask (1013)');
INSERT INTO `glpi_logs` VALUES ('479','ProfileRight','1013','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('480','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','queuedmail (1014)');
INSERT INTO `glpi_logs` VALUES ('481','ProfileRight','1014','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('482','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','reminder_public (1015)');
INSERT INTO `glpi_logs` VALUES ('483','ProfileRight','1015','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('484','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','reports (1016)');
INSERT INTO `glpi_logs` VALUES ('485','ProfileRight','1016','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('486','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','reservation (1017)');
INSERT INTO `glpi_logs` VALUES ('487','ProfileRight','1017','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('488','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rssfeed_public (1018)');
INSERT INTO `glpi_logs` VALUES ('489','ProfileRight','1018','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('490','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rule_dictionnary_dropdown (1019)');
INSERT INTO `glpi_logs` VALUES ('491','ProfileRight','1019','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('492','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rule_dictionnary_printer (1020)');
INSERT INTO `glpi_logs` VALUES ('493','ProfileRight','1020','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('494','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rule_dictionnary_software (1021)');
INSERT INTO `glpi_logs` VALUES ('495','ProfileRight','1021','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('496','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rule_import (1022)');
INSERT INTO `glpi_logs` VALUES ('497','ProfileRight','1022','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('498','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rule_ldap (1023)');
INSERT INTO `glpi_logs` VALUES ('499','ProfileRight','1023','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('500','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rule_mailcollector (1024)');
INSERT INTO `glpi_logs` VALUES ('501','ProfileRight','1024','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('502','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rule_softwarecategories (1025)');
INSERT INTO `glpi_logs` VALUES ('503','ProfileRight','1025','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('504','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','rule_ticket (1026)');
INSERT INTO `glpi_logs` VALUES ('505','ProfileRight','1026','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('506','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','search_config (1027)');
INSERT INTO `glpi_logs` VALUES ('507','ProfileRight','1027','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('508','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','show_group_hardware (1028)');
INSERT INTO `glpi_logs` VALUES ('509','ProfileRight','1028','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('510','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','sla (1029)');
INSERT INTO `glpi_logs` VALUES ('511','ProfileRight','1029','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('512','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','software (1030)');
INSERT INTO `glpi_logs` VALUES ('513','ProfileRight','1030','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('514','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','solutiontemplate (1031)');
INSERT INTO `glpi_logs` VALUES ('515','ProfileRight','1031','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('516','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','state (1032)');
INSERT INTO `glpi_logs` VALUES ('517','ProfileRight','1032','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('518','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','statistic (1033)');
INSERT INTO `glpi_logs` VALUES ('519','ProfileRight','1033','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('520','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','task (1034)');
INSERT INTO `glpi_logs` VALUES ('521','ProfileRight','1034','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('522','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','taskcategory (1035)');
INSERT INTO `glpi_logs` VALUES ('523','ProfileRight','1035','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('524','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','ticket (1036)');
INSERT INTO `glpi_logs` VALUES ('525','ProfileRight','1036','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('526','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','ticketcost (1037)');
INSERT INTO `glpi_logs` VALUES ('527','ProfileRight','1037','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('528','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','ticketrecurrent (1038)');
INSERT INTO `glpi_logs` VALUES ('529','ProfileRight','1038','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('530','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','tickettemplate (1039)');
INSERT INTO `glpi_logs` VALUES ('531','ProfileRight','1039','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('532','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','ticketvalidation (1040)');
INSERT INTO `glpi_logs` VALUES ('533','ProfileRight','1040','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('534','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','transfer (1041)');
INSERT INTO `glpi_logs` VALUES ('535','ProfileRight','1041','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('536','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','typedoc (1042)');
INSERT INTO `glpi_logs` VALUES ('537','ProfileRight','1042','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('538','Profile','11','ProfileRight','17','Juan David Correa (2)','2017-07-18 09:45:34','0','','user (1043)');
INSERT INTO `glpi_logs` VALUES ('539','ProfileRight','1043','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('540','Profile','11','0','20','Juan David Correa (2)','2017-07-18 09:45:34','0','','');
INSERT INTO `glpi_logs` VALUES ('541','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:16','107','0','23');
INSERT INTO `glpi_logs` VALUES ('542','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:16','47','0','3');
INSERT INTO `glpi_logs` VALUES ('543','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:16','44','0','22');
INSERT INTO `glpi_logs` VALUES ('544','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:16','42','0','23');
INSERT INTO `glpi_logs` VALUES ('545','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:16','46','0','23');
INSERT INTO `glpi_logs` VALUES ('546','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:16','106','0','23');
INSERT INTO `glpi_logs` VALUES ('547','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:16','52','0','3072');
INSERT INTO `glpi_logs` VALUES ('548','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:16','45','0','23');
INSERT INTO `glpi_logs` VALUES ('549','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','26','0','127');
INSERT INTO `glpi_logs` VALUES ('550','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','20','0','127');
INSERT INTO `glpi_logs` VALUES ('551','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','27','0','127');
INSERT INTO `glpi_logs` VALUES ('552','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','129','0','31');
INSERT INTO `glpi_logs` VALUES ('553','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','21','0','127');
INSERT INTO `glpi_logs` VALUES ('554','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','23','0','127');
INSERT INTO `glpi_logs` VALUES ('555','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','25','0','127');
INSERT INTO `glpi_logs` VALUES ('556','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','28','0','127');
INSERT INTO `glpi_logs` VALUES ('557','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','24','0','127');
INSERT INTO `glpi_logs` VALUES ('558','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:33','22','0','127');
INSERT INTO `glpi_logs` VALUES ('559','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','86','0','2');
INSERT INTO `glpi_logs` VALUES ('560','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','87','','[]');
INSERT INTO `glpi_logs` VALUES ('561','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','115','0','1151');
INSERT INTO `glpi_logs` VALUES ('562','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','79','0','3073');
INSERT INTO `glpi_logs` VALUES ('563','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','112','0','1151');
INSERT INTO `glpi_logs` VALUES ('564','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','85','0','1');
INSERT INTO `glpi_logs` VALUES ('565','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','102','0','261151');
INSERT INTO `glpi_logs` VALUES ('566','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','119','0','23');
INSERT INTO `glpi_logs` VALUES ('567','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:47:59','103','0','23');
INSERT INTO `glpi_logs` VALUES ('568','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:14','86','2','3');
INSERT INTO `glpi_logs` VALUES ('569','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:26','101','0','127');
INSERT INTO `glpi_logs` VALUES ('570','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:26','32','0','127');
INSERT INTO `glpi_logs` VALUES ('571','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:26','31','0','127');
INSERT INTO `glpi_logs` VALUES ('572','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:26','33','0','23');
INSERT INTO `glpi_logs` VALUES ('573','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:39','64','0','23');
INSERT INTO `glpi_logs` VALUES ('574','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:39','34','0','7191');
INSERT INTO `glpi_logs` VALUES ('575','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:39','63','0','23');
INSERT INTO `glpi_logs` VALUES ('576','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:39','38','0','1');
INSERT INTO `glpi_logs` VALUES ('577','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:39','36','0','1055');
INSERT INTO `glpi_logs` VALUES ('578','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:39','120','0','23');
INSERT INTO `glpi_logs` VALUES ('579','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:53','91','0','23');
INSERT INTO `glpi_logs` VALUES ('580','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:48:53','90','0','23');
INSERT INTO `glpi_logs` VALUES ('581','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','62','0','1045');
INSERT INTO `glpi_logs` VALUES ('582','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','59','0','3191');
INSERT INTO `glpi_logs` VALUES ('583','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','58','0','119');
INSERT INTO `glpi_logs` VALUES ('584','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','61','0','1');
INSERT INTO `glpi_logs` VALUES ('585','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','55','0','23');
INSERT INTO `glpi_logs` VALUES ('586','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','49','0','23');
INSERT INTO `glpi_logs` VALUES ('587','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','50','0','23');
INSERT INTO `glpi_logs` VALUES ('588','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','105','0','23');
INSERT INTO `glpi_logs` VALUES ('589','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','51','0','23');
INSERT INTO `glpi_logs` VALUES ('590','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','48','0','1047');
INSERT INTO `glpi_logs` VALUES ('591','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','60','0','23');
INSERT INTO `glpi_logs` VALUES ('592','Profile','11','','0','Juan David Correa (2)','2017-07-18 09:49:11','56','0','7199');
INSERT INTO `glpi_logs` VALUES ('593','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:54:33','44','22','0');
INSERT INTO `glpi_logs` VALUES ('594','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:54:33','106','23','0');
INSERT INTO `glpi_logs` VALUES ('595','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:54:33','45','23','0');
INSERT INTO `glpi_logs` VALUES ('596','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:55:31','87','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]');
INSERT INTO `glpi_logs` VALUES ('597','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:55:31','115','1279','1151');
INSERT INTO `glpi_logs` VALUES ('598','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:55:31','112','1279','0');
INSERT INTO `glpi_logs` VALUES ('599','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:55:31','102','259231','259103');
INSERT INTO `glpi_logs` VALUES ('600','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:55:31','119','31','23');
INSERT INTO `glpi_logs` VALUES ('601','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:55:31','103','31','0');
INSERT INTO `glpi_logs` VALUES ('602','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','62','1055','0');
INSERT INTO `glpi_logs` VALUES ('603','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','59','3327','0');
INSERT INTO `glpi_logs` VALUES ('604','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','58','159','0');
INSERT INTO `glpi_logs` VALUES ('605','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','61','1','0');
INSERT INTO `glpi_logs` VALUES ('606','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','55','159','0');
INSERT INTO `glpi_logs` VALUES ('607','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','91','31','0');
INSERT INTO `glpi_logs` VALUES ('608','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','90','31','23');
INSERT INTO `glpi_logs` VALUES ('609','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','49','31','0');
INSERT INTO `glpi_logs` VALUES ('610','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','50','31','0');
INSERT INTO `glpi_logs` VALUES ('611','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','105','31','0');
INSERT INTO `glpi_logs` VALUES ('612','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','51','31','0');
INSERT INTO `glpi_logs` VALUES ('613','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','48','1055','0');
INSERT INTO `glpi_logs` VALUES ('614','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','60','31','0');
INSERT INTO `glpi_logs` VALUES ('615','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:56:20','56','7327','0');
INSERT INTO `glpi_logs` VALUES ('616','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:57:01','2','central','helpdesk');
INSERT INTO `glpi_logs` VALUES ('617','Profile','4','','0','Juan David Correa (2)','2017-07-18 09:57:38','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('618','Location','3','0','20','Juan David Correa (2)','2017-07-25 15:26:43','0','','');
INSERT INTO `glpi_logs` VALUES ('619','Location','1','','0','Juan David Correa (2)','2017-07-25 15:26:56','13','0','3');
INSERT INTO `glpi_logs` VALUES ('620','Location','1','','0','Juan David Correa (2)','2017-07-25 15:26:56','1','33-417 Area tecnologica','Piso 4 > 33-417 Area tecnologica');
INSERT INTO `glpi_logs` VALUES ('621','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:26:56','0','','33-417 Area tecnologica');
INSERT INTO `glpi_logs` VALUES ('622','Location','1','Location','18','Juan David Correa (2)','2017-07-25 15:26:56','0','','Piso 4');
INSERT INTO `glpi_logs` VALUES ('623','Location','2','','0','Juan David Correa (2)','2017-07-25 15:27:07','13','0','3');
INSERT INTO `glpi_logs` VALUES ('624','Location','2','','0','Juan David Correa (2)','2017-07-25 15:27:07','1','33-417 Oficina de soporte técnico ','Piso 4 > 33-417 Soporte sistemas');
INSERT INTO `glpi_logs` VALUES ('625','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:27:07','0','','33-417 Soporte sistemas');
INSERT INTO `glpi_logs` VALUES ('626','Location','2','Location','18','Juan David Correa (2)','2017-07-25 15:27:07','0','','Piso 4');
INSERT INTO `glpi_logs` VALUES ('627','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:27:52','0','','33-406 Asistencia de planeación');
INSERT INTO `glpi_logs` VALUES ('628','Location','4','0','20','Juan David Correa (2)','2017-07-25 15:27:52','0','','');
INSERT INTO `glpi_logs` VALUES ('629','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:29:59','0','','33-413 Posgrados');
INSERT INTO `glpi_logs` VALUES ('630','Location','5','0','20','Juan David Correa (2)','2017-07-25 15:29:59','0','','');
INSERT INTO `glpi_logs` VALUES ('631','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:30:25','0','','33-418 Coordinación posgrados');
INSERT INTO `glpi_logs` VALUES ('632','Location','6','0','20','Juan David Correa (2)','2017-07-25 15:30:25','0','','');
INSERT INTO `glpi_logs` VALUES ('633','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:30:49','0','','33-417A Sala Videoconferencia');
INSERT INTO `glpi_logs` VALUES ('634','Location','7','0','20','Juan David Correa (2)','2017-07-25 15:30:49','0','','');
INSERT INTO `glpi_logs` VALUES ('635','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:31:15','0','','33-401 Aula');
INSERT INTO `glpi_logs` VALUES ('636','Location','8','0','20','Juan David Correa (2)','2017-07-25 15:31:15','0','','');
INSERT INTO `glpi_logs` VALUES ('637','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:31:27','0','','33-402 Aula');
INSERT INTO `glpi_logs` VALUES ('638','Location','9','0','20','Juan David Correa (2)','2017-07-25 15:31:27','0','','');
INSERT INTO `glpi_logs` VALUES ('639','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:31:46','0','','33-404 Aula');
INSERT INTO `glpi_logs` VALUES ('640','Location','10','0','20','Juan David Correa (2)','2017-07-25 15:31:46','0','','');
INSERT INTO `glpi_logs` VALUES ('641','Location','8','','0','Juan David Correa (2)','2017-07-25 15:32:02','11','33-401 Aula','33-401');
INSERT INTO `glpi_logs` VALUES ('642','Location','8','','0','Juan David Correa (2)','2017-07-25 15:32:02','12','33-401 Aula','33-401');
INSERT INTO `glpi_logs` VALUES ('643','Location','9','','0','Juan David Correa (2)','2017-07-25 15:32:15','11','33-402 Aula','33-402');
INSERT INTO `glpi_logs` VALUES ('644','Location','9','','0','Juan David Correa (2)','2017-07-25 15:32:15','12','33-402 Aula','33-402');
INSERT INTO `glpi_logs` VALUES ('645','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:32:44','0','','33-407 Aula');
INSERT INTO `glpi_logs` VALUES ('646','Location','11','0','20','Juan David Correa (2)','2017-07-25 15:32:44','0','','');
INSERT INTO `glpi_logs` VALUES ('647','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:32:58','0','','33-410 Aula');
INSERT INTO `glpi_logs` VALUES ('648','Location','12','0','20','Juan David Correa (2)','2017-07-25 15:32:58','0','','');
INSERT INTO `glpi_logs` VALUES ('649','Location','3','Location','17','Juan David Correa (2)','2017-07-25 15:33:10','0','','33-412 Aula');
INSERT INTO `glpi_logs` VALUES ('650','Location','13','0','20','Juan David Correa (2)','2017-07-25 15:33:10','0','','');
INSERT INTO `glpi_logs` VALUES ('651','Location','14','0','20','Juan David Correa (2)','2017-07-25 15:58:59','0','','');
INSERT INTO `glpi_logs` VALUES ('652','Location','15','0','20','Juan David Correa (2)','2017-07-25 15:59:10','0','','');
INSERT INTO `glpi_logs` VALUES ('653','Location','16','0','20','Juan David Correa (2)','2017-07-25 15:59:17','0','','');
INSERT INTO `glpi_logs` VALUES ('654','ITILCategory','3','0','20','Juan David Correa (2)','2017-07-25 16:13:03','0','','');
INSERT INTO `glpi_logs` VALUES ('655','ITILCategory','4','0','20','Juan David Correa (2)','2017-07-25 16:13:29','0','','');
INSERT INTO `glpi_logs` VALUES ('656','PrinterType','1','0','20','Juan David Correa (2)','2017-07-25 17:45:17','0','','');
INSERT INTO `glpi_logs` VALUES ('657','PrinterType','2','0','20','Juan David Correa (2)','2017-07-25 17:45:32','0','','');
INSERT INTO `glpi_logs` VALUES ('658','PrinterType','3','0','20','Juan David Correa (2)','2017-07-25 17:45:42','0','','');
INSERT INTO `glpi_logs` VALUES ('659','PrinterType','4','0','20','Juan David Correa (2)','2017-07-25 17:46:28','0','','');
INSERT INTO `glpi_logs` VALUES ('660','Manufacturer','1','0','20','Juan David Correa (2)','2017-07-25 17:49:48','0','','');
INSERT INTO `glpi_logs` VALUES ('661','Manufacturer','2','0','20','Juan David Correa (2)','2017-07-25 17:49:53','0','','');
INSERT INTO `glpi_logs` VALUES ('662','Manufacturer','3','0','20','Juan David Correa (2)','2017-07-25 17:50:21','0','','');
INSERT INTO `glpi_logs` VALUES ('663','PrinterModel','1','0','20','Juan David Correa (2)','2017-07-25 17:55:51','0','','');
INSERT INTO `glpi_logs` VALUES ('664','Profile','10','','0','Juan David Correa (2)','2017-07-25 18:07:34','2','helpdesk','central');
INSERT INTO `glpi_logs` VALUES ('665','Profile','10','','0','Juan David Correa (2)','2017-07-25 18:08:53','2','central','helpdesk');
INSERT INTO `glpi_logs` VALUES ('666','Profile','10','','0','Juan David Correa (2)','2017-07-25 18:09:50','87','[\"Computer\",\"Monitor\",\"Printer\",\"Software\"]','[\"Computer\",\"Monitor\",\"Printer\",\"Software\"]');
INSERT INTO `glpi_logs` VALUES ('667','Profile','10','','0','Juan David Correa (2)','2017-07-25 18:11:04','87','[\"Computer\",\"Monitor\",\"Printer\",\"Software\"]','[\"Computer\",\"Monitor\",\"Printer\",\"Software\"]');
INSERT INTO `glpi_logs` VALUES ('668','OperatingSystem','1','0','20','Juan David Correa (2)','2017-07-25 18:17:38','0','','');
INSERT INTO `glpi_logs` VALUES ('669','OperatingSystem','2','0','20','Juan David Correa (2)','2017-07-25 18:17:45','0','','');
INSERT INTO `glpi_logs` VALUES ('670','OperatingSystem','3','0','20','Juan David Correa (2)','2017-07-25 18:17:54','0','','');
INSERT INTO `glpi_logs` VALUES ('671','OperatingSystem','4','0','20','Juan David Correa (2)','2017-07-25 18:18:05','0','','');
INSERT INTO `glpi_logs` VALUES ('672','OperatingSystem','5','0','20','Juan David Correa (2)','2017-07-25 18:19:25','0','','');
INSERT INTO `glpi_logs` VALUES ('673','User','6','','0','Juan David Correa (2)','2017-07-25 18:19:56','3','&nbsp; (0)','Piso 4 > 33-414 Soporte sistemas (2)');
INSERT INTO `glpi_logs` VALUES ('674','User','9','','0','Juan David Correa (2)','2017-07-25 18:20:28','81','&nbsp; (0)','Ingeniero (1)');
INSERT INTO `glpi_logs` VALUES ('675','User','9','','0','Juan David Correa (2)','2017-07-25 18:20:28','3','&nbsp; (0)','Piso 4 > 33-414 Soporte sistemas (2)');
INSERT INTO `glpi_logs` VALUES ('676','Entity','0','','0','Juan David Correa (2)','2017-07-25 18:23:41','14','Categoría Ppal','FNSP');
INSERT INTO `glpi_logs` VALUES ('677','Entity','0','','0','Juan David Correa (2)','2017-07-25 18:23:41','1','Categoría Ppal','FNSP');
INSERT INTO `glpi_logs` VALUES ('678','Entity','1','0','20','Juan David Correa (2)','2017-07-25 22:11:52','0','','');
INSERT INTO `glpi_logs` VALUES ('680','User','10','0','20','Juan David Correa (2)','2017-07-26 00:24:49','0','','');
INSERT INTO `glpi_logs` VALUES ('681','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:25:45','0','','Capacitación EVA y Moodle');
INSERT INTO `glpi_logs` VALUES ('682','ITILCategory','5','0','20','Juan David Correa (2)','2017-07-26 00:25:45','0','','');
INSERT INTO `glpi_logs` VALUES ('683','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:26:42','0','','montaje o edición de curso');
INSERT INTO `glpi_logs` VALUES ('684','ITILCategory','6','0','20','Juan David Correa (2)','2017-07-26 00:26:42','0','','');
INSERT INTO `glpi_logs` VALUES ('685','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:27:24','0','','Publicación portales Web');
INSERT INTO `glpi_logs` VALUES ('686','ITILCategory','7','0','20','Juan David Correa (2)','2017-07-26 00:27:24','0','','');
INSERT INTO `glpi_logs` VALUES ('687','ITILCategory','6','','0','Juan David Correa (2)','2017-07-26 00:27:41','14','montaje o edición de curso','Montaje o edición de curso');
INSERT INTO `glpi_logs` VALUES ('688','ITILCategory','6','','0','Juan David Correa (2)','2017-07-26 00:27:41','1','Entornos virtuales > montaje o edición de curso','Entornos virtuales > Montaje o edición de curso');
INSERT INTO `glpi_logs` VALUES ('689','ITILCategory','1','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:28:37','0','','Dificultades con usuario de un sistema');
INSERT INTO `glpi_logs` VALUES ('690','ITILCategory','8','0','20','Juan David Correa (2)','2017-07-26 00:28:37','0','','');
INSERT INTO `glpi_logs` VALUES ('691','ITILCategory','1','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:29:06','0','','Modificar información');
INSERT INTO `glpi_logs` VALUES ('692','ITILCategory','9','0','20','Juan David Correa (2)','2017-07-26 00:29:06','0','','');
INSERT INTO `glpi_logs` VALUES ('693','ITILCategory','1','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:29:24','0','','Generar informe');
INSERT INTO `glpi_logs` VALUES ('694','ITILCategory','10','0','20','Juan David Correa (2)','2017-07-26 00:29:24','0','','');
INSERT INTO `glpi_logs` VALUES ('695','ITILCategory','1','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:29:46','0','','Capacitar sobre uso de un sistema');
INSERT INTO `glpi_logs` VALUES ('696','ITILCategory','11','0','20','Juan David Correa (2)','2017-07-26 00:29:46','0','','');
INSERT INTO `glpi_logs` VALUES ('697','ITILCategory','1','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:30:28','0','','Sistema fuera de linea');
INSERT INTO `glpi_logs` VALUES ('698','ITILCategory','12','0','20','Juan David Correa (2)','2017-07-26 00:30:28','0','','');
INSERT INTO `glpi_logs` VALUES ('699','ITILCategory','4','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:31:58','0','','Impresora no funciona');
INSERT INTO `glpi_logs` VALUES ('700','ITILCategory','13','0','20','Juan David Correa (2)','2017-07-26 00:31:58','0','','');
INSERT INTO `glpi_logs` VALUES ('701','ITILCategory','4','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:32:16','0','','Instalar software');
INSERT INTO `glpi_logs` VALUES ('702','ITILCategory','14','0','20','Juan David Correa (2)','2017-07-26 00:32:16','0','','');
INSERT INTO `glpi_logs` VALUES ('703','ITILCategory','4','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:32:34','0','','Computador no funciona');
INSERT INTO `glpi_logs` VALUES ('704','ITILCategory','15','0','20','Juan David Correa (2)','2017-07-26 00:32:34','0','','');
INSERT INTO `glpi_logs` VALUES ('705','ITILCategory','4','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:32:52','0','','Problemas de red');
INSERT INTO `glpi_logs` VALUES ('706','ITILCategory','16','0','20','Juan David Correa (2)','2017-07-26 00:32:52','0','','');
INSERT INTO `glpi_logs` VALUES ('707','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 00:34:17','0','','Reserva sala Webex');
INSERT INTO `glpi_logs` VALUES ('708','ITILCategory','17','0','20','Juan David Correa (2)','2017-07-26 00:34:17','0','','');
INSERT INTO `glpi_logs` VALUES ('709','ITILCategory','7','','0','Juan David Correa (2)','2017-07-26 09:44:16','14','Publicación portales Web','Publicación pagina web U de A');
INSERT INTO `glpi_logs` VALUES ('710','ITILCategory','7','','0','Juan David Correa (2)','2017-07-26 09:44:16','1','Entornos virtuales > Publicación portales Web','Entornos virtuales > Publicación pagina web U de A');
INSERT INTO `glpi_logs` VALUES ('711','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 09:45:11','0','','Publicación portal Campus virtual Salud Pública CVSP');
INSERT INTO `glpi_logs` VALUES ('712','ITILCategory','18','0','20','Juan David Correa (2)','2017-07-26 09:45:11','0','','');
INSERT INTO `glpi_logs` VALUES ('713','ITILCategory','7','','0','Juan David Correa (2)','2017-07-26 09:48:36','14','Publicación pagina web U de A','Publicación Portal Web U de A');
INSERT INTO `glpi_logs` VALUES ('714','ITILCategory','7','','0','Juan David Correa (2)','2017-07-26 09:48:36','1','Entornos virtuales > Publicación pagina web U de A','Entornos virtuales > Publicación Portal Web U de A');
INSERT INTO `glpi_logs` VALUES ('715','ITILCategory','19','0','20','Juan David Correa (2)','2017-07-26 09:49:00','0','','');
INSERT INTO `glpi_logs` VALUES ('716','ITILCategory','6','','0','Juan David Correa (2)','2017-07-26 09:49:47','14','Montaje o edición de curso','Montaje de curso');
INSERT INTO `glpi_logs` VALUES ('717','ITILCategory','6','','0','Juan David Correa (2)','2017-07-26 09:49:47','1','Entornos virtuales > Montaje o edición de curso','Entornos virtuales > Montaje de curso');
INSERT INTO `glpi_logs` VALUES ('718','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 09:50:54','0','','Implementación recurso educativo');
INSERT INTO `glpi_logs` VALUES ('719','ITILCategory','20','0','20','Juan David Correa (2)','2017-07-26 09:50:54','0','','');
INSERT INTO `glpi_logs` VALUES ('720','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 09:54:57','0','','Edición y ajustes curso EVA');
INSERT INTO `glpi_logs` VALUES ('721','ITILCategory','21','0','20','Juan David Correa (2)','2017-07-26 09:54:57','0','','');
INSERT INTO `glpi_logs` VALUES ('722','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 09:55:20','0','','Capacitación en Webex');
INSERT INTO `glpi_logs` VALUES ('723','ITILCategory','22','0','20','Juan David Correa (2)','2017-07-26 09:55:20','0','','');
INSERT INTO `glpi_logs` VALUES ('724','ITILCategory','17','','0','Juan David Correa (2)','2017-07-26 09:56:54','14','Reserva sala Webex','Reserva sala Webex y sala de videoconferencia 417');
INSERT INTO `glpi_logs` VALUES ('725','ITILCategory','17','','0','Juan David Correa (2)','2017-07-26 09:56:54','1','Entornos virtuales > Reserva sala Webex','Entornos virtuales > Reserva sala Webex y sala de videoconferencia 417');
INSERT INTO `glpi_logs` VALUES ('726','ITILCategory','3','ITILCategory','17','Juan David Correa (2)','2017-07-26 09:57:28','0','','Apoyo en videoconferencia');
INSERT INTO `glpi_logs` VALUES ('727','ITILCategory','23','0','20','Juan David Correa (2)','2017-07-26 09:57:28','0','','');
INSERT INTO `glpi_logs` VALUES ('728','User','2','UserEmail','18','Juan David Correa (2)','2017-07-26 09:59:50','0','juan.corea2@udea.edu.co','juan.correa2@udea.edu.co');
INSERT INTO `glpi_logs` VALUES ('729','ITILCategory','8','','0','Juan David Correa (2)','2017-07-26 10:02:25','14','Dificultades con usuario de un sistema','Soporte de software');
INSERT INTO `glpi_logs` VALUES ('730','ITILCategory','8','','0','Juan David Correa (2)','2017-07-26 10:02:25','1','Sistemas > Dificultades con usuario de un sistema','Sistemas > Soporte de software');
INSERT INTO `glpi_logs` VALUES ('731','ITILCategory','9','','0','Juan David Correa (2)','2017-07-26 10:03:50','14','Modificar información','Modificar información en base de datos');
INSERT INTO `glpi_logs` VALUES ('732','ITILCategory','9','','0','Juan David Correa (2)','2017-07-26 10:03:50','1','Sistemas > Modificar información','Sistemas > Modificar información en base de datos');
INSERT INTO `glpi_logs` VALUES ('733','ITILCategory','9','','0','Juan David Correa (2)','2017-07-26 10:04:18','14','Modificar información en base de datos','Actualizar información en base de datos');
INSERT INTO `glpi_logs` VALUES ('734','ITILCategory','9','','0','Juan David Correa (2)','2017-07-26 10:04:18','1','Sistemas > Modificar información en base de datos','Sistemas > Actualizar información en base de datos');
INSERT INTO `glpi_logs` VALUES ('735','ITILCategory','2','','0','Juan David Correa (2)','2017-07-26 10:05:06','14','Creación de usuarios en un sistema','Gestion de usuarios de un sistema');
INSERT INTO `glpi_logs` VALUES ('736','ITILCategory','2','','0','Juan David Correa (2)','2017-07-26 10:05:06','1','Sistemas > Creación de usuarios en un sistema','Sistemas > Gestion de usuarios de un sistema');
INSERT INTO `glpi_logs` VALUES ('737','ITILCategory','2','','0','Juan David Correa (2)','2017-07-26 10:05:57','14','Gestion de usuarios de un sistema','Activación y modificación de usuarios de un sistema');
INSERT INTO `glpi_logs` VALUES ('738','ITILCategory','2','','0','Juan David Correa (2)','2017-07-26 10:05:57','1','Sistemas > Gestion de usuarios de un sistema','Sistemas > Activación y modificación de usuarios de un sistema');
INSERT INTO `glpi_logs` VALUES ('739','Manufacturer','4','0','20','Juan David Correa (2)','2017-07-26 10:09:07','0','','');
INSERT INTO `glpi_logs` VALUES ('740','Manufacturer','5','0','20','Juan David Correa (2)','2017-07-26 10:09:16','0','','');
INSERT INTO `glpi_logs` VALUES ('741','Manufacturer','6','0','20','Juan David Correa (2)','2017-07-26 10:09:21','0','','');
INSERT INTO `glpi_logs` VALUES ('742','Manufacturer','7','0','20','Juan David Correa (2)','2017-07-26 10:09:29','0','','');
INSERT INTO `glpi_logs` VALUES ('743','Manufacturer','8','0','20','Juan David Correa (2)','2017-07-26 10:09:36','0','','');
INSERT INTO `glpi_logs` VALUES ('744','Manufacturer','9','0','20','Juan David Correa (2)','2017-07-26 10:09:53','0','','');
INSERT INTO `glpi_logs` VALUES ('745','Manufacturer','10','0','20','Juan David Correa (2)','2017-07-26 10:10:08','0','','');
INSERT INTO `glpi_logs` VALUES ('746','Manufacturer','11','0','20','Juan David Correa (2)','2017-07-26 10:10:37','0','','');
INSERT INTO `glpi_logs` VALUES ('747','ComputerType','4','0','20','Juan David Correa (2)','2017-07-26 10:15:49','0','','');
INSERT INTO `glpi_logs` VALUES ('748','ComputerType','5','0','20','Juan David Correa (2)','2017-07-26 10:16:06','0','','');
INSERT INTO `glpi_logs` VALUES ('749','ComputerType','6','0','20','Juan David Correa (2)','2017-07-26 10:16:51','0','','');
INSERT INTO `glpi_logs` VALUES ('750','PeripheralType','1','0','20','Juan David Correa (2)','2017-07-26 10:17:55','0','','');
INSERT INTO `glpi_logs` VALUES ('751','PeripheralType','1','','0','Juan David Correa (2)','2017-07-26 10:18:56','1','Camara Web','Camara de video');
INSERT INTO `glpi_logs` VALUES ('752','PeripheralType','2','0','20','Juan David Correa (2)','2017-07-26 10:19:25','0','','');
INSERT INTO `glpi_logs` VALUES ('753','PeripheralType','3','0','20','Juan David Correa (2)','2017-07-26 10:19:59','0','','');
INSERT INTO `glpi_logs` VALUES ('754','ComputerType','5','','0','Juan David Correa (2)','2017-07-26 10:20:28','1','Table PC','Tablet PC');
INSERT INTO `glpi_logs` VALUES ('755','ComputerType','7','0','20','Juan David Correa (2)','2017-07-26 10:21:18','0','','');
INSERT INTO `glpi_logs` VALUES ('756','ComputerType','8','0','20','Juan David Correa (2)','2017-07-26 10:22:05','0','','');
INSERT INTO `glpi_logs` VALUES ('757','NetworkEquipmentType','1','0','20','Juan David Correa (2)','2017-07-26 10:22:23','0','','');
INSERT INTO `glpi_logs` VALUES ('758','NetworkEquipmentType','2','0','20','Juan David Correa (2)','2017-07-26 10:22:34','0','','');
INSERT INTO `glpi_logs` VALUES ('759','NetworkEquipmentType','3','0','20','Juan David Correa (2)','2017-07-26 10:22:59','0','','');
INSERT INTO `glpi_logs` VALUES ('760','NetworkEquipmentType','4','0','20','Juan David Correa (2)','2017-07-26 10:23:10','0','','');
INSERT INTO `glpi_logs` VALUES ('761','NetworkEquipmentType','5','0','20','Juan David Correa (2)','2017-07-26 10:23:20','0','','');
INSERT INTO `glpi_logs` VALUES ('762','NetworkEquipmentType','6','0','20','Juan David Correa (2)','2017-07-26 10:24:00','0','','');
INSERT INTO `glpi_logs` VALUES ('763','NetworkEquipmentType','5','','0','Juan David Correa (2)','2017-07-26 10:24:14','1','Briigde','Brigde');
INSERT INTO `glpi_logs` VALUES ('764','PrinterType','3','','0','Juan David Correa (2)','2017-07-26 10:24:51','1','Impresora Multifuncional','Impresora Multifuncional Laser');
INSERT INTO `glpi_logs` VALUES ('765','PrinterType','5','0','20','Juan David Correa (2)','2017-07-26 10:25:06','0','','');
INSERT INTO `glpi_logs` VALUES ('766','PeripheralType','4','0','20','Juan David Correa (2)','2017-07-26 10:26:24','0','','');
INSERT INTO `glpi_logs` VALUES ('767','State','1','0','20','Juan David Correa (2)','2017-07-26 10:36:01','0','','');
INSERT INTO `glpi_logs` VALUES ('768','State','2','0','20','Juan David Correa (2)','2017-07-26 10:36:12','0','','');
INSERT INTO `glpi_logs` VALUES ('769','State','3','0','20','Juan David Correa (2)','2017-07-26 10:36:38','0','','');
INSERT INTO `glpi_logs` VALUES ('770','NetworkEquipmentType','7','0','20','Juan David Correa (2)','2017-07-26 10:39:37','0','','');
INSERT INTO `glpi_logs` VALUES ('771','OperatingSystem','6','0','20','Juan David Correa (2)','2017-07-26 10:40:43','0','','');
INSERT INTO `glpi_logs` VALUES ('772','ITILCategory','4','ITILCategory','17','Juan David Correa (2)','2017-07-26 10:47:48','0','','Periferico no funciona');
INSERT INTO `glpi_logs` VALUES ('773','ITILCategory','24','0','20','Juan David Correa (2)','2017-07-26 10:47:48','0','','');
INSERT INTO `glpi_logs` VALUES ('774','ITILCategory','4','ITILCategory','17','Juan David Correa (2)','2017-07-26 10:49:17','0','','Problema de sistema operativo');
INSERT INTO `glpi_logs` VALUES ('775','ITILCategory','25','0','20','Juan David Correa (2)','2017-07-26 10:49:17','0','','');
INSERT INTO `glpi_logs` VALUES ('776','ITILCategory','4','ITILCategory','17','Juan David Correa (2)','2017-07-26 10:50:29','0','','Problemas de seguridad y virus');
INSERT INTO `glpi_logs` VALUES ('777','ITILCategory','26','0','20','Juan David Correa (2)','2017-07-26 10:50:29','0','','');
INSERT INTO `glpi_logs` VALUES ('778','ITILCategory','4','ITILCategory','17','Juan David Correa (2)','2017-07-26 10:51:38','0','','Problemas de software de aplicación');
INSERT INTO `glpi_logs` VALUES ('779','ITILCategory','27','0','20','Juan David Correa (2)','2017-07-26 10:51:38','0','','');
INSERT INTO `glpi_logs` VALUES ('780','User','11','UserEmail','17','Juan David Correa (2)','2017-07-27 11:25:52','0','','claudia.jaramillo@udea.edu.co (5)');
INSERT INTO `glpi_logs` VALUES ('781','UserEmail','5','0','20','Juan David Correa (2)','2017-07-27 11:25:52','0','','');
INSERT INTO `glpi_logs` VALUES ('782','User','11','Profile','17','Juan David Correa (2)','2017-07-27 11:25:52','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('783','User','11','0','20','Juan David Correa (2)','2017-07-27 11:25:52','0','','');
INSERT INTO `glpi_logs` VALUES ('784','Group','6','0','20','Juan David Correa (2)','2017-07-27 11:27:42','0','','');
INSERT INTO `glpi_logs` VALUES ('1039','ProfileRight','1170','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1040','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','sla (1171)');
INSERT INTO `glpi_logs` VALUES ('1038','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','show_group_hardware (1170)');
INSERT INTO `glpi_logs` VALUES ('1037','ProfileRight','1169','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1035','ProfileRight','1168','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1036','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','search_config (1169)');
INSERT INTO `glpi_logs` VALUES ('1033','ProfileRight','1167','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1034','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rule_ticket (1168)');
INSERT INTO `glpi_logs` VALUES ('1032','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rule_softwarecategories (1167)');
INSERT INTO `glpi_logs` VALUES ('1030','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rule_mailcollector (1166)');
INSERT INTO `glpi_logs` VALUES ('1031','ProfileRight','1166','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1029','ProfileRight','1165','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1027','ProfileRight','1164','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1028','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rule_ldap (1165)');
INSERT INTO `glpi_logs` VALUES ('1026','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rule_import (1164)');
INSERT INTO `glpi_logs` VALUES ('1025','ProfileRight','1163','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1023','ProfileRight','1162','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1024','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rule_dictionnary_software (1163)');
INSERT INTO `glpi_logs` VALUES ('1022','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rule_dictionnary_printer (1162)');
INSERT INTO `glpi_logs` VALUES ('1020','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rule_dictionnary_dropdown (1161)');
INSERT INTO `glpi_logs` VALUES ('1021','ProfileRight','1161','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1019','ProfileRight','1160','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1017','ProfileRight','1159','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1018','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','rssfeed_public (1160)');
INSERT INTO `glpi_logs` VALUES ('1016','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','reservation (1159)');
INSERT INTO `glpi_logs` VALUES ('1014','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','reports (1158)');
INSERT INTO `glpi_logs` VALUES ('1015','ProfileRight','1158','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1013','ProfileRight','1157','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1011','ProfileRight','1156','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1012','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','reminder_public (1157)');
INSERT INTO `glpi_logs` VALUES ('1010','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','queuedmail (1156)');
INSERT INTO `glpi_logs` VALUES ('1008','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','projecttask (1155)');
INSERT INTO `glpi_logs` VALUES ('1009','ProfileRight','1155','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1007','ProfileRight','1154','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1005','ProfileRight','1153','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1006','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','project (1154)');
INSERT INTO `glpi_logs` VALUES ('1003','ProfileRight','1152','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1004','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','profile (1153)');
INSERT INTO `glpi_logs` VALUES ('1002','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','problem (1152)');
INSERT INTO `glpi_logs` VALUES ('1000','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','printer (1151)');
INSERT INTO `glpi_logs` VALUES ('1001','ProfileRight','1151','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('999','ProfileRight','1150','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('997','ProfileRight','1149','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('998','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','planning (1150)');
INSERT INTO `glpi_logs` VALUES ('996','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','phone (1149)');
INSERT INTO `glpi_logs` VALUES ('994','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','peripheral (1148)');
INSERT INTO `glpi_logs` VALUES ('995','ProfileRight','1148','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('993','ProfileRight','1147','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('991','ProfileRight','1146','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('992','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','password_update (1147)');
INSERT INTO `glpi_logs` VALUES ('989','ProfileRight','1145','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('990','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','notification (1146)');
INSERT INTO `glpi_logs` VALUES ('988','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','networking (1145)');
INSERT INTO `glpi_logs` VALUES ('986','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','netpoint (1144)');
INSERT INTO `glpi_logs` VALUES ('987','ProfileRight','1144','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('985','ProfileRight','1143','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('983','ProfileRight','1142','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('984','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','monitor (1143)');
INSERT INTO `glpi_logs` VALUES ('981','ProfileRight','1141','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('982','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','logs (1142)');
INSERT INTO `glpi_logs` VALUES ('980','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','location (1141)');
INSERT INTO `glpi_logs` VALUES ('978','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','link (1140)');
INSERT INTO `glpi_logs` VALUES ('979','ProfileRight','1140','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('977','ProfileRight','1139','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('975','ProfileRight','1138','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('976','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','license (1139)');
INSERT INTO `glpi_logs` VALUES ('973','ProfileRight','1137','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('974','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','knowbasecategory (1138)');
INSERT INTO `glpi_logs` VALUES ('972','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','knowbase (1137)');
INSERT INTO `glpi_logs` VALUES ('970','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','itilcategory (1136)');
INSERT INTO `glpi_logs` VALUES ('971','ProfileRight','1136','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('968','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','internet (1135)');
INSERT INTO `glpi_logs` VALUES ('969','ProfileRight','1135','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('966','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','infocom (1134)');
INSERT INTO `glpi_logs` VALUES ('967','ProfileRight','1134','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('965','ProfileRight','1133','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('963','ProfileRight','1132','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('964','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','group (1133)');
INSERT INTO `glpi_logs` VALUES ('961','ProfileRight','1131','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('962','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','followup (1132)');
INSERT INTO `glpi_logs` VALUES ('959','ProfileRight','1130','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('960','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','entity (1131)');
INSERT INTO `glpi_logs` VALUES ('957','ProfileRight','1129','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('958','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','dropdown (1130)');
INSERT INTO `glpi_logs` VALUES ('956','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','domain (1129)');
INSERT INTO `glpi_logs` VALUES ('954','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','document (1128)');
INSERT INTO `glpi_logs` VALUES ('955','ProfileRight','1128','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('952','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','device (1127)');
INSERT INTO `glpi_logs` VALUES ('953','ProfileRight','1127','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('951','ProfileRight','1126','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('949','ProfileRight','1125','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('950','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','contract (1126)');
INSERT INTO `glpi_logs` VALUES ('948','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','contact_enterprise (1125)');
INSERT INTO `glpi_logs` VALUES ('946','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','consumable (1124)');
INSERT INTO `glpi_logs` VALUES ('947','ProfileRight','1124','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('945','ProfileRight','1123','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('943','ProfileRight','1122','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('944','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','config (1123)');
INSERT INTO `glpi_logs` VALUES ('941','ProfileRight','1121','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('942','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','computer (1122)');
INSERT INTO `glpi_logs` VALUES ('940','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','changevalidation (1121)');
INSERT INTO `glpi_logs` VALUES ('938','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','change (1120)');
INSERT INTO `glpi_logs` VALUES ('939','ProfileRight','1120','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('937','ProfileRight','1119','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('935','ProfileRight','1118','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('936','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','cartridge (1119)');
INSERT INTO `glpi_logs` VALUES ('933','ProfileRight','1117','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('934','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','calendar (1118)');
INSERT INTO `glpi_logs` VALUES ('932','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','budget (1117)');
INSERT INTO `glpi_logs` VALUES ('930','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','bookmark_public (1116)');
INSERT INTO `glpi_logs` VALUES ('931','ProfileRight','1116','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('929','ProfileRight','1115','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('928','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','backup (1115)');
INSERT INTO `glpi_logs` VALUES ('1041','ProfileRight','1171','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1042','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','software (1172)');
INSERT INTO `glpi_logs` VALUES ('1043','ProfileRight','1172','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1044','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','solutiontemplate (1173)');
INSERT INTO `glpi_logs` VALUES ('1045','ProfileRight','1173','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1046','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','state (1174)');
INSERT INTO `glpi_logs` VALUES ('1047','ProfileRight','1174','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1048','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','statistic (1175)');
INSERT INTO `glpi_logs` VALUES ('1049','ProfileRight','1175','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1050','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','task (1176)');
INSERT INTO `glpi_logs` VALUES ('1051','ProfileRight','1176','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1052','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','taskcategory (1177)');
INSERT INTO `glpi_logs` VALUES ('1053','ProfileRight','1177','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1054','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','ticket (1178)');
INSERT INTO `glpi_logs` VALUES ('1055','ProfileRight','1178','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1056','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','ticketcost (1179)');
INSERT INTO `glpi_logs` VALUES ('1057','ProfileRight','1179','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1058','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','ticketrecurrent (1180)');
INSERT INTO `glpi_logs` VALUES ('1059','ProfileRight','1180','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1060','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','tickettemplate (1181)');
INSERT INTO `glpi_logs` VALUES ('1061','ProfileRight','1181','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1062','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','ticketvalidation (1182)');
INSERT INTO `glpi_logs` VALUES ('1063','ProfileRight','1182','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1064','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','transfer (1183)');
INSERT INTO `glpi_logs` VALUES ('1065','ProfileRight','1183','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1066','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','typedoc (1184)');
INSERT INTO `glpi_logs` VALUES ('1067','ProfileRight','1184','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1068','Profile','13','ProfileRight','17','Juan David Correa (2)','2017-07-27 11:32:10','0','','user (1185)');
INSERT INTO `glpi_logs` VALUES ('1069','ProfileRight','1185','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1070','Profile','13','0','20','Juan David Correa (2)','2017-07-27 11:32:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1071','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','26','0','119');
INSERT INTO `glpi_logs` VALUES ('1072','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','20','0','119');
INSERT INTO `glpi_logs` VALUES ('1073','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','27','0','119');
INSERT INTO `glpi_logs` VALUES ('1074','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','129','0','23');
INSERT INTO `glpi_logs` VALUES ('1075','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','21','0','119');
INSERT INTO `glpi_logs` VALUES ('1076','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','23','0','119');
INSERT INTO `glpi_logs` VALUES ('1077','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','25','0','119');
INSERT INTO `glpi_logs` VALUES ('1078','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','28','0','119');
INSERT INTO `glpi_logs` VALUES ('1079','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','24','0','119');
INSERT INTO `glpi_logs` VALUES ('1080','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:32:46','22','0','119');
INSERT INTO `glpi_logs` VALUES ('1081','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:33:30','87','','[]');
INSERT INTO `glpi_logs` VALUES ('1082','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:33:30','102','0','261151');
INSERT INTO `glpi_logs` VALUES ('1083','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:33:30','119','0','23');
INSERT INTO `glpi_logs` VALUES ('1084','Profile','13','','0','Juan David Correa (2)','2017-07-27 11:33:30','103','0','23');
INSERT INTO `glpi_logs` VALUES ('1085','User','7','Group','16','Juan David Correa (2)','2017-07-27 11:34:58','0','Soporte tecnico (1)','');
INSERT INTO `glpi_logs` VALUES ('1086','Group','1','User','16','Juan David Correa (2)','2017-07-27 11:34:58','0','Carlos Alberto Tangarife (7)','');
INSERT INTO `glpi_logs` VALUES ('1087','User','6','Group','16','Juan David Correa (2)','2017-07-27 11:34:58','0','Soporte tecnico (1)','');
INSERT INTO `glpi_logs` VALUES ('1088','Group','1','User','16','Juan David Correa (2)','2017-07-27 11:34:58','0','Felipe Becerra (6)','');
INSERT INTO `glpi_logs` VALUES ('1089','User','8','Group','15','Juan David Correa (2)','2017-07-27 11:35:48','0','','Soporte tecnico (1)');
INSERT INTO `glpi_logs` VALUES ('1090','Group','1','User','15','Juan David Correa (2)','2017-07-27 11:35:48','0','','prueba prueba (8)');
INSERT INTO `glpi_logs` VALUES ('1091','ComputerModel','1','0','20','Felipe Becerra (6)','2017-08-10 10:43:35','0','','');
INSERT INTO `glpi_logs` VALUES ('1092','ComputerModel','2','0','20','Felipe Becerra (6)','2017-08-10 10:43:59','0','','');
INSERT INTO `glpi_logs` VALUES ('1093','ComputerModel','3','0','20','Felipe Becerra (6)','2017-08-10 10:44:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1094','ComputerModel','4','0','20','Felipe Becerra (6)','2017-08-10 10:44:35','0','','');
INSERT INTO `glpi_logs` VALUES ('1095','ComputerModel','5','0','20','Felipe Becerra (6)','2017-08-10 10:44:48','0','','');
INSERT INTO `glpi_logs` VALUES ('1096','ComputerModel','6','0','20','Felipe Becerra (6)','2017-08-10 10:45:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1097','ComputerModel','7','0','20','Felipe Becerra (6)','2017-08-10 10:46:04','0','','');
INSERT INTO `glpi_logs` VALUES ('1098','ComputerModel','8','0','20','Felipe Becerra (6)','2017-08-10 10:46:16','0','','');
INSERT INTO `glpi_logs` VALUES ('1099','ComputerModel','9','0','20','Felipe Becerra (6)','2017-08-10 10:46:34','0','','');
INSERT INTO `glpi_logs` VALUES ('1100','ComputerModel','10','0','20','Felipe Becerra (6)','2017-08-10 10:46:46','0','','');
INSERT INTO `glpi_logs` VALUES ('1101','ComputerModel','11','0','20','Felipe Becerra (6)','2017-08-10 10:47:01','0','','');
INSERT INTO `glpi_logs` VALUES ('1102','ComputerModel','12','0','20','Felipe Becerra (6)','2017-08-10 10:47:21','0','','');
INSERT INTO `glpi_logs` VALUES ('1103','ComputerModel','13','0','20','Felipe Becerra (6)','2017-08-10 10:47:41','0','','');
INSERT INTO `glpi_logs` VALUES ('1104','ComputerModel','14','0','20','Felipe Becerra (6)','2017-08-10 10:48:01','0','','');
INSERT INTO `glpi_logs` VALUES ('1105','ComputerModel','15','0','20','Felipe Becerra (6)','2017-08-10 10:48:14','0','','');
INSERT INTO `glpi_logs` VALUES ('1106','ComputerModel','16','0','20','Felipe Becerra (6)','2017-08-10 10:48:27','0','','');
INSERT INTO `glpi_logs` VALUES ('1107','ComputerModel','17','0','20','Felipe Becerra (6)','2017-08-10 10:49:39','0','','');
INSERT INTO `glpi_logs` VALUES ('1108','ComputerModel','18','0','20','Felipe Becerra (6)','2017-08-10 10:49:55','0','','');
INSERT INTO `glpi_logs` VALUES ('1109','ComputerModel','19','0','20','Felipe Becerra (6)','2017-08-10 10:53:50','0','','');
INSERT INTO `glpi_logs` VALUES ('1110','ComputerModel','20','0','20','Felipe Becerra (6)','2017-08-10 10:54:11','0','','');
INSERT INTO `glpi_logs` VALUES ('1111','ComputerModel','21','0','20','Felipe Becerra (6)','2017-08-10 10:55:00','0','','');
INSERT INTO `glpi_logs` VALUES ('1112','ComputerModel','22','0','20','Felipe Becerra (6)','2017-08-10 10:55:19','0','','');
INSERT INTO `glpi_logs` VALUES ('1113','ComputerModel','23','0','20','Felipe Becerra (6)','2017-08-10 10:55:41','0','','');
INSERT INTO `glpi_logs` VALUES ('1114','ComputerModel','24','0','20','Felipe Becerra (6)','2017-08-10 10:58:59','0','','');
INSERT INTO `glpi_logs` VALUES ('1115','ComputerModel','25','0','20','Felipe Becerra (6)','2017-08-10 10:59:16','0','','');
INSERT INTO `glpi_logs` VALUES ('1123','PhoneModel','1','0','20','Felipe Becerra (6)','2017-08-10 11:25:19','0','','');
INSERT INTO `glpi_logs` VALUES ('1124','OperatingSystemArchitecture','1','0','20','Felipe Becerra (6)','2017-08-10 11:28:35','0','','');
INSERT INTO `glpi_logs` VALUES ('1122','PrinterModel','68','0','20','Felipe Becerra (6)','2017-08-10 11:07:30','0','','');
INSERT INTO `glpi_logs` VALUES ('1121','PrinterModel','67','0','20','Felipe Becerra (6)','2017-08-10 11:07:10','0','','');
INSERT INTO `glpi_logs` VALUES ('1120','PrinterModel','66','0','20','Felipe Becerra (6)','2017-08-10 11:06:49','0','','');
INSERT INTO `glpi_logs` VALUES ('1125','OperatingSystemArchitecture','2','0','20','Felipe Becerra (6)','2017-08-10 11:28:46','0','','');
INSERT INTO `glpi_logs` VALUES ('1126','TicketTemplate','3','0','20','Juan David Correa (2)','2017-08-15 22:48:13','0','','');
INSERT INTO `glpi_logs` VALUES ('1127','ITILCategory','3','','0','Juan David Correa (2)','2017-08-15 22:48:28','72','&nbsp; (0)','Entornos virtuales (3)');
INSERT INTO `glpi_logs` VALUES ('1128','Notification','2','','0','Juan David Correa (2)','2017-08-15 22:54:51','4','Tickets (4)','Tickets (Simple) (5)');
INSERT INTO `glpi_logs` VALUES ('1129','Notification','2','NotificationTargetTicket','19','Juan David Correa (2)','2017-08-15 22:57:24','0','N/A (3)','');
INSERT INTO `glpi_logs` VALUES ('1130','Notification','2','NotificationTargetTicket','19','Juan David Correa (2)','2017-08-15 22:57:24','0','Watcher (34)','');
INSERT INTO `glpi_logs` VALUES ('1131','TicketTemplate','1','TicketTemplatePredefinedField','17','Juan David Correa (2)','2017-08-15 22:59:21','0','','Título (1)');
INSERT INTO `glpi_logs` VALUES ('1132','TicketTemplatePredefinedField','1','0','20','Juan David Correa (2)','2017-08-15 22:59:21','0','','');
INSERT INTO `glpi_logs` VALUES ('1133','TicketTemplate','1','TicketTemplatePredefinedField','17','Juan David Correa (2)','2017-08-15 22:59:35','0','','Ubicación (2)');
INSERT INTO `glpi_logs` VALUES ('1134','TicketTemplatePredefinedField','2','0','20','Juan David Correa (2)','2017-08-15 22:59:35','0','','');
INSERT INTO `glpi_logs` VALUES ('1135','TicketTemplate','1','TicketTemplatePredefinedField','17','Juan David Correa (2)','2017-08-15 22:59:50','0','','Categoría (3)');
INSERT INTO `glpi_logs` VALUES ('1136','TicketTemplatePredefinedField','3','0','20','Juan David Correa (2)','2017-08-15 22:59:50','0','','');
INSERT INTO `glpi_logs` VALUES ('1137','TicketTemplate','1','TicketTemplatePredefinedField','17','Juan David Correa (2)','2017-08-15 22:59:58','0','','Descripción (4)');
INSERT INTO `glpi_logs` VALUES ('1138','TicketTemplatePredefinedField','4','0','20','Juan David Correa (2)','2017-08-15 22:59:58','0','','');
INSERT INTO `glpi_logs` VALUES ('1139','ITILCategory','22','','0','Juan David Correa (2)','2017-08-15 23:04:42','73','&nbsp; (0)','Entornos virtuales (3)');
INSERT INTO `glpi_logs` VALUES ('1140','Notification','2','','0','Juan David Correa (2)','2017-08-15 23:06:05','4','Tickets (Simple) (5)','Tickets (4)');
INSERT INTO `glpi_logs` VALUES ('1141','Ticket','1','User','15','Claudia Marleny Jaramillo (11)','2017-08-15 23:57:38','0','','Claudia Marleny Jaramillo (11)');
INSERT INTO `glpi_logs` VALUES ('1142','Ticket','1','0','20','Claudia Marleny Jaramillo (11)','2017-08-15 23:57:38','0','','');
INSERT INTO `glpi_logs` VALUES ('1143','Ticket','1','','0','Claudia Marleny Jaramillo (11)','2017-08-15 23:59:29','7','Comunicaciones (19)','Sistemas > Activación y modificación de usuarios de un sistema (2)');
INSERT INTO `glpi_logs` VALUES ('1144','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:00:23','150','0','165');
INSERT INTO `glpi_logs` VALUES ('1145','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:00:23','64','43157733 (11)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1146','Ticket','1','User','15','Juan David Correa (2)','2017-08-16 00:00:23','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1147','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:00:23','12','1','2');
INSERT INTO `glpi_logs` VALUES ('1148','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:00:23','64','43157733 (11)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1149','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:01:12','24','','&lt;p&gt;Se dio solucion al incidente&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1150','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:01:12','12','2','6');
INSERT INTO `glpi_logs` VALUES ('1151','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:01:12','16','','2017-08-16 00:01:12');
INSERT INTO `glpi_logs` VALUES ('1152','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:01:12','17','','2017-08-16 00:01:12');
INSERT INTO `glpi_logs` VALUES ('1153','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:05:21','12','6','2');
INSERT INTO `glpi_logs` VALUES ('1154','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:05:21','17','2017-08-16 00:01:12','NULL');
INSERT INTO `glpi_logs` VALUES ('1155','Ticket','1','','0','Juan David Correa (2)','2017-08-16 00:05:21','16','2017-08-16 00:01:12','NULL');
INSERT INTO `glpi_logs` VALUES ('1156','ITILCategory','19','','0','Juan David Correa (2)','2017-08-18 11:21:23','3','1','0');
INSERT INTO `glpi_logs` VALUES ('1157','ITILCategory','19','ITILCategory','17','Juan David Correa (2)','2017-08-18 12:56:21','0','','Diseño de piezas gráfica');
INSERT INTO `glpi_logs` VALUES ('1158','ITILCategory','28','0','20','Juan David Correa (2)','2017-08-18 12:56:21','0','','');
INSERT INTO `glpi_logs` VALUES ('1159','User','11','Group','15','Juan David Correa (2)','2017-08-18 12:56:47','0','','Comunicaciones (6)');
INSERT INTO `glpi_logs` VALUES ('1160','Group','6','User','15','Juan David Correa (2)','2017-08-18 12:56:47','0','','Claudia Marleny Jaramillo (11)');
INSERT INTO `glpi_logs` VALUES ('1161','ITILCategory','19','ITILCategory','17','Juan David Correa (2)','2017-08-18 12:58:27','0','','Producción de video');
INSERT INTO `glpi_logs` VALUES ('1162','ITILCategory','29','0','20','Juan David Correa (2)','2017-08-18 12:58:27','0','','');
INSERT INTO `glpi_logs` VALUES ('1163','ITILCategory','19','ITILCategory','17','Juan David Correa (2)','2017-08-18 12:58:48','0','','Cubrimiento comunicacional de evento');
INSERT INTO `glpi_logs` VALUES ('1164','ITILCategory','30','0','20','Juan David Correa (2)','2017-08-18 12:58:48','0','','');
INSERT INTO `glpi_logs` VALUES ('1165','ITILCategory','19','ITILCategory','17','Juan David Correa (2)','2017-08-18 12:59:28','0','','Publicación en medios institucionales');
INSERT INTO `glpi_logs` VALUES ('1166','ITILCategory','31','0','20','Juan David Correa (2)','2017-08-18 12:59:28','0','','');
INSERT INTO `glpi_logs` VALUES ('1167','ITILCategory','19','ITILCategory','17','Juan David Correa (2)','2017-08-18 13:00:33','0','','Apoyo o coordinación de eventos');
INSERT INTO `glpi_logs` VALUES ('1168','ITILCategory','32','0','20','Juan David Correa (2)','2017-08-18 13:00:33','0','','');
INSERT INTO `glpi_logs` VALUES ('1169','ITILCategory','19','ITILCategory','17','Juan David Correa (2)','2017-08-18 13:00:49','0','','Cubrimiento comunicacional de evento');
INSERT INTO `glpi_logs` VALUES ('1170','ITILCategory','33','0','20','Juan David Correa (2)','2017-08-18 13:00:49','0','','');
INSERT INTO `glpi_logs` VALUES ('1171','ITILCategory','19','ITILCategory','17','Juan David Correa (2)','2017-08-18 13:01:17','0','','Producción periodística para boletines');
INSERT INTO `glpi_logs` VALUES ('1172','ITILCategory','34','0','20','Juan David Correa (2)','2017-08-18 13:01:17','0','','');
INSERT INTO `glpi_logs` VALUES ('1173','ITILCategory','19','ITILCategory','17','Juan David Correa (2)','2017-08-18 13:01:25','0','','Asesoría y consultoría en comunicaciones');
INSERT INTO `glpi_logs` VALUES ('1174','ITILCategory','35','0','20','Juan David Correa (2)','2017-08-18 13:01:25','0','','');
INSERT INTO `glpi_logs` VALUES ('1175','Profile','13','','0','Juan David Correa (2)','2017-08-18 13:05:41','1','Técnicos en soporte','Soporte');
INSERT INTO `glpi_logs` VALUES ('1176','User','11','Profile','17','Juan David Correa (2)','2017-08-18 13:06:16','0','','Soporte (13)');
INSERT INTO `glpi_logs` VALUES ('1177','User','11','','0','Juan David Correa (2)','2017-08-18 13:06:25','20','&nbsp; (0)','Soporte (13)');
INSERT INTO `glpi_logs` VALUES ('1178','ITILCategory','32','','0','Juan David Correa (2)','2017-08-18 13:07:26','70','&nbsp; (0)','43157733 (11)');
INSERT INTO `glpi_logs` VALUES ('1179','ITILCategory','35','','0','Juan David Correa (2)','2017-08-18 13:07:37','70','&nbsp; (0)','43157733 (11)');
INSERT INTO `glpi_logs` VALUES ('1180','ITILCategory','30','','0','Juan David Correa (2)','2017-08-18 13:07:45','70','&nbsp; (0)','43157733 (11)');
INSERT INTO `glpi_logs` VALUES ('1181','ITILCategory','33','','0','Juan David Correa (2)','2017-08-18 13:07:52','70','&nbsp; (0)','43157733 (11)');
INSERT INTO `glpi_logs` VALUES ('1182','ITILCategory','28','','0','Juan David Correa (2)','2017-08-18 13:08:00','70','&nbsp; (0)','43157733 (11)');
INSERT INTO `glpi_logs` VALUES ('1183','ITILCategory','29','','0','Juan David Correa (2)','2017-08-18 13:08:07','70','&nbsp; (0)','43157733 (11)');
INSERT INTO `glpi_logs` VALUES ('1184','ITILCategory','34','','0','Juan David Correa (2)','2017-08-18 13:08:14','70','&nbsp; (0)','43157733 (11)');
INSERT INTO `glpi_logs` VALUES ('1185','ITILCategory','31','','0','Juan David Correa (2)','2017-08-18 13:08:21','70','&nbsp; (0)','43157733 (11)');
INSERT INTO `glpi_logs` VALUES ('1186','ITILCategory','19','','0','Juan David Correa (2)','2017-08-18 13:08:55','86','0','1');
INSERT INTO `glpi_logs` VALUES ('1187','ITILCategory','19','','0','Juan David Correa (2)','2017-08-18 13:10:51','71','&nbsp; (0)','Comunicaciones (6)');
INSERT INTO `glpi_logs` VALUES ('1188','ITILCategory','19','','0','Juan David Correa (2)','2017-08-18 13:10:51','74','1','0');
INSERT INTO `glpi_logs` VALUES ('1189','ITILCategory','19','','0','Juan David Correa (2)','2017-08-18 13:10:51','75','1','0');
INSERT INTO `glpi_logs` VALUES ('1190','ITILCategory','19','','0','Juan David Correa (2)','2017-08-18 13:10:51','76','1','0');
INSERT INTO `glpi_logs` VALUES ('1191','ITILCategory','19','','0','Juan David Correa (2)','2017-08-18 13:10:51','85','1','0');
INSERT INTO `glpi_logs` VALUES ('1192','ITILCategory','3','','0','Juan David Correa (2)','2017-08-18 13:11:52','86','0','1');
INSERT INTO `glpi_logs` VALUES ('1193','ITILCategory','3','','0','Juan David Correa (2)','2017-08-18 13:11:52','3','1','0');
INSERT INTO `glpi_logs` VALUES ('1194','ITILCategory','3','','0','Juan David Correa (2)','2017-08-18 13:11:52','74','1','0');
INSERT INTO `glpi_logs` VALUES ('1195','ITILCategory','3','','0','Juan David Correa (2)','2017-08-18 13:11:52','75','1','0');
INSERT INTO `glpi_logs` VALUES ('1196','ITILCategory','3','','0','Juan David Correa (2)','2017-08-18 13:11:52','76','1','0');
INSERT INTO `glpi_logs` VALUES ('1197','ITILCategory','3','','0','Juan David Correa (2)','2017-08-18 13:11:52','85','1','0');
INSERT INTO `glpi_logs` VALUES ('1198','ITILCategory','3','','0','Juan David Correa (2)','2017-08-18 13:11:52','72','Entornos virtuales (3)','&nbsp; (0)');
INSERT INTO `glpi_logs` VALUES ('1199','ITILCategory','3','','0','Juan David Correa (2)','2017-08-18 13:12:24','70','&nbsp; (0)','paula.hincapie (10)');
INSERT INTO `glpi_logs` VALUES ('1200','ITILCategory','1','','0','Juan David Correa (2)','2017-08-18 13:12:43','86','0','1');
INSERT INTO `glpi_logs` VALUES ('1201','ITILCategory','1','','0','Juan David Correa (2)','2017-08-18 13:12:43','3','1','0');
INSERT INTO `glpi_logs` VALUES ('1202','ITILCategory','1','','0','Juan David Correa (2)','2017-08-18 13:12:43','74','1','0');
INSERT INTO `glpi_logs` VALUES ('1203','ITILCategory','1','','0','Juan David Correa (2)','2017-08-18 13:12:43','75','1','0');
INSERT INTO `glpi_logs` VALUES ('1204','ITILCategory','1','','0','Juan David Correa (2)','2017-08-18 13:12:43','76','1','0');
INSERT INTO `glpi_logs` VALUES ('1205','ITILCategory','1','','0','Juan David Correa (2)','2017-08-18 13:12:43','85','1','0');
INSERT INTO `glpi_logs` VALUES ('1206','ITILCategory','4','','0','Juan David Correa (2)','2017-08-18 13:13:29','3','1','0');
INSERT INTO `glpi_logs` VALUES ('1207','ITILCategory','4','','0','Juan David Correa (2)','2017-08-18 13:13:29','74','1','0');
INSERT INTO `glpi_logs` VALUES ('1208','ITILCategory','4','','0','Juan David Correa (2)','2017-08-18 13:13:29','75','1','0');
INSERT INTO `glpi_logs` VALUES ('1209','ITILCategory','4','','0','Juan David Correa (2)','2017-08-18 13:13:29','76','1','0');
INSERT INTO `glpi_logs` VALUES ('1210','ITILCategory','4','','0','Juan David Correa (2)','2017-08-18 13:13:29','85','1','0');
INSERT INTO `glpi_logs` VALUES ('1211','Ticket','2','User','15','prueba prueba (8)','2017-11-02 15:48:00','0','','prueba prueba (8)');
INSERT INTO `glpi_logs` VALUES ('1212','Ticket','2','User','15','prueba prueba (8)','2017-11-02 15:48:00','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1213','Ticket','2','0','20','prueba prueba (8)','2017-11-02 15:48:00','0','','');
INSERT INTO `glpi_logs` VALUES ('1214','Ticket','2','','0','Juan David Correa (2)','2017-11-03 11:28:16','12','1','5');
INSERT INTO `glpi_logs` VALUES ('1215','Ticket','2','','0','Juan David Correa (2)','2017-11-03 11:28:16','64','prueba (8)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1216','Ticket','2','','0','Juan David Correa (2)','2017-11-03 11:28:16','17','','2017-11-03 11:28:16');
INSERT INTO `glpi_logs` VALUES ('1217','User','12','UserEmail','17','Juan David Correa (2)','2017-11-07 15:41:31','0','','maria-epr@hotmail.com (6)');
INSERT INTO `glpi_logs` VALUES ('1218','UserEmail','6','0','20','Juan David Correa (2)','2017-11-07 15:41:31','0','','');
INSERT INTO `glpi_logs` VALUES ('1219','User','12','Profile','17','Juan David Correa (2)','2017-11-07 15:41:31','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('1220','User','12','0','20','Juan David Correa (2)','2017-11-07 15:41:31','0','','');
INSERT INTO `glpi_logs` VALUES ('1221','User','13','UserEmail','17','Juan David Correa (2)','2017-11-07 15:45:09','0','','sjechavarria@gmail.com (7)');
INSERT INTO `glpi_logs` VALUES ('1222','UserEmail','7','0','20','Juan David Correa (2)','2017-11-07 15:45:09','0','','');
INSERT INTO `glpi_logs` VALUES ('1223','User','13','UserEmail','17','Juan David Correa (2)','2017-11-07 15:45:09','0','','juliet.echavarria@udea.edu.co (8)');
INSERT INTO `glpi_logs` VALUES ('1224','UserEmail','8','0','20','Juan David Correa (2)','2017-11-07 15:45:09','0','','');
INSERT INTO `glpi_logs` VALUES ('1225','User','13','Profile','17','Juan David Correa (2)','2017-11-07 15:45:09','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('1226','User','13','0','20','Juan David Correa (2)','2017-11-07 15:45:09','0','','');
INSERT INTO `glpi_logs` VALUES ('1227','User','14','UserEmail','17','Juan David Correa (2)','2017-11-07 15:46:31','0','','asistenciacontratacioncifnsp@udea.edu.co (9)');
INSERT INTO `glpi_logs` VALUES ('1228','UserEmail','9','0','20','Juan David Correa (2)','2017-11-07 15:46:31','0','','');
INSERT INTO `glpi_logs` VALUES ('1229','User','14','Profile','17','Juan David Correa (2)','2017-11-07 15:46:31','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('1230','User','14','0','20','Juan David Correa (2)','2017-11-07 15:46:31','0','','');
INSERT INTO `glpi_logs` VALUES ('1231','User','15','UserEmail','17','Juan David Correa (2)','2017-11-07 16:00:37','0','','saira.chaverra@udea.edu.co (10)');
INSERT INTO `glpi_logs` VALUES ('1232','UserEmail','10','0','20','Juan David Correa (2)','2017-11-07 16:00:37','0','','');
INSERT INTO `glpi_logs` VALUES ('1233','User','15','Profile','17','Juan David Correa (2)','2017-11-07 16:00:37','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('1234','User','15','0','20','Juan David Correa (2)','2017-11-07 16:00:37','0','','');
INSERT INTO `glpi_logs` VALUES ('1235','User','16','UserEmail','17','Juan David Correa (2)','2017-11-07 16:03:49','0','','erika.alzate1416@gmail.com (11)');
INSERT INTO `glpi_logs` VALUES ('1236','UserEmail','11','0','20','Juan David Correa (2)','2017-11-07 16:03:49','0','','');
INSERT INTO `glpi_logs` VALUES ('1237','User','16','Profile','17','Juan David Correa (2)','2017-11-07 16:03:49','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('1238','User','16','0','20','Juan David Correa (2)','2017-11-07 16:03:49','0','','');
INSERT INTO `glpi_logs` VALUES ('1239','User','17','UserEmail','17','Juan David Correa (2)','2017-11-07 16:08:23','0','','nelly.zapata@udea.edu.co (12)');
INSERT INTO `glpi_logs` VALUES ('1240','UserEmail','12','0','20','Juan David Correa (2)','2017-11-07 16:08:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1241','User','17','Profile','17','Juan David Correa (2)','2017-11-07 16:08:23','0','','Solicitante (10)');
INSERT INTO `glpi_logs` VALUES ('1242','User','17','0','20','Juan David Correa (2)','2017-11-07 16:08:23','0','','');
INSERT INTO `glpi_logs` VALUES ('1243','Ticket','3','User','15','Luz Nelly Zapata Villarreal (17)','2017-11-07 16:14:00','0','','Luz Nelly Zapata Villarreal (17)');
INSERT INTO `glpi_logs` VALUES ('1244','Ticket','3','0','20','Luz Nelly Zapata Villarreal (17)','2017-11-07 16:14:00','0','','');
INSERT INTO `glpi_logs` VALUES ('1245','ITILCategory','4','','0','Juan David Correa (2)','2017-11-07 17:02:43','86','0','1');
INSERT INTO `glpi_logs` VALUES ('1246','ITILCategory','4','','0','Juan David Correa (2)','2017-11-07 17:03:42','86','1','0');
INSERT INTO `glpi_logs` VALUES ('1247','Ticket','4','User','15','Lina Maria  Ospina Perez (14)','2017-11-14 10:40:42','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1248','Ticket','4','User','15','Lina Maria  Ospina Perez (14)','2017-11-14 10:40:42','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1249','Ticket','4','0','20','Lina Maria  Ospina Perez (14)','2017-11-14 10:40:42','0','','');
INSERT INTO `glpi_logs` VALUES ('1250','Location','14','Location','17','Juan David Correa (2)','2017-11-14 15:59:42','0','','33-232 Jefe Centro investigación');
INSERT INTO `glpi_logs` VALUES ('1251','Location','78','0','20','Juan David Correa (2)','2017-11-14 15:59:42','0','','');
INSERT INTO `glpi_logs` VALUES ('1252','Location','47','','0','Juan David Correa (2)','2017-11-14 16:00:28','14','33-232 Jefe Basicas','33-237 Aistencia CI- FNSP');
INSERT INTO `glpi_logs` VALUES ('1253','Location','47','','0','Juan David Correa (2)','2017-11-14 16:00:28','11','33-232','33-237');
INSERT INTO `glpi_logs` VALUES ('1254','Location','47','','0','Juan David Correa (2)','2017-11-14 16:00:28','12','33-232','33-237');
INSERT INTO `glpi_logs` VALUES ('1255','Location','47','','0','Juan David Correa (2)','2017-11-14 16:00:28','1','Piso 2 > 33-232 Jefe Basicas','Piso 2 > 33-237 Aistencia CI- FNSP');
INSERT INTO `glpi_logs` VALUES ('1256','Location','78','','0','Juan David Correa (2)','2017-11-14 16:00:48','11','','33-232');
INSERT INTO `glpi_logs` VALUES ('1257','Location','78','','0','Juan David Correa (2)','2017-11-14 16:00:48','12','','33-232');
INSERT INTO `glpi_logs` VALUES ('1258','Location','47','','0','Juan David Correa (2)','2017-11-14 16:01:03','14','33-237 Aistencia CI- FNSP','33-237 Asistencia CI- FNSP');
INSERT INTO `glpi_logs` VALUES ('1259','Location','47','','0','Juan David Correa (2)','2017-11-14 16:01:03','1','Piso 2 > 33-237 Aistencia CI- FNSP','Piso 2 > 33-237 Asistencia CI- FNSP');
INSERT INTO `glpi_logs` VALUES ('1260','Ticket','4','','0','Juan David Correa (2)','2017-11-14 16:04:18','155','','2017-11-14 10:50');
INSERT INTO `glpi_logs` VALUES ('1261','Ticket','4','','0','Juan David Correa (2)','2017-11-14 16:04:18','18','','2017-11-14 10:55');
INSERT INTO `glpi_logs` VALUES ('1262','Ticket','4','','0','Juan David Correa (2)','2017-11-14 16:04:18','83','&nbsp; (0)','Piso 2 > 33-237 Asistencia CI- FNSP (47)');
INSERT INTO `glpi_logs` VALUES ('1263','Ticket','4','','0','Juan David Correa (2)','2017-11-14 16:04:18','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1264','Ticket','4','','0','Juan David Correa (2)','2017-11-14 16:05:32','12','1','5');
INSERT INTO `glpi_logs` VALUES ('1265','Ticket','4','','0','Juan David Correa (2)','2017-11-14 16:05:32','17','','2017-11-14 16:05:32');
INSERT INTO `glpi_logs` VALUES ('1266','Change','1','User','15','Juan David Correa (2)','2017-11-14 16:06:07','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1267','Change','1','User','15','Juan David Correa (2)','2017-11-14 16:06:07','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1268','Change','1','Ticket','15','Juan David Correa (2)','2017-11-14 16:06:07','0','','Activación reporte en SISREC (4)');
INSERT INTO `glpi_logs` VALUES ('1269','Ticket','4','Change','15','Juan David Correa (2)','2017-11-14 16:06:07','0','','Activación reporte en SISREC (1)');
INSERT INTO `glpi_logs` VALUES ('1270','Change','1','0','20','Juan David Correa (2)','2017-11-14 16:06:07','0','','');
INSERT INTO `glpi_logs` VALUES ('1271','Change','1','','0','Juan David Correa (2)','2017-11-14 16:06:32','12','7','5');
INSERT INTO `glpi_logs` VALUES ('1272','Change','1','','0','Juan David Correa (2)','2017-11-14 16:06:32','17','','2017-11-14 16:06:32');
INSERT INTO `glpi_logs` VALUES ('1273','Change','1','','0','Juan David Correa (2)','2017-11-14 16:07:51','24','','&lt;p&gt;Se ha realizado la  activación del reporte para el mes de octubre. Ademas, se han agregado las oficinas en el sistema. &lt;/p&gt;rn&lt;p&gt;Un feliz día,&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1274','Change','1','','0','Juan David Correa (2)','2017-11-14 16:07:51','17','2017-11-14 16:06:32','2017-11-14 16:07:51');
INSERT INTO `glpi_logs` VALUES ('1275','Document','1','0','20','Lina Maria  Ospina Perez (14)','2017-11-16 14:59:13','0','','');
INSERT INTO `glpi_logs` VALUES ('1276','Document','1','Ticket','15','Lina Maria  Ospina Perez (14)','2017-11-16 14:59:13','0','','Dificultad para agregar persona en SISO (5)');
INSERT INTO `glpi_logs` VALUES ('1277','Ticket','5','Document','15','Lina Maria  Ospina Perez (14)','2017-11-16 14:59:13','0','','Documento de incidencia 5 (1)');
INSERT INTO `glpi_logs` VALUES ('1278','Ticket','5','User','15','Lina Maria  Ospina Perez (14)','2017-11-16 14:59:13','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1279','Ticket','5','User','15','Lina Maria  Ospina Perez (14)','2017-11-16 14:59:13','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1280','Ticket','5','0','20','Lina Maria  Ospina Perez (14)','2017-11-16 14:59:13','0','','');
INSERT INTO `glpi_logs` VALUES ('1281','Ticket','5','','0','Lina Maria  Ospina Perez (14)','2017-11-16 15:01:42','21','&lt;p&gt;He intentado agregar una persona al SISO, como contratista, pero no guarda. Adjunto pantallazo donde se ve el error que arroja el sistema. Gracias.&lt;/p&gt;','&lt;p&gt;He intentado agregar una persona al SISO, como contratista, pero no guarda. Adjunto pantallazo donde se ve el error que arroja el sistema. Gracias.&lt;/p&gt;n&lt;p&gt; &lt');
INSERT INTO `glpi_logs` VALUES ('1282','Ticket','5','','0','Juan David Correa (2)','2017-11-16 16:48:47','150','0','6574');
INSERT INTO `glpi_logs` VALUES ('1283','Ticket','5','','0','Juan David Correa (2)','2017-11-16 16:48:47','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1284','Ticket','5','TicketFollowup','17','Juan David Correa (2)','2017-11-16 16:48:47','0','','1');
INSERT INTO `glpi_logs` VALUES ('1285','Ticket','5','','0','Juan David Correa (2)','2017-11-16 16:51:52','18','','2017-11-16 18:00');
INSERT INTO `glpi_logs` VALUES ('1286','Ticket','5','','0','Juan David Correa (2)','2017-11-16 16:51:52','52','1','3');
INSERT INTO `glpi_logs` VALUES ('1287','Ticket','5','','0','Juan David Correa (2)','2017-11-16 16:53:00','155','','2017-11-23 19:00');
INSERT INTO `glpi_logs` VALUES ('1288','Document','2','0','20','Lina Maria  Ospina Perez (14)','2017-11-23 14:51:37','0','','');
INSERT INTO `glpi_logs` VALUES ('1289','Document','2','Ticket','15','Lina Maria  Ospina Perez (14)','2017-11-23 14:51:37','0','','Solicitud cambio de planilla de seguridad social (6)');
INSERT INTO `glpi_logs` VALUES ('1290','Ticket','6','Document','15','Lina Maria  Ospina Perez (14)','2017-11-23 14:51:37','0','','Documento de incidencia 6 (2)');
INSERT INTO `glpi_logs` VALUES ('1291','Ticket','6','User','15','Lina Maria  Ospina Perez (14)','2017-11-23 14:51:37','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1292','Ticket','6','User','15','Lina Maria  Ospina Perez (14)','2017-11-23 14:51:37','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1293','Ticket','6','0','20','Lina Maria  Ospina Perez (14)','2017-11-23 14:51:37','0','','');
INSERT INTO `glpi_logs` VALUES ('1294','Ticket','6','','0','Juan David Correa (2)','2017-11-24 14:41:41','24','','&lt;p&gt;Cordial saludo Lina, &lt;br /&gt;El documento se ha reemplazado en el sistema. &lt;br /&gt;Una feliz día.&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1295','Ticket','6','','0','Juan David Correa (2)','2017-11-24 14:41:41','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1296','Ticket','6','','0','Juan David Correa (2)','2017-11-24 14:41:41','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1297','Ticket','6','','0','Juan David Correa (2)','2017-11-24 14:41:41','16','','2017-11-24 14:41:41');
INSERT INTO `glpi_logs` VALUES ('1298','Ticket','6','','0','Juan David Correa (2)','2017-11-24 14:41:41','17','','2017-11-24 14:41:41');
INSERT INTO `glpi_logs` VALUES ('1299','Ticket','5','','0','Juan David Correa (2)','2017-11-24 14:42:59','24','','&lt;p&gt;Se ha reiniciado nuevamente el servicio, por favor realiza la verificación ene l sistema. &lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1300','Ticket','5','','0','Juan David Correa (2)','2017-11-24 14:42:59','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1301','Ticket','5','','0','Juan David Correa (2)','2017-11-24 14:42:59','16','','2017-11-24 14:42:59');
INSERT INTO `glpi_logs` VALUES ('1302','Ticket','5','','0','Juan David Correa (2)','2017-11-24 14:42:59','17','','2017-11-24 14:42:59');
INSERT INTO `glpi_logs` VALUES ('1303','Document','3','0','20','Lina Maria  Ospina Perez (14)','2017-11-28 11:01:36','0','','');
INSERT INTO `glpi_logs` VALUES ('1304','Document','3','Ticket','15','Lina Maria  Ospina Perez (14)','2017-11-28 11:01:36','0','','Solicitud cambio de planilla en SISREC (7)');
INSERT INTO `glpi_logs` VALUES ('1305','Ticket','7','Document','15','Lina Maria  Ospina Perez (14)','2017-11-28 11:01:36','0','','Documento de incidencia 7 (3)');
INSERT INTO `glpi_logs` VALUES ('1306','Ticket','7','User','15','Lina Maria  Ospina Perez (14)','2017-11-28 11:01:36','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1307','Ticket','7','User','15','Lina Maria  Ospina Perez (14)','2017-11-28 11:01:36','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1308','Ticket','7','0','20','Lina Maria  Ospina Perez (14)','2017-11-28 11:01:36','0','','');
INSERT INTO `glpi_logs` VALUES ('1309','Document','4','0','20','Lina Maria  Ospina Perez (14)','2017-11-28 11:12:04','0','','');
INSERT INTO `glpi_logs` VALUES ('1310','Document','4','Ticket','15','Lina Maria  Ospina Perez (14)','2017-11-28 11:12:04','0','','Solicitud agregar planilla de ajuste en SISREC (8)');
INSERT INTO `glpi_logs` VALUES ('1311','Ticket','8','Document','15','Lina Maria  Ospina Perez (14)','2017-11-28 11:12:04','0','','Documento de incidencia 8 (4)');
INSERT INTO `glpi_logs` VALUES ('1312','Ticket','8','User','15','Lina Maria  Ospina Perez (14)','2017-11-28 11:12:04','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1313','Ticket','8','User','15','Lina Maria  Ospina Perez (14)','2017-11-28 11:12:04','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1314','Ticket','8','0','20','Lina Maria  Ospina Perez (14)','2017-11-28 11:12:04','0','','');
INSERT INTO `glpi_logs` VALUES ('1315','Document','5','0','20','Lina Maria  Ospina Perez (14)','2017-11-29 14:29:59','0','','');
INSERT INTO `glpi_logs` VALUES ('1316','Document','5','Ticket','15','Lina Maria  Ospina Perez (14)','2017-11-29 14:29:59','0','','Planilla de ajuste para SISREC (9)');
INSERT INTO `glpi_logs` VALUES ('1317','Ticket','9','Document','15','Lina Maria  Ospina Perez (14)','2017-11-29 14:29:59','0','','Documento de incidencia 9 (5)');
INSERT INTO `glpi_logs` VALUES ('1318','Ticket','9','User','15','Lina Maria  Ospina Perez (14)','2017-11-29 14:29:59','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1319','Ticket','9','User','15','Lina Maria  Ospina Perez (14)','2017-11-29 14:29:59','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1320','Ticket','9','0','20','Lina Maria  Ospina Perez (14)','2017-11-29 14:29:59','0','','');
INSERT INTO `glpi_logs` VALUES ('1321','Ticket','10','User','15','Lina Maria  Ospina Perez (14)','2017-12-05 10:26:41','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1322','Ticket','10','User','15','Lina Maria  Ospina Perez (14)','2017-12-05 10:26:41','0','','Felipe Becerra (6)');
INSERT INTO `glpi_logs` VALUES ('1323','Ticket','10','0','20','Lina Maria  Ospina Perez (14)','2017-12-05 10:26:41','0','','');
INSERT INTO `glpi_logs` VALUES ('1324','Ticket','11','User','15','Lina Maria  Ospina Perez (14)','2017-12-05 13:50:44','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1325','Ticket','11','User','15','Lina Maria  Ospina Perez (14)','2017-12-05 13:50:44','0','','Felipe Becerra (6)');
INSERT INTO `glpi_logs` VALUES ('1326','Ticket','11','0','20','Lina Maria  Ospina Perez (14)','2017-12-05 13:50:44','0','','');
INSERT INTO `glpi_logs` VALUES ('1327','Document','6','0','20','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','');
INSERT INTO `glpi_logs` VALUES ('1328','Document','6','Ticket','15','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','Solicitud cambio de planilla de SS (12)');
INSERT INTO `glpi_logs` VALUES ('1329','Ticket','12','Document','15','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','Documento de incidencia 12 (6)');
INSERT INTO `glpi_logs` VALUES ('1330','Document','7','0','20','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','');
INSERT INTO `glpi_logs` VALUES ('1331','Document','7','Ticket','15','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','Solicitud cambio de planilla de SS (12)');
INSERT INTO `glpi_logs` VALUES ('1332','Ticket','12','Document','15','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','Documento de incidencia 12 (7)');
INSERT INTO `glpi_logs` VALUES ('1333','Document','8','0','20','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','');
INSERT INTO `glpi_logs` VALUES ('1334','Document','8','Ticket','15','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','Solicitud cambio de planilla de SS (12)');
INSERT INTO `glpi_logs` VALUES ('1335','Ticket','12','Document','15','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','Documento de incidencia 12 (8)');
INSERT INTO `glpi_logs` VALUES ('1336','Ticket','12','User','15','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','Lina Maria  Ospina Perez (14)');
INSERT INTO `glpi_logs` VALUES ('1337','Ticket','12','User','15','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','Juan David Correa (2)');
INSERT INTO `glpi_logs` VALUES ('1338','Ticket','12','0','20','Lina Maria  Ospina Perez (14)','2017-12-06 14:10:59','0','','');
INSERT INTO `glpi_logs` VALUES ('1339','Ticket','12','','0','Juan David Correa (2)','2017-12-06 14:24:29','24','','&lt;p&gt;Cordial saludo, &lt;/p&gt;rn&lt;p&gt;Los documentos de seguridad social han sido actualizados. &lt;/p&gt;rn&lt;p&gt;Asimismo, quiero informarte que con tu cuenta de usuari');
INSERT INTO `glpi_logs` VALUES ('1340','Ticket','12','','0','Juan David Correa (2)','2017-12-06 14:24:29','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1341','Ticket','12','','0','Juan David Correa (2)','2017-12-06 14:24:29','12','1','6');
INSERT INTO `glpi_logs` VALUES ('1342','Ticket','12','','0','Juan David Correa (2)','2017-12-06 14:24:29','16','','2017-12-06 14:24:29');
INSERT INTO `glpi_logs` VALUES ('1343','Ticket','12','','0','Juan David Correa (2)','2017-12-06 14:24:29','17','','2017-12-06 14:24:29');
INSERT INTO `glpi_logs` VALUES ('1344','Ticket','11','','0','Juan David Correa (2)','2017-12-06 14:30:21','150','0','88777');
INSERT INTO `glpi_logs` VALUES ('1345','Ticket','11','','0','Juan David Correa (2)','2017-12-06 14:30:21','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1346','Ticket','11','TicketTask','17','Juan David Correa (2)','2017-12-06 14:30:21','0','','1');
INSERT INTO `glpi_logs` VALUES ('1347','Ticket','11','','0','Juan David Correa (2)','2017-12-06 14:31:58','155','','2017-12-06 19:00');
INSERT INTO `glpi_logs` VALUES ('1348','Ticket','9','','0','Juan David Correa (2)','2017-12-06 14:33:18','12','1','5');
INSERT INTO `glpi_logs` VALUES ('1349','Ticket','9','','0','Juan David Correa (2)','2017-12-06 14:33:18','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1350','Ticket','9','','0','Juan David Correa (2)','2017-12-06 14:33:18','17','','2017-12-06 14:33:18');
INSERT INTO `glpi_logs` VALUES ('1351','Ticket','9','','0','Juan David Correa (2)','2017-12-06 14:34:38','24','','&lt;p&gt;Cordial saludo, &lt;/p&gt;rn&lt;p&gt;El archivo ha sido modificado. &lt;/p&gt;rn&lt;p&gt;Una feliz tarde&lt;/p&gt;');
INSERT INTO `glpi_logs` VALUES ('1352','Ticket','9','','0','Juan David Correa (2)','2017-12-06 14:34:38','12','5','6');
INSERT INTO `glpi_logs` VALUES ('1353','Ticket','9','','0','Juan David Correa (2)','2017-12-06 14:34:38','16','','2017-12-06 14:34:38');
INSERT INTO `glpi_logs` VALUES ('1354','Ticket','8','','0','Juan David Correa (2)','2017-12-06 14:35:34','21','&lt;p&gt;Buenos días,&lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt;Solicito agregar la planilla adjunta que es de novedad al reporte de noviembre de JOHANA PRADA ACEVEDO, cc 63493037.&lt;','&lt;p&gt;Buenos días,&lt;/p&gt;n&lt;p&gt; &lt;/p&gt;n&lt;p&gt;Solicito agregar la planilla adjunta que es de novedad al reporte de noviembre de JOHANA PRADA ACEVEDO, cc 63493037.&l');
INSERT INTO `glpi_logs` VALUES ('1355','Ticket','8','','0','Juan David Correa (2)','2017-12-06 14:35:34','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1356','Ticket','8','TicketTask','17','Juan David Correa (2)','2017-12-06 14:36:29','0','','2');
INSERT INTO `glpi_logs` VALUES ('1357','Ticket','7','','0','Juan David Correa (2)','2017-12-06 14:37:20','52','1','3');
INSERT INTO `glpi_logs` VALUES ('1358','Ticket','7','','0','Juan David Correa (2)','2017-12-06 14:37:20','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1359','Ticket','7','','0','Juan David Correa (2)','2017-12-06 14:37:42','52','3','4');
INSERT INTO `glpi_logs` VALUES ('1360','Ticket','7','TicketTask','17','Juan David Correa (2)','2017-12-06 14:40:17','0','','3');
INSERT INTO `glpi_logs` VALUES ('1361','Ticket','7','','0','Juan David Correa (2)','2017-12-06 14:40:28','21','&lt;p&gt;Buenos días,&lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt;Solicito el cambio de la planilla de la contratista SANDRA PATRICIA LARA VARGAS, cc 43479573 por el que anexo debido a q','&lt;p&gt;Buenos días,&lt;/p&gt;n&lt;p&gt; &lt;/p&gt;n&lt;p&gt;Solicito el cambio de la planilla de la contratista SANDRA PATRICIA LARA VARGAS, cc 43479573 por el que anexo debido a');
INSERT INTO `glpi_logs` VALUES ('1362','Document','3','Ticket','16','Juan David Correa (2)','2017-12-06 14:43:18','0','Solicitud cambio de planilla en SISREC (7)','');
INSERT INTO `glpi_logs` VALUES ('1363','Ticket','7','Document','16','Juan David Correa (2)','2017-12-06 14:43:18','0','Documento de incidencia 7 (3)','');
INSERT INTO `glpi_logs` VALUES ('1364','Ticket','7','','0','Juan David Correa (2)','2017-12-06 14:43:18','19','2017-12-06 14:40:28','2017-12-06 14:43:18');
INSERT INTO `glpi_logs` VALUES ('1365','Ticket','7','','0','Juan David Correa (2)','2017-12-06 14:43:18','21','&lt;p&gt;Buenos días,&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Solicito el cambio de la planilla de la contratista SANDRA PATRICIA LARA VARGAS, cc 43479573 por el que anexo debido a','<p>Buenos días,</p>n<p> </p>n<p>Solicito el cambio de la planilla de la contratista SANDRA PATRICIA LARA VARGAS, cc 43479573 por el que anexo debido a que la planilla que está en e');
INSERT INTO `glpi_logs` VALUES ('1366','Document','4','Ticket','16','Juan David Correa (2)','2017-12-06 14:43:18','0','Solicitud agregar planilla de ajuste en SISREC (8)','');
INSERT INTO `glpi_logs` VALUES ('1367','Ticket','8','Document','16','Juan David Correa (2)','2017-12-06 14:43:18','0','Documento de incidencia 8 (4)','');
INSERT INTO `glpi_logs` VALUES ('1368','Ticket','8','','0','Juan David Correa (2)','2017-12-06 14:43:18','19','2017-12-06 14:36:29','2017-12-06 14:43:18');
INSERT INTO `glpi_logs` VALUES ('1369','Ticket','8','','0','Juan David Correa (2)','2017-12-06 14:43:18','21','&lt;p&gt;Buenos días,&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Solicito agregar la planilla adjunta que es de novedad al reporte de noviembre de JOHANA PRADA ACEVEDO, cc 63493037.&l','<p>Buenos días,</p>n<p> </p>n<p>Solicito agregar la planilla adjunta que es de novedad al reporte de noviembre de JOHANA PRADA ACEVEDO, cc 63493037.</p>n<p> </p>n<p>NOTA: En este m');
INSERT INTO `glpi_logs` VALUES ('1370','Ticket','11','','0','Juan David Correa (2)','2017-12-06 14:44:06','52','1','3');
INSERT INTO `glpi_logs` VALUES ('1371','Ticket','1','0','13','Juan David Correa (2)','2017-12-06 14:48:35','0','','');
INSERT INTO `glpi_logs` VALUES ('1372','Ticket','3','0','13','Juan David Correa (2)','2017-12-06 14:48:35','0','','');
INSERT INTO `glpi_logs` VALUES ('1373','Ticket','11','','0','Juan David Correa (2)','2017-12-06 14:50:41','12','1','4');
INSERT INTO `glpi_logs` VALUES ('1374','Ticket','7','','0','Juan David Correa (2)','2017-12-06 14:51:12','12','1','4');
INSERT INTO `glpi_logs` VALUES ('1375','Ticket','7','','0','Juan David Correa (2)','2017-12-06 14:51:12','21','<p>Buenos días,</p>
<p> </p>
<p>Solicito el cambio de la planilla de la contratista SANDRA PATRICIA LARA VARGAS, cc 43479573 por el que anexo debido a que la planilla que está en e','&lt;p&gt;Buenos días,&lt;/p&gt;n&lt;p&gt; &lt;/p&gt;n&lt;p&gt;Solicito el cambio de la planilla de la contratista SANDRA PATRICIA LARA VARGAS, cc 43479573 por el que anexo debido a');
INSERT INTO `glpi_logs` VALUES ('1376','Ticket','8','','0','Juan David Correa (2)','2017-12-06 14:51:52','12','1','4');
INSERT INTO `glpi_logs` VALUES ('1377','Ticket','8','','0','Juan David Correa (2)','2017-12-06 14:51:52','21','<p>Buenos días,</p>
<p> </p>
<p>Solicito agregar la planilla adjunta que es de novedad al reporte de noviembre de JOHANA PRADA ACEVEDO, cc 63493037.</p>
<p> </p>
<p>NOTA: En este m','&lt;p&gt;Buenos días,&lt;/p&gt;n&lt;p&gt; &lt;/p&gt;n&lt;p&gt;Solicito agregar la planilla adjunta que es de novedad al reporte de noviembre de JOHANA PRADA ACEVEDO, cc 63493037.&l');
INSERT INTO `glpi_logs` VALUES ('1378','Ticket','10','','0','Juan David Correa (2)','2017-12-06 15:02:44','64','43695135 (14)','juan.correa (2)');
INSERT INTO `glpi_logs` VALUES ('1379','Ticket','13','User','15','prueba prueba (8)','2018-02-28 10:20:35','0','','prueba prueba (8)');
INSERT INTO `glpi_logs` VALUES ('1380','Ticket','13','User','15','prueba prueba (8)','2018-02-28 10:20:35','0','','Claudia Marleny Jaramillo (11)');
INSERT INTO `glpi_logs` VALUES ('1381','Ticket','13','0','20','prueba prueba (8)','2018-02-28 10:20:35','0','','');
INSERT INTO `glpi_logs` VALUES ('1382','User','3','','0','post-only (3)','2018-03-01 18:47:28','15','0','1');
INSERT INTO `glpi_logs` VALUES ('1383','TicketTemplate','4','0','20','Juan David Correa (2)','2018-03-22 22:51:33','0','','');
INSERT INTO `glpi_logs` VALUES ('1384','TicketTemplate','5','0','20','Juan David Correa (2)','2018-03-22 22:51:50','0','','');
INSERT INTO `glpi_logs` VALUES ('1385','TicketTemplate','6','0','20','Juan David Correa (2)','2018-03-22 22:52:04','0','','');
INSERT INTO `glpi_logs` VALUES ('1386','User','2','','0','Paola Cardona (2)','2018-04-02 15:32:23','34','Correa','Cardona');
INSERT INTO `glpi_logs` VALUES ('1387','User','2','','0','Paola Cardona (2)','2018-04-02 15:32:23','9','Juan David','Paola');

### Dump table glpi_mailcollectors

DROP TABLE IF EXISTS `glpi_mailcollectors`;
CREATE TABLE `glpi_mailcollectors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `host` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `login` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize_max` int(11) NOT NULL DEFAULT '2097152',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `passwd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accepted` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `refused` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `use_kerberos` tinyint(1) NOT NULL DEFAULT '0',
  `errors` int(11) NOT NULL DEFAULT '0',
  `use_mail_date` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_manufacturers

DROP TABLE IF EXISTS `glpi_manufacturers`;
CREATE TABLE `glpi_manufacturers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_manufacturers` VALUES ('1','HP','','2017-07-25 17:49:48','2017-07-25 17:49:48');
INSERT INTO `glpi_manufacturers` VALUES ('2','EPSON','','2017-07-25 17:49:53','2017-07-25 17:49:53');
INSERT INTO `glpi_manufacturers` VALUES ('3','Kyocera','','2017-07-25 17:50:21','2017-07-25 17:50:21');
INSERT INTO `glpi_manufacturers` VALUES ('4','Lenovo','','2017-07-26 10:09:07','2017-07-26 10:09:07');
INSERT INTO `glpi_manufacturers` VALUES ('5','Apple','','2017-07-26 10:09:16','2017-07-26 10:09:16');
INSERT INTO `glpi_manufacturers` VALUES ('6','Asus','','2017-07-26 10:09:21','2017-07-26 10:09:21');
INSERT INTO `glpi_manufacturers` VALUES ('7','Cisco','','2017-07-26 10:09:29','2017-07-26 10:09:29');
INSERT INTO `glpi_manufacturers` VALUES ('8','LG','','2017-07-26 10:09:36','2017-07-26 10:09:36');
INSERT INTO `glpi_manufacturers` VALUES ('9','Toshiba','','2017-07-26 10:09:53','2017-07-26 10:09:53');
INSERT INTO `glpi_manufacturers` VALUES ('10','Dell','','2017-07-26 10:10:08','2017-07-26 10:10:08');
INSERT INTO `glpi_manufacturers` VALUES ('11','Panasonic','','2017-07-26 10:10:37','2017-07-26 10:10:37');

### Dump table glpi_monitormodels

DROP TABLE IF EXISTS `glpi_monitormodels`;
CREATE TABLE `glpi_monitormodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitors

DROP TABLE IF EXISTS `glpi_monitors`;
CREATE TABLE `glpi_monitors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `size` int(11) NOT NULL DEFAULT '0',
  `have_micro` tinyint(1) NOT NULL DEFAULT '0',
  `have_speaker` tinyint(1) NOT NULL DEFAULT '0',
  `have_subd` tinyint(1) NOT NULL DEFAULT '0',
  `have_bnc` tinyint(1) NOT NULL DEFAULT '0',
  `have_dvi` tinyint(1) NOT NULL DEFAULT '0',
  `have_pivot` tinyint(1) NOT NULL DEFAULT '0',
  `have_hdmi` tinyint(1) NOT NULL DEFAULT '0',
  `have_displayport` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `monitortypes_id` int(11) NOT NULL DEFAULT '0',
  `monitormodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `monitormodels_id` (`monitormodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `monitortypes_id` (`monitortypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_monitortypes

DROP TABLE IF EXISTS `glpi_monitortypes`;
CREATE TABLE `glpi_monitortypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_netpoints

DROP TABLE IF EXISTS `glpi_netpoints`;
CREATE TABLE `glpi_netpoints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `complete` (`entities_id`,`locations_id`,`name`),
  KEY `location_name` (`locations_id`,`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkaliases

DROP TABLE IF EXISTS `glpi_networkaliases`;
CREATE TABLE `glpi_networkaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `networknames_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `name` (`name`),
  KEY `networknames_id` (`networknames_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmentfirmwares

DROP TABLE IF EXISTS `glpi_networkequipmentfirmwares`;
CREATE TABLE `glpi_networkequipmentfirmwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmentmodels

DROP TABLE IF EXISTS `glpi_networkequipmentmodels`;
CREATE TABLE `glpi_networkequipmentmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipments

DROP TABLE IF EXISTS `glpi_networkequipments`;
CREATE TABLE `glpi_networkequipments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ram` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmenttypes_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmentmodels_id` int(11) NOT NULL DEFAULT '0',
  `networkequipmentfirmwares_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `domains_id` (`domains_id`),
  KEY `networkequipmentfirmwares_id` (`networkequipmentfirmwares_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `networkequipmentmodels_id` (`networkequipmentmodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `networkequipmenttypes_id` (`networkequipmenttypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkequipmenttypes

DROP TABLE IF EXISTS `glpi_networkequipmenttypes`;
CREATE TABLE `glpi_networkequipmenttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_networkequipmenttypes` VALUES ('1','Router','','2017-07-26 10:22:23','2017-07-26 10:22:23');
INSERT INTO `glpi_networkequipmenttypes` VALUES ('2','Access Point','','2017-07-26 10:22:34','2017-07-26 10:22:34');
INSERT INTO `glpi_networkequipmenttypes` VALUES ('3','Switch router','','2017-07-26 10:22:59','2017-07-26 10:22:59');
INSERT INTO `glpi_networkequipmenttypes` VALUES ('4','Hub concentrador','','2017-07-26 10:23:10','2017-07-26 10:23:10');
INSERT INTO `glpi_networkequipmenttypes` VALUES ('5','Brigde','','2017-07-26 10:24:14','2017-07-26 10:23:20');
INSERT INTO `glpi_networkequipmenttypes` VALUES ('6','Router inalámbrico','','2017-07-26 10:24:00','2017-07-26 10:24:00');
INSERT INTO `glpi_networkequipmenttypes` VALUES ('7','NAS','','2017-07-26 10:39:37','2017-07-26 10:39:37');

### Dump table glpi_networkinterfaces

DROP TABLE IF EXISTS `glpi_networkinterfaces`;
CREATE TABLE `glpi_networkinterfaces` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networknames

DROP TABLE IF EXISTS `glpi_networknames`;
CREATE TABLE `glpi_networknames` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `fqdns_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `FQDN` (`name`,`fqdns_id`),
  KEY `name` (`name`),
  KEY `fqdns_id` (`fqdns_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `item` (`itemtype`,`items_id`,`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaggregates

DROP TABLE IF EXISTS `glpi_networkportaggregates`;
CREATE TABLE `glpi_networkportaggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_list` text COLLATE utf8_unicode_ci COMMENT 'array of associated networkports_id',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportaliases

DROP TABLE IF EXISTS `glpi_networkportaliases`;
CREATE TABLE `glpi_networkportaliases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `networkports_id_alias` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `networkports_id_alias` (`networkports_id_alias`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportdialups

DROP TABLE IF EXISTS `glpi_networkportdialups`;
CREATE TABLE `glpi_networkportdialups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportethernets

DROP TABLE IF EXISTS `glpi_networkportethernets`;
CREATE TABLE `glpi_networkportethernets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) COLLATE utf8_unicode_ci DEFAULT '' COMMENT 'T, LX, SX',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `type` (`type`),
  KEY `speed` (`speed`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportfiberchannels

DROP TABLE IF EXISTS `glpi_networkportfiberchannels`;
CREATE TABLE `glpi_networkportfiberchannels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `netpoints_id` int(11) NOT NULL DEFAULT '0',
  `wwn` varchar(16) COLLATE utf8_unicode_ci DEFAULT '',
  `speed` int(11) NOT NULL DEFAULT '10' COMMENT 'Mbit/s: 10, 100, 1000, 10000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `netpoint` (`netpoints_id`),
  KEY `wwn` (`wwn`),
  KEY `speed` (`speed`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportlocals

DROP TABLE IF EXISTS `glpi_networkportlocals`;
CREATE TABLE `glpi_networkportlocals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports

DROP TABLE IF EXISTS `glpi_networkports`;
CREATE TABLE `glpi_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `logical_number` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `instantiation_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mac` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `on_device` (`items_id`,`itemtype`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `mac` (`mac`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports_networkports

DROP TABLE IF EXISTS `glpi_networkports_networkports`;
CREATE TABLE `glpi_networkports_networkports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id_1` int(11) NOT NULL DEFAULT '0',
  `networkports_id_2` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id_1`,`networkports_id_2`),
  KEY `networkports_id_2` (`networkports_id_2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkports_vlans

DROP TABLE IF EXISTS `glpi_networkports_vlans`;
CREATE TABLE `glpi_networkports_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `vlans_id` int(11) NOT NULL DEFAULT '0',
  `tagged` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`networkports_id`,`vlans_id`),
  KEY `vlans_id` (`vlans_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networkportwifis

DROP TABLE IF EXISTS `glpi_networkportwifis`;
CREATE TABLE `glpi_networkportwifis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `networkports_id` int(11) NOT NULL DEFAULT '0',
  `items_devicenetworkcards_id` int(11) NOT NULL DEFAULT '0',
  `wifinetworks_id` int(11) NOT NULL DEFAULT '0',
  `networkportwifis_id` int(11) NOT NULL DEFAULT '0' COMMENT 'only useful in case of Managed node',
  `version` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'a, a/b, a/b/g, a/b/g/n, a/b/g/n/y',
  `mode` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, managed, master, repeater, secondary, monitor, auto',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `networkports_id` (`networkports_id`),
  KEY `card` (`items_devicenetworkcards_id`),
  KEY `essid` (`wifinetworks_id`),
  KEY `version` (`version`),
  KEY `mode` (`mode`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_networks

DROP TABLE IF EXISTS `glpi_networks`;
CREATE TABLE `glpi_networks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notepads

DROP TABLE IF EXISTS `glpi_notepads`;
CREATE TABLE `glpi_notepads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date` (`date`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_notifications

DROP TABLE IF EXISTS `glpi_notifications`;
CREATE TABLE `glpi_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `event` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `itemtype` (`itemtype`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notifications` VALUES ('1','Alert Tickets not closed','0','Ticket','alertnotclosed','mail','6','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('2','Nuevo Ticket','0','Ticket','new','mail','4','','0','1','2017-08-15 23:06:05',NULL);
INSERT INTO `glpi_notifications` VALUES ('3','Update Ticket','0','Ticket','update','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('4','Close Ticket','0','Ticket','closed','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('5','Add Followup','0','Ticket','add_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('6','Add Task','0','Ticket','add_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('7','Update Followup','0','Ticket','update_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('8','Update Task','0','Ticket','update_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('9','Delete Followup','0','Ticket','delete_followup','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('10','Delete Task','0','Ticket','delete_task','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('11','Resolve ticket','0','Ticket','solved','mail','4','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('12','Ticket Validation','0','Ticket','validation','mail','7','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('13','New Reservation','0','Reservation','new','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('14','Update Reservation','0','Reservation','update','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('15','Delete Reservation','0','Reservation','delete','mail','2','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('16','Alert Reservation','0','Reservation','alert','mail','3','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('17','Contract Notice','0','Contract','notice','mail','12','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('18','Contract End','0','Contract','end','mail','12','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('19','MySQL Synchronization','0','DBConnection','desynchronization','mail','1','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('20','Cartridges','0','CartridgeItem','alert','mail','8','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('21','Consumables','0','ConsumableItem','alert','mail','9','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('22','Infocoms','0','Infocom','alert','mail','10','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('23','Software Licenses','0','SoftwareLicense','alert','mail','11','','1','1','2010-02-16 16:41:39',NULL);
INSERT INTO `glpi_notifications` VALUES ('24','Ticket Recall','0','Ticket','recall','mail','4','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('25','Password Forget','0','User','passwordforget','mail','13','','1','1','2011-03-04 11:35:13',NULL);
INSERT INTO `glpi_notifications` VALUES ('26','Ticket Satisfaction','0','Ticket','satisfaction','mail','14','','1','1','2011-03-04 11:35:15',NULL);
INSERT INTO `glpi_notifications` VALUES ('27','Item not unique','0','FieldUnicity','refuse','mail','15','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('28','Crontask Watcher','0','Crontask','alert','mail','16','','1','1','2011-03-04 11:35:16',NULL);
INSERT INTO `glpi_notifications` VALUES ('29','New Problem','0','Problem','new','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('30','Update Problem','0','Problem','update','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('31','Resolve Problem','0','Problem','solved','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('32','Add Task','0','Problem','add_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('33','Update Task','0','Problem','update_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('34','Delete Task','0','Problem','delete_task','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('35','Close Problem','0','Problem','closed','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('36','Delete Problem','0','Problem','delete','mail','17','','1','1','2011-12-06 09:48:33',NULL);
INSERT INTO `glpi_notifications` VALUES ('37','Ticket Validation Answer','0','Ticket','validation_answer','mail','7','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('38','Contract End Periodicity','0','Contract','periodicity','mail','12','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('39','Contract Notice Periodicity','0','Contract','periodicitynotice','mail','12','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('40','Planning recall','0','PlanningRecall','planningrecall','mail','18','','1','1','2014-01-15 14:35:24',NULL);
INSERT INTO `glpi_notifications` VALUES ('41','Delete Ticket','0','Ticket','delete','mail','4','','1','1','2014-01-15 14:35:26',NULL);
INSERT INTO `glpi_notifications` VALUES ('42','New Change','0','Change','new','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('43','Update Change','0','Change','update','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('44','Resolve Change','0','Change','solved','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('45','Add Task','0','Change','add_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('46','Update Task','0','Change','update_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('47','Delete Task','0','Change','delete_task','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('48','Close Change','0','Change','closed','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('49','Delete Change','0','Change','delete','mail','19','','1','1','2014-06-18 08:02:07',NULL);
INSERT INTO `glpi_notifications` VALUES ('50','Ticket Satisfaction Answer','0','Ticket','replysatisfaction','mail','14','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('51','Receiver errors','0','MailCollector','error','mail','20','','1','1','2014-06-18 08:02:08',NULL);
INSERT INTO `glpi_notifications` VALUES ('52','New Project','0','Project','new','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('53','Update Project','0','Project','update','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('54','Delete Project','0','Project','delete','mail','21','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('55','New Project Task','0','ProjectTask','new','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('56','Update Project Task','0','ProjectTask','update','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('57','Delete Project Task','0','ProjectTask','delete','mail','22','','1','1','2014-06-18 08:02:09',NULL);
INSERT INTO `glpi_notifications` VALUES ('58','Request Unlock Items','0','ObjectLock','unlock','mail','23','','1','1','2016-02-08 16:57:46',NULL);

### Dump table glpi_notificationtargets

DROP TABLE IF EXISTS `glpi_notificationtargets`;
CREATE TABLE `glpi_notificationtargets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `notifications_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `items` (`type`,`items_id`),
  KEY `notifications_id` (`notifications_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtargets` VALUES ('1','3','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('2','1','1','13');
INSERT INTO `glpi_notificationtargets` VALUES ('4','1','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('5','1','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('6','1','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('7','1','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('8','2','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('9','4','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('10','3','1','2');
INSERT INTO `glpi_notificationtargets` VALUES ('11','3','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('12','3','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('13','3','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('14','1','1','19');
INSERT INTO `glpi_notificationtargets` VALUES ('15','14','1','12');
INSERT INTO `glpi_notificationtargets` VALUES ('16','3','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('17','1','1','14');
INSERT INTO `glpi_notificationtargets` VALUES ('18','3','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('19','1','1','15');
INSERT INTO `glpi_notificationtargets` VALUES ('20','1','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('21','3','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('22','1','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('23','3','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('24','1','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('25','3','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('26','1','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('27','3','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('28','1','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('29','3','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('30','1','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('31','3','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('32','19','1','25');
INSERT INTO `glpi_notificationtargets` VALUES ('33','3','1','26');
INSERT INTO `glpi_notificationtargets` VALUES ('35','21','1','3');
INSERT INTO `glpi_notificationtargets` VALUES ('36','21','1','5');
INSERT INTO `glpi_notificationtargets` VALUES ('37','21','1','4');
INSERT INTO `glpi_notificationtargets` VALUES ('38','21','1','6');
INSERT INTO `glpi_notificationtargets` VALUES ('39','21','1','7');
INSERT INTO `glpi_notificationtargets` VALUES ('40','21','1','8');
INSERT INTO `glpi_notificationtargets` VALUES ('41','21','1','9');
INSERT INTO `glpi_notificationtargets` VALUES ('42','21','1','10');
INSERT INTO `glpi_notificationtargets` VALUES ('43','21','1','11');
INSERT INTO `glpi_notificationtargets` VALUES ('75','1','1','41');
INSERT INTO `glpi_notificationtargets` VALUES ('46','1','1','28');
INSERT INTO `glpi_notificationtargets` VALUES ('47','3','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('48','1','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('49','21','1','29');
INSERT INTO `glpi_notificationtargets` VALUES ('50','2','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('51','4','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('52','3','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('53','1','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('54','21','1','30');
INSERT INTO `glpi_notificationtargets` VALUES ('55','3','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('56','1','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('57','21','1','31');
INSERT INTO `glpi_notificationtargets` VALUES ('58','3','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('59','1','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('60','21','1','32');
INSERT INTO `glpi_notificationtargets` VALUES ('61','3','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('62','1','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('63','21','1','33');
INSERT INTO `glpi_notificationtargets` VALUES ('64','3','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('65','1','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('66','21','1','34');
INSERT INTO `glpi_notificationtargets` VALUES ('67','3','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('68','1','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('69','21','1','35');
INSERT INTO `glpi_notificationtargets` VALUES ('70','3','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('71','1','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('72','21','1','36');
INSERT INTO `glpi_notificationtargets` VALUES ('73','14','1','37');
INSERT INTO `glpi_notificationtargets` VALUES ('74','3','1','40');
INSERT INTO `glpi_notificationtargets` VALUES ('76','3','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('77','1','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('78','21','1','42');
INSERT INTO `glpi_notificationtargets` VALUES ('79','2','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('80','4','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('81','3','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('82','1','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('83','21','1','43');
INSERT INTO `glpi_notificationtargets` VALUES ('84','3','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('85','1','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('86','21','1','44');
INSERT INTO `glpi_notificationtargets` VALUES ('87','3','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('88','1','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('89','21','1','45');
INSERT INTO `glpi_notificationtargets` VALUES ('90','3','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('91','1','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('92','21','1','46');
INSERT INTO `glpi_notificationtargets` VALUES ('93','3','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('94','1','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('95','21','1','47');
INSERT INTO `glpi_notificationtargets` VALUES ('96','3','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('97','1','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('98','21','1','48');
INSERT INTO `glpi_notificationtargets` VALUES ('99','3','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('100','1','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('101','21','1','49');
INSERT INTO `glpi_notificationtargets` VALUES ('102','3','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('103','2','1','50');
INSERT INTO `glpi_notificationtargets` VALUES ('104','1','1','51');
INSERT INTO `glpi_notificationtargets` VALUES ('105','27','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('106','1','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('107','28','1','52');
INSERT INTO `glpi_notificationtargets` VALUES ('108','27','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('109','1','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('110','28','1','53');
INSERT INTO `glpi_notificationtargets` VALUES ('111','27','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('112','1','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('113','28','1','54');
INSERT INTO `glpi_notificationtargets` VALUES ('114','31','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('115','1','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('116','32','1','55');
INSERT INTO `glpi_notificationtargets` VALUES ('117','31','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('118','1','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('119','32','1','56');
INSERT INTO `glpi_notificationtargets` VALUES ('120','31','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('121','1','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('122','32','1','57');
INSERT INTO `glpi_notificationtargets` VALUES ('123','19','1','58');

### Dump table glpi_notificationtemplates

DROP TABLE IF EXISTS `glpi_notificationtemplates`;
CREATE TABLE `glpi_notificationtemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `css` text COLLATE utf8_unicode_ci,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `itemtype` (`itemtype`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplates` VALUES ('1','MySQL Synchronization','DBConnection','2010-02-01 15:51:46','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('2','Reservations','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('3','Alert Reservation','Reservation','2010-02-03 14:03:45','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('4','Tickets','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('5','Tickets (Simple)','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('6','Alert Tickets not closed','Ticket','2010-02-07 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('7','Tickets Validation','Ticket','2010-02-26 21:39:15','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('8','Cartridges','CartridgeItem','2010-02-16 13:17:24','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('9','Consumables','ConsumableItem','2010-02-16 13:17:38','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('10','Infocoms','Infocom','2010-02-16 13:17:55','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('11','Licenses','SoftwareLicense','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('12','Contracts','Contract','2010-02-16 13:18:12','',NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('13','Password Forget','User','2011-03-04 11:35:13',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('14','Ticket Satisfaction','Ticket','2011-03-04 11:35:15',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('15','Item not unique','FieldUnicity','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('16','Crontask','Crontask','2011-03-04 11:35:16',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('17','Problems','Problem','2011-12-06 09:48:33',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('18','Planning recall','PlanningRecall','2014-01-15 14:35:24',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('19','Changes','Change','2014-06-18 08:02:07',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('20','Receiver errors','MailCollector','2014-06-18 08:02:08',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('21','Projects','Project','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('22','Project Tasks','ProjectTask','2014-06-18 08:02:09',NULL,NULL,NULL);
INSERT INTO `glpi_notificationtemplates` VALUES ('23','Unlock Item request','ObjectLock','2016-02-08 16:57:46',NULL,NULL,NULL);

### Dump table glpi_notificationtemplatetranslations

DROP TABLE IF EXISTS `glpi_notificationtemplatetranslations`;
CREATE TABLE `glpi_notificationtemplatetranslations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `language` char(5) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content_text` text COLLATE utf8_unicode_ci,
  `content_html` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `notificationtemplates_id` (`notificationtemplates_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('1','1','','##lang.dbconnection.title##','##lang.dbconnection.delay## : ##dbconnection.delay##
','&lt;p&gt;##lang.dbconnection.delay## : ##dbconnection.delay##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('2','2','','##reservation.action##','======================================================================
##lang.reservation.user##: ##reservation.user##
##lang.reservation.item.name##: ##reservation.itemtype## - ##reservation.item.name##
##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech## ##ENDIFreservation.tech##
##lang.reservation.begin##: ##reservation.begin##
##lang.reservation.end##: ##reservation.end##
##lang.reservation.comment##: ##reservation.comment##
======================================================================
','&lt;!-- description{ color: inherit; background: #ebebeb;border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; } --&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.user##:&lt;/span&gt;##reservation.user##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.item.name##:&lt;/span&gt;##reservation.itemtype## - ##reservation.item.name##&lt;br /&gt;##IFreservation.tech## ##lang.reservation.tech## ##reservation.tech####ENDIFreservation.tech##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.begin##:&lt;/span&gt; ##reservation.begin##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.end##:&lt;/span&gt;##reservation.end##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.reservation.comment##:&lt;/span&gt; ##reservation.comment##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('3','3','','##reservation.action##  ##reservation.entity##','##lang.reservation.entity## : ##reservation.entity##


##FOREACHreservations##
##lang.reservation.itemtype## : ##reservation.itemtype##

 ##lang.reservation.item## : ##reservation.item##

 ##reservation.url##

 ##ENDFOREACHreservations##','&lt;p&gt;##lang.reservation.entity## : ##reservation.entity## &lt;br /&gt; &lt;br /&gt;
##FOREACHreservations## &lt;br /&gt;##lang.reservation.itemtype## :  ##reservation.itemtype##&lt;br /&gt;
 ##lang.reservation.item## :  ##reservation.item##&lt;br /&gt; &lt;br /&gt;
 &lt;a href=\"##reservation.url##\"&gt; ##reservation.url##&lt;/a&gt;&lt;br /&gt;
 ##ENDFOREACHreservations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('4','4','','##ticket.action## ##ticket.title##',' ##IFticket.storestatus=5##
 ##lang.ticket.url## : ##ticket.urlapprove##
 ##lang.ticket.autoclosewarning##
 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description## ##ENDIFticket.storestatus##
 ##ELSEticket.storestatus## ##lang.ticket.url## : ##ticket.url## ##ENDELSEticket.storestatus##

 ##lang.ticket.description##

 ##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.authors## : ##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors## ##ELSEticket.authors##--##ENDELSEticket.authors##
 ##lang.ticket.creationdate## : ##ticket.creationdate##
 ##lang.ticket.closedate## : ##ticket.closedate##
 ##lang.ticket.requesttype## : ##ticket.requesttype##
##lang.ticket.item.name## :

##FOREACHitems##

 ##IFticket.itemtype##
  ##ticket.itemtype## - ##ticket.item.name##
  ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model##
  ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial##
  ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial##
 ##ENDIFticket.itemtype##

##ENDFOREACHitems##
##IFticket.assigntousers## ##lang.ticket.assigntousers## : ##ticket.assigntousers## ##ENDIFticket.assigntousers##
 ##lang.ticket.status## : ##ticket.status##
##IFticket.assigntogroups## ##lang.ticket.assigntogroups## : ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##
 ##lang.ticket.urgency## : ##ticket.urgency##
 ##lang.ticket.impact## : ##ticket.impact##
 ##lang.ticket.priority## : ##ticket.priority##
##IFticket.user.email## ##lang.ticket.user.email## : ##ticket.user.email ##ENDIFticket.user.email##
##IFticket.category## ##lang.ticket.category## : ##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
 ##lang.ticket.content## : ##ticket.content##
 ##IFticket.storestatus=6##

 ##lang.ticket.solvedate## : ##ticket.solvedate##
 ##lang.ticket.solution.type## : ##ticket.solution.type##
 ##lang.ticket.solution.description## : ##ticket.solution.description##
 ##ENDIFticket.storestatus##
 ##lang.ticket.numberoffollowups## : ##ticket.numberoffollowups##

##FOREACHfollowups##

 [##followup.date##] ##lang.followup.isprivate## : ##followup.isprivate##
 ##lang.followup.author## ##followup.author##
 ##lang.followup.description## ##followup.description##
 ##lang.followup.date## ##followup.date##
 ##lang.followup.requesttype## ##followup.requesttype##

##ENDFOREACHfollowups##
 ##lang.ticket.numberoftasks## : ##ticket.numberoftasks##

##FOREACHtasks##

 [##task.date##] ##lang.task.isprivate## : ##task.isprivate##
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##','<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div>##IFticket.storestatus=5##</div>
<div>##lang.ticket.url## : <a href=\"##ticket.urlapprove##\">##ticket.urlapprove##</a> <strong>&#160;</strong></div>
<div><strong>##lang.ticket.autoclosewarning##</strong></div>
<div><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.type##</strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description## ##ENDIFticket.storestatus##</div>
<div>##ELSEticket.storestatus## ##lang.ticket.url## : <a href=\"##ticket.url##\">##ticket.url##</a> ##ENDELSEticket.storestatus##</div>
<p class=\"description b\"><strong>##lang.ticket.description##</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.title##</span>&#160;:##ticket.title## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.authors##</span>&#160;:##IFticket.authors## ##ticket.authors## ##ENDIFticket.authors##    ##ELSEticket.authors##--##ENDELSEticket.authors## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.creationdate##</span>&#160;:##ticket.creationdate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.closedate##</span>&#160;:##ticket.closedate## <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.requesttype##</span>&#160;:##ticket.requesttype##<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.item.name##</span>&#160;:
<p>##FOREACHitems##</p>
<div class=\"description b\">##IFticket.itemtype## ##ticket.itemtype##&#160;- ##ticket.item.name## ##IFticket.item.model## ##lang.ticket.item.model## : ##ticket.item.model## ##ENDIFticket.item.model## ##IFticket.item.serial## ##lang.ticket.item.serial## : ##ticket.item.serial## ##ENDIFticket.item.serial## ##IFticket.item.otherserial## ##lang.ticket.item.otherserial## : ##ticket.item.otherserial## ##ENDIFticket.item.otherserial## ##ENDIFticket.itemtype## </div><br />
<p>##ENDFOREACHitems##</p>
##IFticket.assigntousers## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntousers##</span>&#160;: ##ticket.assigntousers## ##ENDIFticket.assigntousers##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.status## </span>&#160;: ##ticket.status##<br /> ##IFticket.assigntogroups## <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.assigntogroups##</span>&#160;: ##ticket.assigntogroups## ##ENDIFticket.assigntogroups##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.urgency##</span>&#160;: ##ticket.urgency##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.impact##</span>&#160;: ##ticket.impact##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.priority##</span>&#160;: ##ticket.priority## <br /> ##IFticket.user.email##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.user.email##</span>&#160;: ##ticket.user.email ##ENDIFticket.user.email##    <br /> ##IFticket.category##<span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">##lang.ticket.category## </span>&#160;:##ticket.category## ##ENDIFticket.category## ##ELSEticket.category## ##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##    <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.ticket.content##</span>&#160;: ##ticket.content##</p>
<br />##IFticket.storestatus=6##<br /><span style=\"text-decoration: underline;\"><strong><span style=\"color: #888888;\">##lang.ticket.solvedate##</span></strong></span> : ##ticket.solvedate##<br /><span style=\"color: #888888;\"><strong><span style=\"text-decoration: underline;\">##lang.ticket.solution.type##</span></strong></span> : ##ticket.solution.type##<br /><span style=\"text-decoration: underline; color: #888888;\"><strong>##lang.ticket.solution.description##</strong></span> : ##ticket.solution.description##<br />##ENDIFticket.storestatus##</p>
<div class=\"description b\">##lang.ticket.numberoffollowups##&#160;: ##ticket.numberoffollowups##</div>
<p>##FOREACHfollowups##</p>
<div class=\"description b\"><br /> <strong> [##followup.date##] <em>##lang.followup.isprivate## : ##followup.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.author## </span> ##followup.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.description## </span> ##followup.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.date## </span> ##followup.date##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.followup.requesttype## </span> ##followup.requesttype##</div>
<p>##ENDFOREACHfollowups##</p>
<div class=\"description b\">##lang.ticket.numberoftasks##&#160;: ##ticket.numberoftasks##</div>
<p>##FOREACHtasks##</p>
<div class=\"description b\"><br /> <strong> [##task.date##] <em>##lang.task.isprivate## : ##task.isprivate## </em></strong><br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.author##</span> ##task.author##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.description##</span> ##task.description##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.time##</span> ##task.time##<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> ##lang.task.category##</span> ##task.category##</div>
<p>##ENDFOREACHtasks##</p>');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('5','12','','##contract.action##  ##contract.entity##','##lang.contract.entity## : ##contract.entity##

##FOREACHcontracts##
##lang.contract.name## : ##contract.name##
##lang.contract.number## : ##contract.number##
##lang.contract.time## : ##contract.time##
##IFcontract.type####lang.contract.type## : ##contract.type####ENDIFcontract.type##
##contract.url##
##ENDFOREACHcontracts##','&lt;p&gt;##lang.contract.entity## : ##contract.entity##&lt;br /&gt;
&lt;br /&gt;##FOREACHcontracts##&lt;br /&gt;##lang.contract.name## :
##contract.name##&lt;br /&gt;
##lang.contract.number## : ##contract.number##&lt;br /&gt;
##lang.contract.time## : ##contract.time##&lt;br /&gt;
##IFcontract.type####lang.contract.type## : ##contract.type##
##ENDIFcontract.type##&lt;br /&gt;
&lt;a href=\"##contract.url##\"&gt;
##contract.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcontracts##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('6','5','','##ticket.action## ##ticket.title##','##lang.ticket.url## : ##ticket.url##

##lang.ticket.description##


##lang.ticket.title##  :##ticket.title##

##lang.ticket.authors##  :##IFticket.authors##
##ticket.authors## ##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##

##IFticket.category## ##lang.ticket.category##  :##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##

##lang.ticket.content##  : ##ticket.content##
##IFticket.itemtype##
##lang.ticket.item.name##  : ##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##','&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.url##\"&gt;
##ticket.url##&lt;/a&gt;&lt;/div&gt;
&lt;div class=\"description b\"&gt;
##lang.ticket.description##&lt;/div&gt;
&lt;p&gt;&lt;span
style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.title##&lt;/span&gt;&#160;:##ticket.title##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.authors##&lt;/span&gt;
##IFticket.authors## ##ticket.authors##
##ENDIFticket.authors##
##ELSEticket.authors##--##ENDELSEticket.authors##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;&#160
;&lt;/span&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;
##IFticket.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.category## &lt;/span&gt;&#160;:##ticket.category##
##ENDIFticket.category## ##ELSEticket.category##
##lang.ticket.nocategoryassigned## ##ENDELSEticket.category##
&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.content##&lt;/span&gt;&#160;:
##ticket.content##&lt;br /&gt;##IFticket.itemtype##
&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;
##lang.ticket.item.name##&lt;/span&gt;&#160;:
##ticket.itemtype## - ##ticket.item.name##
##ENDIFticket.itemtype##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('15','15','','##lang.unicity.action##','##lang.unicity.entity## : ##unicity.entity##

##lang.unicity.itemtype## : ##unicity.itemtype##

##lang.unicity.message## : ##unicity.message##

##lang.unicity.action_user## : ##unicity.action_user##

##lang.unicity.action_type## : ##unicity.action_type##

##lang.unicity.date## : ##unicity.date##','&lt;p&gt;##lang.unicity.entity## : ##unicity.entity##&lt;/p&gt;
&lt;p&gt;##lang.unicity.itemtype## : ##unicity.itemtype##&lt;/p&gt;
&lt;p&gt;##lang.unicity.message## : ##unicity.message##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_user## : ##unicity.action_user##&lt;/p&gt;
&lt;p&gt;##lang.unicity.action_type## : ##unicity.action_type##&lt;/p&gt;
&lt;p&gt;##lang.unicity.date## : ##unicity.date##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('7','7','','##ticket.action## ##ticket.title##','##FOREACHvalidations##

##IFvalidation.storestatus=2##
##validation.submission.title##
##lang.validation.commentsubmission## : ##validation.commentsubmission##
##ENDIFvalidation.storestatus##
##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##

##lang.ticket.url## : ##ticket.urlvalidation##

##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
##IFvalidation.commentvalidation##
##lang.validation.commentvalidation## : ##validation.commentvalidation##
##ENDIFvalidation.commentvalidation##
##ENDFOREACHvalidations##','&lt;div&gt;##FOREACHvalidations##&lt;/div&gt;
&lt;p&gt;##IFvalidation.storestatus=2##&lt;/p&gt;
&lt;div&gt;##validation.submission.title##&lt;/div&gt;
&lt;div&gt;##lang.validation.commentsubmission## : ##validation.commentsubmission##&lt;/div&gt;
&lt;div&gt;##ENDIFvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEvalidation.storestatus## ##validation.answer.title## ##ENDELSEvalidation.storestatus##&lt;/div&gt;
&lt;div&gt;&lt;/div&gt;
&lt;div&gt;
&lt;div&gt;##lang.ticket.url## : &lt;a href=\"##ticket.urlvalidation##\"&gt; ##ticket.urlvalidation## &lt;/a&gt;&lt;/div&gt;
&lt;/div&gt;
&lt;p&gt;##IFvalidation.status## ##lang.validation.status## : ##validation.status## ##ENDIFvalidation.status##
&lt;br /&gt; ##IFvalidation.commentvalidation##&lt;br /&gt; ##lang.validation.commentvalidation## :
&#160; ##validation.commentvalidation##&lt;br /&gt; ##ENDIFvalidation.commentvalidation##
&lt;br /&gt;##ENDFOREACHvalidations##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('8','6','','##ticket.action## ##ticket.entity##','##lang.ticket.entity## : ##ticket.entity##

##FOREACHtickets##

##lang.ticket.title## : ##ticket.title##
 ##lang.ticket.status## : ##ticket.status##

 ##ticket.url##
 ##ENDFOREACHtickets##','&lt;table class=\"tab_cadre\" border=\"1\" cellspacing=\"2\" cellpadding=\"3\"&gt;
&lt;tbody&gt;
&lt;tr&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.title##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.attribution##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td style=\"text-align: left;\" width=\"auto\" bgcolor=\"#cccccc\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##lang.ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##FOREACHtickets##
&lt;tr&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.authors##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;&lt;a href=\"##ticket.url##\"&gt;##ticket.title##&lt;/a&gt;&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.priority##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.status##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##IFticket.assigntousers####ticket.assigntousers##&lt;br /&gt;##ENDIFticket.assigntousers####IFticket.assigntogroups##&lt;br /&gt;##ticket.assigntogroups## ##ENDIFticket.assigntogroups####IFticket.assigntosupplier##&lt;br /&gt;##ticket.assigntosupplier## ##ENDIFticket.assigntosupplier##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.creationdate##&lt;/span&gt;&lt;/td&gt;
&lt;td width=\"auto\"&gt;&lt;span style=\"font-size: 11px; text-align: left;\"&gt;##ticket.content##&lt;/span&gt;&lt;/td&gt;
&lt;/tr&gt;
##ENDFOREACHtickets##
&lt;/tbody&gt;
&lt;/table&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('9','9','','##consumable.action##  ##consumable.entity##','##lang.consumable.entity## : ##consumable.entity##


##FOREACHconsumables##
##lang.consumable.item## : ##consumable.item##


##lang.consumable.reference## : ##consumable.reference##

##lang.consumable.remaining## : ##consumable.remaining##

##consumable.url##

##ENDFOREACHconsumables##','&lt;p&gt;
##lang.consumable.entity## : ##consumable.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHconsumables##
&lt;br /&gt;##lang.consumable.item## : ##consumable.item##&lt;br /&gt;
&lt;br /&gt;##lang.consumable.reference## : ##consumable.reference##&lt;br /&gt;
##lang.consumable.remaining## : ##consumable.remaining##&lt;br /&gt;
&lt;a href=\"##consumable.url##\"&gt; ##consumable.url##&lt;/a&gt;&lt;br /&gt;
   ##ENDFOREACHconsumables##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('10','8','','##cartridge.action##  ##cartridge.entity##','##lang.cartridge.entity## : ##cartridge.entity##


##FOREACHcartridges##
##lang.cartridge.item## : ##cartridge.item##


##lang.cartridge.reference## : ##cartridge.reference##

##lang.cartridge.remaining## : ##cartridge.remaining##

##cartridge.url##
 ##ENDFOREACHcartridges##','&lt;p&gt;##lang.cartridge.entity## : ##cartridge.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHcartridges##
&lt;br /&gt;##lang.cartridge.item## :
##cartridge.item##&lt;br /&gt; &lt;br /&gt;
##lang.cartridge.reference## :
##cartridge.reference##&lt;br /&gt;
##lang.cartridge.remaining## :
##cartridge.remaining##&lt;br /&gt;
&lt;a href=\"##cartridge.url##\"&gt;
##cartridge.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHcartridges##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('11','10','','##infocom.action##  ##infocom.entity##','##lang.infocom.entity## : ##infocom.entity##


##FOREACHinfocoms##

##lang.infocom.itemtype## : ##infocom.itemtype##

##lang.infocom.item## : ##infocom.item##


##lang.infocom.expirationdate## : ##infocom.expirationdate##

##infocom.url##
 ##ENDFOREACHinfocoms##','&lt;p&gt;##lang.infocom.entity## : ##infocom.entity##
&lt;br /&gt; &lt;br /&gt;##FOREACHinfocoms##
&lt;br /&gt;##lang.infocom.itemtype## : ##infocom.itemtype##&lt;br /&gt;
##lang.infocom.item## : ##infocom.item##&lt;br /&gt; &lt;br /&gt;
##lang.infocom.expirationdate## : ##infocom.expirationdate##
&lt;br /&gt; &lt;a href=\"##infocom.url##\"&gt;
##infocom.url##&lt;/a&gt;&lt;br /&gt;
##ENDFOREACHinfocoms##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('12','11','','##license.action##  ##license.entity##','##lang.license.entity## : ##license.entity##

##FOREACHlicenses##

##lang.license.item## : ##license.item##

##lang.license.serial## : ##license.serial##

##lang.license.expirationdate## : ##license.expirationdate##

##license.url##
 ##ENDFOREACHlicenses##','&lt;p&gt;
##lang.license.entity## : ##license.entity##&lt;br /&gt;
##FOREACHlicenses##
&lt;br /&gt;##lang.license.item## : ##license.item##&lt;br /&gt;
##lang.license.serial## : ##license.serial##&lt;br /&gt;
##lang.license.expirationdate## : ##license.expirationdate##
&lt;br /&gt; &lt;a href=\"##license.url##\"&gt; ##license.url##
&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHlicenses##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('13','13','','##user.action##','##user.realname## ##user.firstname##

##lang.passwordforget.information##

##lang.passwordforget.link## ##user.passwordforgeturl##','&lt;p&gt;&lt;strong&gt;##user.realname## ##user.firstname##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.information##&lt;/p&gt;
&lt;p&gt;##lang.passwordforget.link## &lt;a title=\"##user.passwordforgeturl##\" href=\"##user.passwordforgeturl##\"&gt;##user.passwordforgeturl##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('14','14','','##ticket.action## ##ticket.title##','##lang.ticket.title## : ##ticket.title##

##lang.ticket.closedate## : ##ticket.closedate##

##lang.satisfaction.text## ##ticket.urlsatisfaction##','&lt;p&gt;##lang.ticket.title## : ##ticket.title##&lt;/p&gt;
&lt;p&gt;##lang.ticket.closedate## : ##ticket.closedate##&lt;/p&gt;
&lt;p&gt;##lang.satisfaction.text## &lt;a href=\"##ticket.urlsatisfaction##\"&gt;##ticket.urlsatisfaction##&lt;/a&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('16','16','','##crontask.action##','##lang.crontask.warning##

##FOREACHcrontasks##
 ##crontask.name## : ##crontask.description##

##ENDFOREACHcrontasks##','&lt;p&gt;##lang.crontask.warning##&lt;/p&gt;
&lt;p&gt;##FOREACHcrontasks## &lt;br /&gt;&lt;a href=\"##crontask.url##\"&gt;##crontask.name##&lt;/a&gt; : ##crontask.description##&lt;br /&gt; &lt;br /&gt;##ENDFOREACHcrontasks##&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('17','17','','##problem.action## ##problem.title##','##IFproblem.storestatus=5##
 ##lang.problem.url## : ##problem.urlapprove##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description## ##ENDIFproblem.storestatus##
 ##ELSEproblem.storestatus## ##lang.problem.url## : ##problem.url## ##ENDELSEproblem.storestatus##

 ##lang.problem.description##

 ##lang.problem.title##  :##problem.title##
 ##lang.problem.authors##  :##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors## ##ELSEproblem.authors##--##ENDELSEproblem.authors##
 ##lang.problem.creationdate##  :##problem.creationdate##
 ##IFproblem.assigntousers## ##lang.problem.assigntousers##  : ##problem.assigntousers## ##ENDIFproblem.assigntousers##
 ##lang.problem.status##  : ##problem.status##
 ##IFproblem.assigntogroups## ##lang.problem.assigntogroups##  : ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##
 ##lang.problem.urgency##  : ##problem.urgency##
 ##lang.problem.impact##  : ##problem.impact##
 ##lang.problem.priority## : ##problem.priority##
##IFproblem.category## ##lang.problem.category##  :##problem.category## ##ENDIFproblem.category## ##ELSEproblem.category## ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##
 ##lang.problem.content##  : ##problem.content##

##IFproblem.storestatus=6##
 ##lang.problem.solvedate## : ##problem.solvedate##
 ##lang.problem.solution.type## : ##problem.solution.type##
 ##lang.problem.solution.description## : ##problem.solution.description##
##ENDIFproblem.storestatus##
 ##lang.problem.numberoftickets## : ##problem.numberoftickets##

##FOREACHtickets##
 [##ticket.date##] ##lang.problem.title## : ##ticket.title##
 ##lang.problem.content## ##ticket.content##

##ENDFOREACHtickets##
 ##lang.problem.numberoftasks## : ##problem.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFproblem.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.problem.url## : &lt;a href=\"##problem.urlapprove##\"&gt;##problem.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description## ##ENDIFproblem.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEproblem.storestatus## ##lang.problem.url## : &lt;a href=\"##problem.url##\"&gt;##problem.url##&lt;/a&gt; ##ENDELSEproblem.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.problem.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.title##&lt;/span&gt;&#160;:##problem.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.authors##&lt;/span&gt;&#160;:##IFproblem.authors## ##problem.authors## ##ENDIFproblem.authors##    ##ELSEproblem.authors##--##ENDELSEproblem.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.creationdate##&lt;/span&gt;&#160;:##problem.creationdate## &lt;br /&gt; ##IFproblem.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntousers##&lt;/span&gt;&#160;: ##problem.assigntousers## ##ENDIFproblem.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.status## &lt;/span&gt;&#160;: ##problem.status##&lt;br /&gt; ##IFproblem.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.assigntogroups##&lt;/span&gt;&#160;: ##problem.assigntogroups## ##ENDIFproblem.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.urgency##&lt;/span&gt;&#160;: ##problem.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.impact##&lt;/span&gt;&#160;: ##problem.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.priority##&lt;/span&gt; : ##problem.priority## &lt;br /&gt;##IFproblem.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.category## &lt;/span&gt;&#160;:##problem.category##  ##ENDIFproblem.category## ##ELSEproblem.category##  ##lang.problem.nocategoryassigned## ##ENDELSEproblem.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.problem.content##&lt;/span&gt;&#160;: ##problem.content##&lt;/p&gt;
&lt;p&gt;##IFproblem.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.problem.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.problem.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.problem.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##problem.solution.description##&lt;br /&gt;##ENDIFproblem.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftickets##&#160;: ##problem.numberoftickets##&lt;/div&gt;
&lt;p&gt;##FOREACHtickets##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##ticket.date##] &lt;em&gt;##lang.problem.title## : &lt;a href=\"##ticket.url##\"&gt;##ticket.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.problem.content## &lt;/span&gt; ##ticket.content##
&lt;p&gt;##ENDFOREACHtickets##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.problem.numberoftasks##&#160;: ##problem.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('18','18','','##recall.action##: ##recall.item.name##','##recall.action##: ##recall.item.name##

##recall.item.content##

##lang.recall.planning.begin##: ##recall.planning.begin##
##lang.recall.planning.end##: ##recall.planning.end##
##lang.recall.planning.state##: ##recall.planning.state##
##lang.recall.item.private##: ##recall.item.private##','&lt;p&gt;##recall.action##: &lt;a href=\"##recall.item.url##\"&gt;##recall.item.name##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;##recall.item.content##&lt;/p&gt;
&lt;p&gt;##lang.recall.planning.begin##: ##recall.planning.begin##&lt;br /&gt;##lang.recall.planning.end##: ##recall.planning.end##&lt;br /&gt;##lang.recall.planning.state##: ##recall.planning.state##&lt;br /&gt;##lang.recall.item.private##: ##recall.item.private##&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p&gt;&lt;br /&gt;&lt;br /&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('19','19','','##change.action## ##change.title##','##IFchange.storestatus=5##
 ##lang.change.url## : ##change.urlapprove##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description## ##ENDIFchange.storestatus##
 ##ELSEchange.storestatus## ##lang.change.url## : ##change.url## ##ENDELSEchange.storestatus##

 ##lang.change.description##

 ##lang.change.title##  :##change.title##
 ##lang.change.authors##  :##IFchange.authors## ##change.authors## ##ENDIFchange.authors## ##ELSEchange.authors##--##ENDELSEchange.authors##
 ##lang.change.creationdate##  :##change.creationdate##
 ##IFchange.assigntousers## ##lang.change.assigntousers##  : ##change.assigntousers## ##ENDIFchange.assigntousers##
 ##lang.change.status##  : ##change.status##
 ##IFchange.assigntogroups## ##lang.change.assigntogroups##  : ##change.assigntogroups## ##ENDIFchange.assigntogroups##
 ##lang.change.urgency##  : ##change.urgency##
 ##lang.change.impact##  : ##change.impact##
 ##lang.change.priority## : ##change.priority##
##IFchange.category## ##lang.change.category##  :##change.category## ##ENDIFchange.category## ##ELSEchange.category## ##lang.change.nocategoryassigned## ##ENDELSEchange.category##
 ##lang.change.content##  : ##change.content##

##IFchange.storestatus=6##
 ##lang.change.solvedate## : ##change.solvedate##
 ##lang.change.solution.type## : ##change.solution.type##
 ##lang.change.solution.description## : ##change.solution.description##
##ENDIFchange.storestatus##
 ##lang.change.numberofproblems## : ##change.numberofproblems##

##FOREACHproblems##
 [##problem.date##] ##lang.change.title## : ##problem.title##
 ##lang.change.content## ##problem.content##

##ENDFOREACHproblems##
 ##lang.change.numberoftasks## : ##change.numberoftasks##

##FOREACHtasks##
 [##task.date##]
 ##lang.task.author## ##task.author##
 ##lang.task.description## ##task.description##
 ##lang.task.time## ##task.time##
 ##lang.task.category## ##task.category##

##ENDFOREACHtasks##
','&lt;p&gt;##IFchange.storestatus=5##&lt;/p&gt;
&lt;div&gt;##lang.change.url## : &lt;a href=\"##change.urlapprove##\"&gt;##change.urlapprove##&lt;/a&gt;&lt;/div&gt;
&lt;div&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.type##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description## ##ENDIFchange.storestatus##&lt;/div&gt;
&lt;div&gt;##ELSEchange.storestatus## ##lang.change.url## : &lt;a href=\"##change.url##\"&gt;##change.url##&lt;/a&gt; ##ENDELSEchange.storestatus##&lt;/div&gt;
&lt;p class=\"description b\"&gt;&lt;strong&gt;##lang.change.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.title##&lt;/span&gt;&#160;:##change.title## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.authors##&lt;/span&gt;&#160;:##IFchange.authors## ##change.authors## ##ENDIFchange.authors##    ##ELSEchange.authors##--##ENDELSEchange.authors## &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.creationdate##&lt;/span&gt;&#160;:##change.creationdate## &lt;br /&gt; ##IFchange.assigntousers## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntousers##&lt;/span&gt;&#160;: ##change.assigntousers## ##ENDIFchange.assigntousers##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.status## &lt;/span&gt;&#160;: ##change.status##&lt;br /&gt; ##IFchange.assigntogroups## &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.assigntogroups##&lt;/span&gt;&#160;: ##change.assigntogroups## ##ENDIFchange.assigntogroups##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.urgency##&lt;/span&gt;&#160;: ##change.urgency##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.impact##&lt;/span&gt;&#160;: ##change.impact##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.priority##&lt;/span&gt; : ##change.priority## &lt;br /&gt;##IFchange.category##&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.category## &lt;/span&gt;&#160;:##change.category##  ##ENDIFchange.category## ##ELSEchange.category##  ##lang.change.nocategoryassigned## ##ENDELSEchange.category##    &lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.change.content##&lt;/span&gt;&#160;: ##change.content##&lt;/p&gt;
&lt;p&gt;##IFchange.storestatus=6##&lt;br /&gt;&lt;span style=\"text-decoration: underline;\"&gt;&lt;strong&gt;&lt;span style=\"color: #888888;\"&gt;##lang.change.solvedate##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solvedate##&lt;br /&gt;&lt;span style=\"color: #888888;\"&gt;&lt;strong&gt;&lt;span style=\"text-decoration: underline;\"&gt;##lang.change.solution.type##&lt;/span&gt;&lt;/strong&gt;&lt;/span&gt; : ##change.solution.type##&lt;br /&gt;&lt;span style=\"text-decoration: underline; color: #888888;\"&gt;&lt;strong&gt;##lang.change.solution.description##&lt;/strong&gt;&lt;/span&gt; : ##change.solution.description##&lt;br /&gt;##ENDIFchange.storestatus##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberofproblems##&#160;: ##change.numberofproblems##&lt;/div&gt;
&lt;p&gt;##FOREACHproblems##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt; [##problem.date##] &lt;em&gt;##lang.change.title## : &lt;a href=\"##problem.url##\"&gt;##problem.title## &lt;/a&gt;&lt;/em&gt;&lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; &lt;/span&gt;&lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt;##lang.change.content## &lt;/span&gt; ##problem.content##
&lt;p&gt;##ENDFOREACHproblems##&lt;/p&gt;
&lt;div class=\"description b\"&gt;##lang.change.numberoftasks##&#160;: ##change.numberoftasks##&lt;/div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div class=\"description b\"&gt;&lt;strong&gt;[##task.date##] &lt;/strong&gt;&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.author##&lt;/span&gt; ##task.author##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.description##&lt;/span&gt; ##task.description##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.time##&lt;/span&gt; ##task.time##&lt;br /&gt; &lt;span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"&gt; ##lang.task.category##&lt;/span&gt; ##task.category##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('20','20','','##mailcollector.action##','##FOREACHmailcollectors##
##lang.mailcollector.name## : ##mailcollector.name##
##lang.mailcollector.errors## : ##mailcollector.errors##
##mailcollector.url##
##ENDFOREACHmailcollectors##','&lt;p&gt;##FOREACHmailcollectors##&lt;br /&gt;##lang.mailcollector.name## : ##mailcollector.name##&lt;br /&gt; ##lang.mailcollector.errors## : ##mailcollector.errors##&lt;br /&gt;&lt;a href=\"##mailcollector.url##\"&gt;##mailcollector.url##&lt;/a&gt;&lt;br /&gt; ##ENDFOREACHmailcollectors##&lt;/p&gt;
&lt;p&gt;&lt;/p&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('21','21','','##project.action## ##project.name## ##project.code##','##lang.project.url## : ##project.url##

##lang.project.description##

##lang.project.name## : ##project.name##
##lang.project.code## : ##project.code##
##lang.project.manager## : ##project.manager##
##lang.project.managergroup## : ##project.managergroup##
##lang.project.creationdate## : ##project.creationdate##
##lang.project.priority## : ##project.priority##
##lang.project.state## : ##project.state##
##lang.project.type## : ##project.type##
##lang.project.description## : ##project.description##

##lang.project.numberoftasks## : ##project.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.project.url## : &lt;a href=\"##project.url##\"&gt;##project.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.project.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.project.name## : ##project.name##&lt;br /&gt;##lang.project.code## : ##project.code##&lt;br /&gt; ##lang.project.manager## : ##project.manager##&lt;br /&gt;##lang.project.managergroup## : ##project.managergroup##&lt;br /&gt; ##lang.project.creationdate## : ##project.creationdate##&lt;br /&gt;##lang.project.priority## : ##project.priority## &lt;br /&gt;##lang.project.state## : ##project.state##&lt;br /&gt;##lang.project.type## : ##project.type##&lt;br /&gt;##lang.project.description## : ##project.description##&lt;/p&gt;
&lt;p&gt;##lang.project.numberoftasks## : ##project.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt; ##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('22','22','','##projecttask.action## ##projecttask.name##','##lang.projecttask.url## : ##projecttask.url##

##lang.projecttask.description##

##lang.projecttask.name## : ##projecttask.name##
##lang.projecttask.project## : ##projecttask.project##
##lang.projecttask.creationdate## : ##projecttask.creationdate##
##lang.projecttask.state## : ##projecttask.state##
##lang.projecttask.type## : ##projecttask.type##
##lang.projecttask.description## : ##projecttask.description##

##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##



##FOREACHtasks##

[##task.creationdate##]
##lang.task.name## : ##task.name##
##lang.task.state## : ##task.state##
##lang.task.type## : ##task.type##
##lang.task.percent## : ##task.percent##
##lang.task.description## : ##task.description##

##ENDFOREACHtasks##','&lt;p&gt;##lang.projecttask.url## : &lt;a href=\"##projecttask.url##\"&gt;##projecttask.url##&lt;/a&gt;&lt;/p&gt;
&lt;p&gt;&lt;strong&gt;##lang.projecttask.description##&lt;/strong&gt;&lt;/p&gt;
&lt;p&gt;##lang.projecttask.name## : ##projecttask.name##&lt;br /&gt;##lang.projecttask.project## : &lt;a href=\"##projecttask.projecturl##\"&gt;##projecttask.project##&lt;/a&gt;&lt;br /&gt;##lang.projecttask.creationdate## : ##projecttask.creationdate##&lt;br /&gt;##lang.projecttask.state## : ##projecttask.state##&lt;br /&gt;##lang.projecttask.type## : ##projecttask.type##&lt;br /&gt;##lang.projecttask.description## : ##projecttask.description##&lt;/p&gt;
&lt;p&gt;##lang.projecttask.numberoftasks## : ##projecttask.numberoftasks##&lt;/p&gt;
&lt;div&gt;
&lt;p&gt;##FOREACHtasks##&lt;/p&gt;
&lt;div&gt;&lt;strong&gt;[##task.creationdate##] &lt;/strong&gt;&lt;br /&gt;##lang.task.name## : ##task.name##&lt;br /&gt;##lang.task.state## : ##task.state##&lt;br /&gt;##lang.task.type## : ##task.type##&lt;br /&gt;##lang.task.percent## : ##task.percent##&lt;br /&gt;##lang.task.description## : ##task.description##&lt;/div&gt;
&lt;p&gt;##ENDFOREACHtasks##&lt;/p&gt;
&lt;/div&gt;');
INSERT INTO `glpi_notificationtemplatetranslations` VALUES ('23','23','','##objectlock.action##','##objectlock.type## ###objectlock.id## - ##objectlock.name##

      ##lang.objectlock.url##
      ##objectlock.url##

      ##lang.objectlock.date_mod##
      ##objectlock.date_mod##

      Hello ##objectlock.lockedby.firstname##,
      Could go to this item and unlock it for me?
      Thank you,
      Regards,
      ##objectlock.requester.firstname##','&lt;table&gt;
      &lt;tbody&gt;
      &lt;tr&gt;&lt;th colspan=\"2\"&gt;&lt;a href=\"##objectlock.url##\"&gt;##objectlock.type## ###objectlock.id## - ##objectlock.name##&lt;/a&gt;&lt;/th&gt;&lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.url##&lt;/td&gt;
      &lt;td&gt;##objectlock.url##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;tr&gt;
      &lt;td&gt;##lang.objectlock.date_mod##&lt;/td&gt;
      &lt;td&gt;##objectlock.date_mod##&lt;/td&gt;
      &lt;/tr&gt;
      &lt;/tbody&gt;
      &lt;/table&gt;
      &lt;p&gt;&lt;span style=\"font-size: small;\"&gt;Hello ##objectlock.lockedby.firstname##,&lt;br /&gt;Could go to this item and unlock it for me?&lt;br /&gt;Thank you,&lt;br /&gt;Regards,&lt;br /&gt;##objectlock.requester.firstname## ##objectlock.requester.lastname##&lt;/span&gt;&lt;/p&gt;');

### Dump table glpi_notimportedemails

DROP TABLE IF EXISTS `glpi_notimportedemails`;
CREATE TABLE `glpi_notimportedemails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `mailcollectors_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `subject` text,
  `messageid` varchar(255) NOT NULL,
  `reason` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `mailcollectors_id` (`mailcollectors_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


### Dump table glpi_objectlocks

DROP TABLE IF EXISTS `glpi_objectlocks`;
CREATE TABLE `glpi_objectlocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Type of locked object',
  `items_id` int(11) NOT NULL COMMENT 'RELATION to various tables, according to itemtype (ID)',
  `users_id` int(11) NOT NULL COMMENT 'id of the locker',
  `date_mod` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Timestamp of the lock',
  PRIMARY KEY (`id`),
  UNIQUE KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemarchitectures

DROP TABLE IF EXISTS `glpi_operatingsystemarchitectures`;
CREATE TABLE `glpi_operatingsystemarchitectures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_operatingsystemarchitectures` VALUES ('1','x86','Arquitectura de 32 Bits','2017-08-10 11:28:35','2017-08-10 11:28:35');
INSERT INTO `glpi_operatingsystemarchitectures` VALUES ('2','x64','Arquitectura de 64 btis','2017-08-10 11:28:46','2017-08-10 11:28:46');

### Dump table glpi_operatingsystems

DROP TABLE IF EXISTS `glpi_operatingsystems`;
CREATE TABLE `glpi_operatingsystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_operatingsystems` VALUES ('1','Windows 7','','2017-07-25 18:17:38','2017-07-25 18:17:38');
INSERT INTO `glpi_operatingsystems` VALUES ('2','Windows 8','','2017-07-25 18:17:45','2017-07-25 18:17:45');
INSERT INTO `glpi_operatingsystems` VALUES ('3','Windows 8.1','','2017-07-25 18:17:54','2017-07-25 18:17:54');
INSERT INTO `glpi_operatingsystems` VALUES ('4','Windows 10','','2017-07-25 18:18:05','2017-07-25 18:18:05');
INSERT INTO `glpi_operatingsystems` VALUES ('5','Windows Server 2008 R2','','2017-07-25 18:19:25','2017-07-25 18:19:25');
INSERT INTO `glpi_operatingsystems` VALUES ('6','IOS','','2017-07-26 10:40:43','2017-07-26 10:40:43');

### Dump table glpi_operatingsystemservicepacks

DROP TABLE IF EXISTS `glpi_operatingsystemservicepacks`;
CREATE TABLE `glpi_operatingsystemservicepacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_operatingsystemversions

DROP TABLE IF EXISTS `glpi_operatingsystemversions`;
CREATE TABLE `glpi_operatingsystemversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheralmodels

DROP TABLE IF EXISTS `glpi_peripheralmodels`;
CREATE TABLE `glpi_peripheralmodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripherals

DROP TABLE IF EXISTS `glpi_peripherals`;
CREATE TABLE `glpi_peripherals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `peripheraltypes_id` int(11) NOT NULL DEFAULT '0',
  `peripheralmodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `peripheralmodels_id` (`peripheralmodels_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `peripheraltypes_id` (`peripheraltypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_peripheraltypes

DROP TABLE IF EXISTS `glpi_peripheraltypes`;
CREATE TABLE `glpi_peripheraltypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_peripheraltypes` VALUES ('1','Camara de video','','2017-07-26 10:18:56','2017-07-26 10:17:55');
INSERT INTO `glpi_peripheraltypes` VALUES ('2','Tripode','','2017-07-26 10:19:25','2017-07-26 10:19:25');
INSERT INTO `glpi_peripheraltypes` VALUES ('3','Micrófonos de ambiente','','2017-07-26 10:19:59','2017-07-26 10:19:59');
INSERT INTO `glpi_peripheraltypes` VALUES ('4','Escaner','','2017-07-26 10:26:24','2017-07-26 10:26:24');

### Dump table glpi_phonemodels

DROP TABLE IF EXISTS `glpi_phonemodels`;
CREATE TABLE `glpi_phonemodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_phonemodels` VALUES ('1','Alcatel 4018 ipTouch','Telefono VOIP','2017-08-10 11:25:19','2017-08-10 11:25:19');

### Dump table glpi_phonepowersupplies

DROP TABLE IF EXISTS `glpi_phonepowersupplies`;
CREATE TABLE `glpi_phonepowersupplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phones

DROP TABLE IF EXISTS `glpi_phones`;
CREATE TABLE `glpi_phones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firmware` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `phonetypes_id` int(11) NOT NULL DEFAULT '0',
  `phonemodels_id` int(11) NOT NULL DEFAULT '0',
  `brand` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonepowersupplies_id` int(11) NOT NULL DEFAULT '0',
  `number_line` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_headset` tinyint(1) NOT NULL DEFAULT '0',
  `have_hp` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `phonemodels_id` (`phonemodels_id`),
  KEY `phonepowersupplies_id` (`phonepowersupplies_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `phonetypes_id` (`phonetypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_phonetypes

DROP TABLE IF EXISTS `glpi_phonetypes`;
CREATE TABLE `glpi_phonetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_planningrecalls

DROP TABLE IF EXISTS `glpi_planningrecalls`;
CREATE TABLE `glpi_planningrecalls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `before_time` int(11) NOT NULL DEFAULT '-10',
  `when` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`itemtype`,`items_id`,`users_id`),
  KEY `users_id` (`users_id`),
  KEY `before_time` (`before_time`),
  KEY `when` (`when`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_plugins

DROP TABLE IF EXISTS `glpi_plugins`;
CREATE TABLE `glpi_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `directory` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `state` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PLUGIN_* constant',
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `homepage` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `license` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`directory`),
  KEY `state` (`state`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_plugins` VALUES ('1','fields','Additionnal fields','1.7.0','2','Teclib\', Olivier Moron','teclib.com','GPLv2+');

### Dump table glpi_printermodels

DROP TABLE IF EXISTS `glpi_printermodels`;
CREATE TABLE `glpi_printermodels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_printermodels` VALUES ('1','Kyosera ECOSYS M2030dn','','2017-07-25 17:55:51','2017-07-25 17:55:51');
INSERT INTO `glpi_printermodels` VALUES ('2','Kyosera ECOSYS M2035dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('3','Kyosera ECOSYS M2040dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('4','Kyosera ECOSYS M2135dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('5','Kyosera ECOSYS M2530dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('6','Kyosera ECOSYS M2535dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('7','Kyosera ECOSYS M2540dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('8','Kyosera ECOSYS M2635dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('9','Kyosera ECOSYS M2640idw',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('10','Kyosera ECOSYS M2735dw',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('11','Kyosera ECOSYS M3040dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('12','Kyosera ECOSYS M3040idn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('13','Kyosera ECOSYS M3540dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('14','Kyosera ECOSYS M3540idn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('15','Kyosera ECOSYS M3550idn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('16','Kyosera ECOSYS M3560idn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('17','Kyosera ECOSYS M5521cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('18','Kyosera ECOSYS M5521cdw',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('19','Kyosera ECOSYS M5526cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('20','Kyosera ECOSYS M5526cdw',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('21','Kyosera ECOSYS M6026cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('22','Kyosera ECOSYS M6030cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('23','Kyosera ECOSYS M6035cidn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('24','Kyosera ECOSYS M6526cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('25','Kyosera ECOSYS M6530cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('26','Kyosera ECOSYS M6535cidn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('27','Kyosera ECOSYS P2035d',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('28','Kyosera ECOSYS P2040dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('29','Kyosera ECOSYS P2040dw',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('30','Kyosera ECOSYS P2135d',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('31','Kyosera ECOSYS P2135dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('32','Kyosera ECOSYS P2235dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('33','Kyosera ECOSYS P2235dw',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('34','Kyosera ECOSYS P3045dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('35','Kyosera ECOSYS P3050dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('36','Kyosera ECOSYS P3055dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('37','Kyosera ECOSYS P3060dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('38','Kyosera ECOSYS P4040dn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('39','Kyosera ECOSYS P5021cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('40','Kyosera ECOSYS P5021cdw',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('41','Kyosera ECOSYS P5026cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('42','Kyosera ECOSYS P5026cdw',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('43','Kyosera ECOSYS P6021cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('44','Kyosera ECOSYS P6035cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('45','Kyosera ECOSYS P6130cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('46','Kyosera ECOSYS P7040cdn',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('47','Kyosera FS-1041',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('48','Kyosera FS-1061DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('49','Kyosera FS-1220MFP',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('50','Kyosera FS-1320MFP',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('51','Kyosera FS-1325MFP',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('52','Kyosera FS-2100D',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('53','Kyosera FS-2100DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('54','Kyosera FS-4100DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('55','Kyosera FS-4200DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('56','Kyosera FS-4300DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('57','Kyosera FS-9130DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('58','Kyosera FS-9530DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('59','Kyosera FS-C8600DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('60','Kyosera FS-C8650DN',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('61','Kyosera TASKalfa 306ci',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('62','Kyosera TASKalfa 350ci',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('63','Kyosera TASKalfa 356ci',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('64','Kyosera TASKalfa 406ci',NULL,NULL,NULL);
INSERT INTO `glpi_printermodels` VALUES ('66','HP OfficeJet Pro 8620','Impresora multifuncional','2017-08-10 11:06:49','2017-08-10 11:06:49');
INSERT INTO `glpi_printermodels` VALUES ('67','HP OfficeJet 7612','Impresora No multifuncional','2017-08-10 11:07:10','2017-08-10 11:07:10');
INSERT INTO `glpi_printermodels` VALUES ('68','HP Color LaserJet MFP M277dw','Impresora Multifuncional','2017-08-10 11:07:30','2017-08-10 11:07:30');

### Dump table glpi_printers

DROP TABLE IF EXISTS `glpi_printers`;
CREATE TABLE `glpi_printers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `have_serial` tinyint(1) NOT NULL DEFAULT '0',
  `have_parallel` tinyint(1) NOT NULL DEFAULT '0',
  `have_usb` tinyint(1) NOT NULL DEFAULT '0',
  `have_wifi` tinyint(1) NOT NULL DEFAULT '0',
  `have_ethernet` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `memory_size` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `domains_id` int(11) NOT NULL DEFAULT '0',
  `networks_id` int(11) NOT NULL DEFAULT '0',
  `printertypes_id` int(11) NOT NULL DEFAULT '0',
  `printermodels_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_global` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `init_pages_counter` int(11) NOT NULL DEFAULT '0',
  `last_pages_counter` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_global` (`is_global`),
  KEY `domains_id` (`domains_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `printermodels_id` (`printermodels_id`),
  KEY `networks_id` (`networks_id`),
  KEY `states_id` (`states_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `printertypes_id` (`printertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `last_pages_counter` (`last_pages_counter`),
  KEY `is_dynamic` (`is_dynamic`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_printertypes

DROP TABLE IF EXISTS `glpi_printertypes`;
CREATE TABLE `glpi_printertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_printertypes` VALUES ('1','Impresora Laser B/N','','2017-07-25 17:45:17','2017-07-25 17:45:17');
INSERT INTO `glpi_printertypes` VALUES ('2','Impresora Laser Color','','2017-07-25 17:45:32','2017-07-25 17:45:32');
INSERT INTO `glpi_printertypes` VALUES ('3','Impresora Multifuncional Laser','','2017-07-26 10:24:51','2017-07-25 17:45:42');
INSERT INTO `glpi_printertypes` VALUES ('4','Impresora de inyección de tinta','','2017-07-25 17:46:28','2017-07-25 17:46:28');
INSERT INTO `glpi_printertypes` VALUES ('5','Impresora Multifuncional inyección de tinta','','2017-07-26 10:25:06','2017-07-26 10:25:06');

### Dump table glpi_problemcosts

DROP TABLE IF EXISTS `glpi_problemcosts`;
CREATE TABLE `glpi_problemcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `problems_id` (`problems_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems

DROP TABLE IF EXISTS `glpi_problems`;
CREATE TABLE `glpi_problems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `content` longtext COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `impactcontent` longtext COLLATE utf8_unicode_ci,
  `causecontent` longtext COLLATE utf8_unicode_ci,
  `symptomcontent` longtext COLLATE utf8_unicode_ci,
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin_waiting_date` datetime DEFAULT NULL,
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `date_mod` (`date_mod`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `due_date` (`due_date`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_suppliers

DROP TABLE IF EXISTS `glpi_problems_suppliers`;
CREATE TABLE `glpi_problems_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_tickets

DROP TABLE IF EXISTS `glpi_problems_tickets`;
CREATE TABLE `glpi_problems_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`tickets_id`),
  KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problems_users

DROP TABLE IF EXISTS `glpi_problems_users`;
CREATE TABLE `glpi_problems_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`problems_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_problemtasks

DROP TABLE IF EXISTS `glpi_problemtasks`;
CREATE TABLE `glpi_problemtasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `problems_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `problems_id` (`problems_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `state` (`state`),
  KEY `taskcategories_id` (`taskcategories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profilerights

DROP TABLE IF EXISTS `glpi_profilerights`;
CREATE TABLE `glpi_profilerights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rights` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`profiles_id`,`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profilerights` VALUES ('697','4','knowbasecategory','23');
INSERT INTO `glpi_profilerights` VALUES ('683','4','location','0');
INSERT INTO `glpi_profilerights` VALUES ('690','4','itilcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('669','4','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('732','4','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('746','4','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('1025','11','rule_softwarecategories','23');
INSERT INTO `glpi_profilerights` VALUES ('1026','11','rule_ticket','1047');
INSERT INTO `glpi_profilerights` VALUES ('1027','11','search_config','3072');
INSERT INTO `glpi_profilerights` VALUES ('1028','11','show_group_hardware','1');
INSERT INTO `glpi_profilerights` VALUES ('1029','11','sla','23');
INSERT INTO `glpi_profilerights` VALUES ('1030','11','software','127');
INSERT INTO `glpi_profilerights` VALUES ('1031','11','solutiontemplate','23');
INSERT INTO `glpi_profilerights` VALUES ('1032','11','state','23');
INSERT INTO `glpi_profilerights` VALUES ('725','4','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('283','4','computer','255');
INSERT INTO `glpi_profilerights` VALUES ('284','4','monitor','255');
INSERT INTO `glpi_profilerights` VALUES ('285','4','software','255');
INSERT INTO `glpi_profilerights` VALUES ('286','4','networking','255');
INSERT INTO `glpi_profilerights` VALUES ('287','4','internet','159');
INSERT INTO `glpi_profilerights` VALUES ('288','4','printer','255');
INSERT INTO `glpi_profilerights` VALUES ('289','4','peripheral','255');
INSERT INTO `glpi_profilerights` VALUES ('290','4','cartridge','255');
INSERT INTO `glpi_profilerights` VALUES ('291','4','consumable','255');
INSERT INTO `glpi_profilerights` VALUES ('292','4','phone','255');
INSERT INTO `glpi_profilerights` VALUES ('294','4','contact_enterprise','255');
INSERT INTO `glpi_profilerights` VALUES ('295','4','document','255');
INSERT INTO `glpi_profilerights` VALUES ('296','4','contract','255');
INSERT INTO `glpi_profilerights` VALUES ('297','4','infocom','31');
INSERT INTO `glpi_profilerights` VALUES ('298','4','knowbase','7327');
INSERT INTO `glpi_profilerights` VALUES ('302','4','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('303','4','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('304','4','dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('306','4','device','0');
INSERT INTO `glpi_profilerights` VALUES ('307','4','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('308','4','link','23');
INSERT INTO `glpi_profilerights` VALUES ('309','4','config','3');
INSERT INTO `glpi_profilerights` VALUES ('311','4','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('312','4','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('313','4','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('314','4','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('315','4','search_config','3072');
INSERT INTO `glpi_profilerights` VALUES ('676','4','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('318','4','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('319','4','user','0');
INSERT INTO `glpi_profilerights` VALUES ('321','4','group','0');
INSERT INTO `glpi_profilerights` VALUES ('322','4','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('323','4','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('324','4','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('325','4','reminder_public','159');
INSERT INTO `glpi_profilerights` VALUES ('326','4','rssfeed_public','159');
INSERT INTO `glpi_profilerights` VALUES ('327','4','bookmark_public','31');
INSERT INTO `glpi_profilerights` VALUES ('328','4','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('329','4','ticket','259103');
INSERT INTO `glpi_profilerights` VALUES ('333','4','followup','15383');
INSERT INTO `glpi_profilerights` VALUES ('334','4','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('346','4','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('349','4','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('350','4','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('352','4','show_group_hardware','1');
INSERT INTO `glpi_profilerights` VALUES ('353','4','rule_dictionnary_software','23');
INSERT INTO `glpi_profilerights` VALUES ('354','4','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('355','4','budget','255');
INSERT INTO `glpi_profilerights` VALUES ('357','4','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('358','4','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('361','4','calendar','23');
INSERT INTO `glpi_profilerights` VALUES ('362','4','sla','0');
INSERT INTO `glpi_profilerights` VALUES ('363','4','rule_dictionnary_printer','23');
INSERT INTO `glpi_profilerights` VALUES ('367','4','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('371','4','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('372','4','ticketrecurrent','23');
INSERT INTO `glpi_profilerights` VALUES ('373','4','ticketcost','23');
INSERT INTO `glpi_profilerights` VALUES ('376','4','ticketvalidation','15376');
INSERT INTO `glpi_profilerights` VALUES ('739','4','project','1279');
INSERT INTO `glpi_profilerights` VALUES ('711','4','taskcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('704','4','netpoint','23');
INSERT INTO `glpi_profilerights` VALUES ('718','4','state','23');
INSERT INTO `glpi_profilerights` VALUES ('662','4','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('1020','11','rule_dictionnary_printer','23');
INSERT INTO `glpi_profilerights` VALUES ('1017','11','reservation','1055');
INSERT INTO `glpi_profilerights` VALUES ('1018','11','rssfeed_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1019','11','rule_dictionnary_dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('1024','11','rule_mailcollector','23');
INSERT INTO `glpi_profilerights` VALUES ('1033','11','statistic','1');
INSERT INTO `glpi_profilerights` VALUES ('1034','11','task','13329');
INSERT INTO `glpi_profilerights` VALUES ('1035','11','taskcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('1036','11','ticket','261151');
INSERT INTO `glpi_profilerights` VALUES ('1037','11','ticketcost','23');
INSERT INTO `glpi_profilerights` VALUES ('1038','11','ticketrecurrent','23');
INSERT INTO `glpi_profilerights` VALUES ('1039','11','tickettemplate','23');
INSERT INTO `glpi_profilerights` VALUES ('1040','11','ticketvalidation','15376');
INSERT INTO `glpi_profilerights` VALUES ('1041','11','transfer','23');
INSERT INTO `glpi_profilerights` VALUES ('1042','11','typedoc','23');
INSERT INTO `glpi_profilerights` VALUES ('1043','11','user','7199');
INSERT INTO `glpi_profilerights` VALUES ('1022','11','rule_import','23');
INSERT INTO `glpi_profilerights` VALUES ('1023','11','rule_ldap','23');
INSERT INTO `glpi_profilerights` VALUES ('1021','11','rule_dictionnary_software','23');
INSERT INTO `glpi_profilerights` VALUES ('1016','11','reports','1');
INSERT INTO `glpi_profilerights` VALUES ('1015','11','reminder_public','23');
INSERT INTO `glpi_profilerights` VALUES ('1014','11','queuedmail','31');
INSERT INTO `glpi_profilerights` VALUES ('1013','11','projecttask','1025');
INSERT INTO `glpi_profilerights` VALUES ('1012','11','project','1151');
INSERT INTO `glpi_profilerights` VALUES ('1011','11','profile','23');
INSERT INTO `glpi_profilerights` VALUES ('1010','11','problem','1151');
INSERT INTO `glpi_profilerights` VALUES ('1009','11','printer','127');
INSERT INTO `glpi_profilerights` VALUES ('1008','11','planning','3073');
INSERT INTO `glpi_profilerights` VALUES ('1007','11','phone','127');
INSERT INTO `glpi_profilerights` VALUES ('1006','11','peripheral','127');
INSERT INTO `glpi_profilerights` VALUES ('1005','11','password_update','0');
INSERT INTO `glpi_profilerights` VALUES ('1004','11','notification','23');
INSERT INTO `glpi_profilerights` VALUES ('1003','11','networking','127');
INSERT INTO `glpi_profilerights` VALUES ('1002','11','netpoint','23');
INSERT INTO `glpi_profilerights` VALUES ('1001','11','monitor','127');
INSERT INTO `glpi_profilerights` VALUES ('1000','11','logs','1');
INSERT INTO `glpi_profilerights` VALUES ('999','11','location','23');
INSERT INTO `glpi_profilerights` VALUES ('998','11','link','23');
INSERT INTO `glpi_profilerights` VALUES ('997','11','license','127');
INSERT INTO `glpi_profilerights` VALUES ('995','11','knowbase','7191');
INSERT INTO `glpi_profilerights` VALUES ('994','11','itilcategory','23');
INSERT INTO `glpi_profilerights` VALUES ('993','11','internet','31');
INSERT INTO `glpi_profilerights` VALUES ('992','11','infocom','23');
INSERT INTO `glpi_profilerights` VALUES ('991','11','group','119');
INSERT INTO `glpi_profilerights` VALUES ('990','11','followup','15383');
INSERT INTO `glpi_profilerights` VALUES ('989','11','entity','3191');
INSERT INTO `glpi_profilerights` VALUES ('988','11','dropdown','23');
INSERT INTO `glpi_profilerights` VALUES ('987','11','domain','23');
INSERT INTO `glpi_profilerights` VALUES ('986','11','document','127');
INSERT INTO `glpi_profilerights` VALUES ('985','11','device','22');
INSERT INTO `glpi_profilerights` VALUES ('984','11','contract','127');
INSERT INTO `glpi_profilerights` VALUES ('983','11','contact_enterprise','127');
INSERT INTO `glpi_profilerights` VALUES ('982','11','consumable','127');
INSERT INTO `glpi_profilerights` VALUES ('981','11','config','3');
INSERT INTO `glpi_profilerights` VALUES ('980','11','computer','127');
INSERT INTO `glpi_profilerights` VALUES ('979','11','changevalidation','1044');
INSERT INTO `glpi_profilerights` VALUES ('978','11','change','1151');
INSERT INTO `glpi_profilerights` VALUES ('977','11','cartridge','127');
INSERT INTO `glpi_profilerights` VALUES ('976','11','calendar','23');
INSERT INTO `glpi_profilerights` VALUES ('975','11','budget','127');
INSERT INTO `glpi_profilerights` VALUES ('974','11','bookmark_public','23');
INSERT INTO `glpi_profilerights` VALUES ('973','11','backup','1045');
INSERT INTO `glpi_profilerights` VALUES ('972','10','user','0');
INSERT INTO `glpi_profilerights` VALUES ('971','10','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('970','10','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('969','10','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('968','10','tickettemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('967','10','ticketrecurrent','0');
INSERT INTO `glpi_profilerights` VALUES ('966','10','ticketcost','0');
INSERT INTO `glpi_profilerights` VALUES ('965','10','ticket','5');
INSERT INTO `glpi_profilerights` VALUES ('964','10','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('963','10','task','0');
INSERT INTO `glpi_profilerights` VALUES ('962','10','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('961','10','state','0');
INSERT INTO `glpi_profilerights` VALUES ('960','10','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('959','10','software','0');
INSERT INTO `glpi_profilerights` VALUES ('958','10','sla','0');
INSERT INTO `glpi_profilerights` VALUES ('957','10','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('824','4','license','255');
INSERT INTO `glpi_profilerights` VALUES ('996','11','knowbasecategory','23');
INSERT INTO `glpi_profilerights` VALUES ('956','10','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('955','10','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('954','10','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('953','10','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('952','10','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('951','10','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('950','10','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('949','10','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('948','10','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('947','10','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('946','10','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('945','10','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('944','10','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('943','10','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('942','10','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('941','10','project','0');
INSERT INTO `glpi_profilerights` VALUES ('940','10','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('939','10','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('938','10','printer','0');
INSERT INTO `glpi_profilerights` VALUES ('937','10','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('936','10','phone','0');
INSERT INTO `glpi_profilerights` VALUES ('935','10','peripheral','0');
INSERT INTO `glpi_profilerights` VALUES ('934','10','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('933','10','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('932','10','networking','0');
INSERT INTO `glpi_profilerights` VALUES ('931','10','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('930','10','monitor','0');
INSERT INTO `glpi_profilerights` VALUES ('929','10','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('928','10','location','0');
INSERT INTO `glpi_profilerights` VALUES ('927','10','link','0');
INSERT INTO `glpi_profilerights` VALUES ('926','10','license','0');
INSERT INTO `glpi_profilerights` VALUES ('925','10','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('924','10','knowbase','0');
INSERT INTO `glpi_profilerights` VALUES ('923','10','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('922','10','internet','0');
INSERT INTO `glpi_profilerights` VALUES ('921','10','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('920','10','group','0');
INSERT INTO `glpi_profilerights` VALUES ('919','10','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('918','10','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('917','10','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('916','10','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('915','10','document','0');
INSERT INTO `glpi_profilerights` VALUES ('914','10','device','0');
INSERT INTO `glpi_profilerights` VALUES ('913','10','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('912','10','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('911','10','consumable','0');
INSERT INTO `glpi_profilerights` VALUES ('910','10','config','0');
INSERT INTO `glpi_profilerights` VALUES ('909','10','computer','0');
INSERT INTO `glpi_profilerights` VALUES ('908','10','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('907','10','change','0');
INSERT INTO `glpi_profilerights` VALUES ('902','10','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('903','10','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('904','10','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('905','10','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('906','10','cartridge','0');
INSERT INTO `glpi_profilerights` VALUES ('1166','13','rule_mailcollector','0');
INSERT INTO `glpi_profilerights` VALUES ('1165','13','rule_ldap','0');
INSERT INTO `glpi_profilerights` VALUES ('1164','13','rule_import','0');
INSERT INTO `glpi_profilerights` VALUES ('1163','13','rule_dictionnary_software','0');
INSERT INTO `glpi_profilerights` VALUES ('1162','13','rule_dictionnary_printer','0');
INSERT INTO `glpi_profilerights` VALUES ('1161','13','rule_dictionnary_dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('1160','13','rssfeed_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1159','13','reservation','0');
INSERT INTO `glpi_profilerights` VALUES ('1158','13','reports','0');
INSERT INTO `glpi_profilerights` VALUES ('1157','13','reminder_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1156','13','queuedmail','0');
INSERT INTO `glpi_profilerights` VALUES ('1155','13','projecttask','0');
INSERT INTO `glpi_profilerights` VALUES ('1154','13','project','0');
INSERT INTO `glpi_profilerights` VALUES ('1153','13','profile','0');
INSERT INTO `glpi_profilerights` VALUES ('1152','13','problem','0');
INSERT INTO `glpi_profilerights` VALUES ('1151','13','printer','119');
INSERT INTO `glpi_profilerights` VALUES ('1150','13','planning','0');
INSERT INTO `glpi_profilerights` VALUES ('1149','13','phone','119');
INSERT INTO `glpi_profilerights` VALUES ('1148','13','peripheral','119');
INSERT INTO `glpi_profilerights` VALUES ('1147','13','password_update','1');
INSERT INTO `glpi_profilerights` VALUES ('1146','13','notification','0');
INSERT INTO `glpi_profilerights` VALUES ('1145','13','networking','119');
INSERT INTO `glpi_profilerights` VALUES ('1144','13','netpoint','0');
INSERT INTO `glpi_profilerights` VALUES ('1143','13','monitor','119');
INSERT INTO `glpi_profilerights` VALUES ('1142','13','logs','0');
INSERT INTO `glpi_profilerights` VALUES ('1141','13','location','0');
INSERT INTO `glpi_profilerights` VALUES ('1140','13','link','0');
INSERT INTO `glpi_profilerights` VALUES ('1139','13','license','0');
INSERT INTO `glpi_profilerights` VALUES ('1138','13','knowbasecategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1137','13','knowbase','0');
INSERT INTO `glpi_profilerights` VALUES ('1136','13','itilcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1135','13','internet','23');
INSERT INTO `glpi_profilerights` VALUES ('1134','13','infocom','0');
INSERT INTO `glpi_profilerights` VALUES ('1133','13','group','0');
INSERT INTO `glpi_profilerights` VALUES ('1132','13','followup','0');
INSERT INTO `glpi_profilerights` VALUES ('1131','13','entity','0');
INSERT INTO `glpi_profilerights` VALUES ('1130','13','dropdown','0');
INSERT INTO `glpi_profilerights` VALUES ('1129','13','domain','0');
INSERT INTO `glpi_profilerights` VALUES ('1128','13','document','0');
INSERT INTO `glpi_profilerights` VALUES ('1127','13','device','0');
INSERT INTO `glpi_profilerights` VALUES ('1126','13','contract','0');
INSERT INTO `glpi_profilerights` VALUES ('1125','13','contact_enterprise','0');
INSERT INTO `glpi_profilerights` VALUES ('1124','13','consumable','119');
INSERT INTO `glpi_profilerights` VALUES ('1123','13','config','0');
INSERT INTO `glpi_profilerights` VALUES ('1122','13','computer','119');
INSERT INTO `glpi_profilerights` VALUES ('1121','13','changevalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1120','13','change','0');
INSERT INTO `glpi_profilerights` VALUES ('1119','13','cartridge','119');
INSERT INTO `glpi_profilerights` VALUES ('1118','13','calendar','0');
INSERT INTO `glpi_profilerights` VALUES ('1117','13','budget','0');
INSERT INTO `glpi_profilerights` VALUES ('1116','13','bookmark_public','0');
INSERT INTO `glpi_profilerights` VALUES ('1115','13','backup','0');
INSERT INTO `glpi_profilerights` VALUES ('1167','13','rule_softwarecategories','0');
INSERT INTO `glpi_profilerights` VALUES ('1168','13','rule_ticket','0');
INSERT INTO `glpi_profilerights` VALUES ('1169','13','search_config','0');
INSERT INTO `glpi_profilerights` VALUES ('1170','13','show_group_hardware','0');
INSERT INTO `glpi_profilerights` VALUES ('1171','13','sla','0');
INSERT INTO `glpi_profilerights` VALUES ('1172','13','software','119');
INSERT INTO `glpi_profilerights` VALUES ('1173','13','solutiontemplate','0');
INSERT INTO `glpi_profilerights` VALUES ('1174','13','state','0');
INSERT INTO `glpi_profilerights` VALUES ('1175','13','statistic','0');
INSERT INTO `glpi_profilerights` VALUES ('1176','13','task','0');
INSERT INTO `glpi_profilerights` VALUES ('1177','13','taskcategory','0');
INSERT INTO `glpi_profilerights` VALUES ('1178','13','ticket','261151');
INSERT INTO `glpi_profilerights` VALUES ('1179','13','ticketcost','23');
INSERT INTO `glpi_profilerights` VALUES ('1180','13','ticketrecurrent','23');
INSERT INTO `glpi_profilerights` VALUES ('1181','13','tickettemplate','23');
INSERT INTO `glpi_profilerights` VALUES ('1182','13','ticketvalidation','0');
INSERT INTO `glpi_profilerights` VALUES ('1183','13','transfer','0');
INSERT INTO `glpi_profilerights` VALUES ('1184','13','typedoc','0');
INSERT INTO `glpi_profilerights` VALUES ('1185','13','user','0');

### Dump table glpi_profiles

DROP TABLE IF EXISTS `glpi_profiles`;
CREATE TABLE `glpi_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interface` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'helpdesk',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `helpdesk_hardware` int(11) NOT NULL DEFAULT '0',
  `helpdesk_item_type` text COLLATE utf8_unicode_ci,
  `ticket_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `problem_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `create_ticket_on_login` tinyint(1) NOT NULL DEFAULT '0',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `change_status` text COLLATE utf8_unicode_ci COMMENT 'json encoded array of from/dest allowed status change',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `interface` (`interface`),
  KEY `is_default` (`is_default`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profiles` VALUES ('4','Administrador','central','0','3','[\"Computer\",\"Monitor\",\"NetworkEquipment\",\"Peripheral\",\"Phone\",\"Printer\",\"Software\"]','[]','2017-07-18 09:57:38',NULL,'[]','1','0',NULL,NULL);
INSERT INTO `glpi_profiles` VALUES ('10','Solicitante','helpdesk','1','1','[\"Computer\",\"Monitor\",\"Printer\",\"Software\"]',NULL,'2017-07-25 18:11:04','',NULL,'1','0',NULL,'2017-07-13 16:05:35');
INSERT INTO `glpi_profiles` VALUES ('11','Super Administrador','central','0','3','[]',NULL,'2017-07-18 09:48:14','',NULL,'0','0',NULL,'2017-07-18 09:45:34');
INSERT INTO `glpi_profiles` VALUES ('13','Soporte','central','0','0','[]',NULL,'2017-08-18 13:05:41','',NULL,'0','0',NULL,'2017-07-27 11:32:10');

### Dump table glpi_profiles_reminders

DROP TABLE IF EXISTS `glpi_profiles_reminders`;
CREATE TABLE `glpi_profiles_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profiles_rssfeeds

DROP TABLE IF EXISTS `glpi_profiles_rssfeeds`;
CREATE TABLE `glpi_profiles_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '-1',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_profiles_users

DROP TABLE IF EXISTS `glpi_profiles_users`;
CREATE TABLE `glpi_profiles_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `users_id` (`users_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_profiles_users` VALUES ('2','2','11','0','1','0');
INSERT INTO `glpi_profiles_users` VALUES ('15','9','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('8','7','4','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('7','6','4','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('14','8','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('16','10','4','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('17','11','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('18','11','13','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('19','12','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('20','13','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('21','14','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('22','15','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('23','16','10','0','0','0');
INSERT INTO `glpi_profiles_users` VALUES ('24','17','10','0','0','0');

### Dump table glpi_projectcosts

DROP TABLE IF EXISTS `glpi_projectcosts`;
CREATE TABLE `glpi_projectcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `cost` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `projects_id` (`projects_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projects

DROP TABLE IF EXISTS `glpi_projects`;
CREATE TABLE `glpi_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttypes_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `show_on_global_gantt` tinyint(1) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `code` (`code`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttypes_id` (`projecttypes_id`),
  KEY `priority` (`priority`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `groups_id` (`groups_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `show_on_global_gantt` (`show_on_global_gantt`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projectstates

DROP TABLE IF EXISTS `glpi_projectstates`;
CREATE TABLE `glpi_projectstates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_finished` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_finished` (`is_finished`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_projectstates` VALUES ('1','New',NULL,'#06ff00','0',NULL,NULL);
INSERT INTO `glpi_projectstates` VALUES ('2','Processing',NULL,'#ffb800','0',NULL,NULL);
INSERT INTO `glpi_projectstates` VALUES ('3','Closed',NULL,'#ff0000','1',NULL,NULL);

### Dump table glpi_projecttasks

DROP TABLE IF EXISTS `glpi_projecttasks`;
CREATE TABLE `glpi_projecttasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `comment` longtext COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `plan_start_date` datetime DEFAULT NULL,
  `plan_end_date` datetime DEFAULT NULL,
  `real_start_date` datetime DEFAULT NULL,
  `real_end_date` datetime DEFAULT NULL,
  `planned_duration` int(11) NOT NULL DEFAULT '0',
  `effective_duration` int(11) NOT NULL DEFAULT '0',
  `projectstates_id` int(11) NOT NULL DEFAULT '0',
  `projecttasktypes_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `percent_done` int(11) NOT NULL DEFAULT '0',
  `is_milestone` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `projects_id` (`projects_id`),
  KEY `projecttasks_id` (`projecttasks_id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `plan_start_date` (`plan_start_date`),
  KEY `plan_end_date` (`plan_end_date`),
  KEY `real_start_date` (`real_start_date`),
  KEY `real_end_date` (`real_end_date`),
  KEY `percent_done` (`percent_done`),
  KEY `projectstates_id` (`projectstates_id`),
  KEY `projecttasktypes_id` (`projecttasktypes_id`),
  KEY `is_milestone` (`is_milestone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttasks_tickets

DROP TABLE IF EXISTS `glpi_projecttasks_tickets`;
CREATE TABLE `glpi_projecttasks_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`projecttasks_id`),
  KEY `projects_id` (`projecttasks_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttaskteams

DROP TABLE IF EXISTS `glpi_projecttaskteams`;
CREATE TABLE `glpi_projecttaskteams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projecttasks_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projecttasks_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttasktypes

DROP TABLE IF EXISTS `glpi_projecttasktypes`;
CREATE TABLE `glpi_projecttasktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projectteams

DROP TABLE IF EXISTS `glpi_projectteams`;
CREATE TABLE `glpi_projectteams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `projects_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`projects_id`,`itemtype`,`items_id`),
  KEY `item` (`itemtype`,`items_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_projecttypes

DROP TABLE IF EXISTS `glpi_projecttypes`;
CREATE TABLE `glpi_projecttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_queuedmails

DROP TABLE IF EXISTS `glpi_queuedmails`;
CREATE TABLE `glpi_queuedmails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `notificationtemplates_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `sent_try` int(11) NOT NULL DEFAULT '0',
  `create_time` datetime DEFAULT NULL,
  `send_time` datetime DEFAULT NULL,
  `sent_time` datetime DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `sender` text COLLATE utf8_unicode_ci,
  `sendername` text COLLATE utf8_unicode_ci,
  `recipient` text COLLATE utf8_unicode_ci,
  `recipientname` text COLLATE utf8_unicode_ci,
  `replyto` text COLLATE utf8_unicode_ci,
  `replytoname` text COLLATE utf8_unicode_ci,
  `headers` text COLLATE utf8_unicode_ci,
  `body_html` longtext COLLATE utf8_unicode_ci,
  `body_text` longtext COLLATE utf8_unicode_ci,
  `messageid` text COLLATE utf8_unicode_ci,
  `documents` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `item` (`itemtype`,`items_id`,`notificationtemplates_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `entities_id` (`entities_id`),
  KEY `sent_try` (`sent_try`),
  KEY `create_time` (`create_time`),
  KEY `send_time` (`send_time`),
  KEY `sent_time` (`sent_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_queuedmails` VALUES ('138','User','2','13','0','1','0','2018-02-28 10:14:18','2018-02-28 10:14:18','2018-02-28 10:14:18','[GLPI] Ha olvidado la contraseña?','gestiontifnsp@udea.edu.co','Área Académica de desarrollo didáctico y tecnológico ','juan.correa2@udea.edu.co','Juan David Correa','gestiontifnsp@udea.edu.co','Área Académica de desarrollo didáctico y tecnológico','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI] Ha olvidado la contrase&ntilde;a?</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<p><strong>Correa Juan David</strong></p>
<p>Ha solicitado reiniciar su contrase&ntilde;a</p>
<p>S&oacute;lo tienes que seguir este enlace (tiene un d&iacute;a): <a title=\"http://saludpublicavirtual.udea.edu.co/glpi/front/lostpassword.php?password_forget_token=8d2e7e14ad77b69c647899d48dda09ae322dc19a\" href=\"http://saludpublicavirtual.udea.edu.co/glpi/front/lostpassword.php?password_forget_token=8d2e7e14ad77b69c647899d48dda09ae322dc19a\">http://saludpublicavirtual.udea.edu.co/glpi/front/lostpassword.php?password_forget_token=8d2e7e14ad77b69c647899d48dda09ae322dc19a</a></p><br><br>-- 
<br>&Aacute;rea Acad&eacute;mica de desarrollo did&aacute;ctico y tecnol&oacute;gico <br>Generados automáticamente por GLPI 9.1.4<br><br>

</body></html>','Correa Juan David

Ha solicitado reiniciar su contraseña

Sólo tienes que seguir este enlace (tiene un día): http://saludpublicavirtual.udea.edu.co/glpi/front/lostpassword.php?password_forget_token=8d2e7e14ad77b69c647899d48dda09ae322dc19a

-- 
Área Académica de desarrollo didáctico y tecnológico 
Generados automáticamente por GLPI 9.1.4

',NULL,'');
INSERT INTO `glpi_queuedmails` VALUES ('139','Ticket','13','4','0','1','0','2018-02-28 10:20:35','2018-02-28 10:20:35','2018-02-28 10:20:35','[GLPI #0000013] Nueva incidencia Prueba','gestiontifnsp@udea.edu.co','Área Académica de desarrollo didáctico y tecnológico ','gestiontifnsp@udea.edu.co','Área Académica de desarrollo didáctico y tecnológico ','gestiontifnsp@udea.edu.co','Área Académica de desarrollo didáctico y tecnológico','{\"Auto-Submitted\":\"auto-generated\",\"X-Auto-Response-Suppress\":\"OOF, DR, NDR, RN, NRN\"}','<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"
                        \'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\'><html>
                        <head>
                         <META http-equiv=\'Content-Type\' content=\'text/html; charset=utf-8\'>
                         <title>[GLPI #0000013] Nueva incidencia Prueba</title>
                         <style type=\'text/css\'>
                           
                         </style>
                        </head>
                        <body>
<!-- description{ color: inherit; background: #ebebeb; border-style: solid;border-color: #8d8d8d; border-width: 0px 1px 1px 0px; }    -->
<div></div>
<div> URL : <a href=\"http://saludpublicavirtual.udea.edu.co/glpi/index.php?redirect=ticket_13&amp;noAUTO=1\">http://saludpublicavirtual.udea.edu.co/glpi/index.php?redirect=ticket_13&amp;noAUTO=1</a> </div>
<p class=\"description b\"><strong>Incidencia: Descripci&oacute;n</strong></p>
<p><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> T&iacute;tulo</span>&#160;:Prueba <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Solicitantes</span>&#160;: prueba prueba      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Fecha de Apertura</span>&#160;:2018-02-28 10:20 <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Fecha de cierre</span>&#160;: <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Origen de la solicitud</span>&#160;:Helpdesk<br />
<br /><span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Elementos asociados</span>&#160;:
<p></p>
<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Estado </span>&#160;: Nuevo<br /> <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Urgencia</span>&#160;: Mediana<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Impacto</span>&#160;: Medio<br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Prioridad</span>&#160;: Mediana <br />     <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\">Categor&iacute;a </span>&#160;:Sistemas &gt; Generar informe      <br /> <span style=\"color: #8b8c8f; font-weight: bold; text-decoration: underline;\"> Descripci&oacute;n</span>&#160;: Esto es una prueba</p>
<br /></p>
<div class=\"description b\">Numero de seguimientos&#160;: 0</div>
<p></p>
<div class=\"description b\">N&uacute;mero de tareas&#160;: 0</div>
<p></p><br><br>-- 
<br>&Aacute;rea Acad&eacute;mica de desarrollo did&aacute;ctico y tecnol&oacute;gico <br>Generados automáticamente por GLPI 9.1.4<br><br>

</body></html>','URL : http://saludpublicavirtual.udea.edu.co/glpi/index.php?redirect=ticket_13&amp;noAUTO=1 

Incidencia: Descripción

Título : Prueba
 Solicitantes : prueba prueba 
 Fecha de Apertura : 2018-02-28 10:20
 Fecha de cierre : 
 Origen de la solicitud : Helpdesk
Elementos asociados :

Estado : Nuevo

Urgencia : Mediana
 Impacto : Medio
 Prioridad : Mediana

Categoría : Sistemas &gt; Generar informe 
 Descripción : Esto es una prueba

Numero de seguimientos : 0

Número de tareas : 0

-- 
Área Académica de desarrollo didáctico y tecnológico 
Generados automáticamente por GLPI 9.1.4

','GLPI-13.1519831235.15345@SPS-DLLOAPPS','');

### Dump table glpi_registeredids

DROP TABLE IF EXISTS `glpi_registeredids`;
CREATE TABLE `glpi_registeredids` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `items_id` int(11) NOT NULL DEFAULT '0',
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `device_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'USB, PCI ...',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `item` (`items_id`,`itemtype`),
  KEY `device_type` (`device_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reminders

DROP TABLE IF EXISTS `glpi_reminders`;
CREATE TABLE `glpi_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8_unicode_ci,
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `is_planned` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '0',
  `begin_view_date` datetime DEFAULT NULL,
  `end_view_date` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `users_id` (`users_id`),
  KEY `is_planned` (`is_planned`),
  KEY `state` (`state`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reminders_users

DROP TABLE IF EXISTS `glpi_reminders_users`;
CREATE TABLE `glpi_reminders_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reminders_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `reminders_id` (`reminders_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_requesttypes

DROP TABLE IF EXISTS `glpi_requesttypes`;
CREATE TABLE `glpi_requesttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_helpdesk_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_followup_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_mail_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_mailfollowup_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_ticketheader` tinyint(1) NOT NULL DEFAULT '1',
  `is_ticketfollowup` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_helpdesk_default` (`is_helpdesk_default`),
  KEY `is_followup_default` (`is_followup_default`),
  KEY `is_mail_default` (`is_mail_default`),
  KEY `is_mailfollowup_default` (`is_mailfollowup_default`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `is_active` (`is_active`),
  KEY `is_ticketheader` (`is_ticketheader`),
  KEY `is_ticketfollowup` (`is_ticketfollowup`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_requesttypes` VALUES ('1','Helpdesk','1','1','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('2','E-Mail','0','0','1','1','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('3','Phone','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('4','Direct','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('5','Written','0','0','0','0','1','1','1',NULL,NULL,NULL);
INSERT INTO `glpi_requesttypes` VALUES ('6','Other','0','0','0','0','1','1','1',NULL,NULL,NULL);

### Dump table glpi_reservationitems

DROP TABLE IF EXISTS `glpi_reservationitems`;
CREATE TABLE `glpi_reservationitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemtype` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `items_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `is_active` (`is_active`),
  KEY `item` (`itemtype`,`items_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_deleted` (`is_deleted`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_reservations

DROP TABLE IF EXISTS `glpi_reservations`;
CREATE TABLE `glpi_reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservationitems_id` int(11) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `group` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `begin` (`begin`),
  KEY `end` (`end`),
  KEY `reservationitems_id` (`reservationitems_id`),
  KEY `users_id` (`users_id`),
  KEY `resagroup` (`reservationitems_id`,`group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_rssfeeds

DROP TABLE IF EXISTS `glpi_rssfeeds`;
CREATE TABLE `glpi_rssfeeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `url` text COLLATE utf8_unicode_ci,
  `refresh_rate` int(11) NOT NULL DEFAULT '86400',
  `max_items` int(11) NOT NULL DEFAULT '20',
  `have_error` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `users_id` (`users_id`),
  KEY `date_mod` (`date_mod`),
  KEY `have_error` (`have_error`),
  KEY `is_active` (`is_active`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_rssfeeds_users

DROP TABLE IF EXISTS `glpi_rssfeeds_users`;
CREATE TABLE `glpi_rssfeeds_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rssfeeds_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `rssfeeds_id` (`rssfeeds_id`),
  KEY `users_id` (`users_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ruleactions

DROP TABLE IF EXISTS `glpi_ruleactions`;
CREATE TABLE `glpi_ruleactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rules_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'VALUE IN (assign, regex_result, append_regex_result, affectbyip, affectbyfqdn, affectbymac)',
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `field_value` (`field`(50),`value`(50))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ruleactions` VALUES ('6','6','fromitem','locations_id','1');
INSERT INTO `glpi_ruleactions` VALUES ('2','2','assign','entities_id','0');
INSERT INTO `glpi_ruleactions` VALUES ('3','3','assign','entities_id','0');
INSERT INTO `glpi_ruleactions` VALUES ('4','4','assign','_refuse_email_no_response','1');
INSERT INTO `glpi_ruleactions` VALUES ('5','5','assign','_refuse_email_no_response','1');
INSERT INTO `glpi_ruleactions` VALUES ('7','7','fromuser','locations_id','1');

### Dump table glpi_rulecriterias

DROP TABLE IF EXISTS `glpi_rulecriterias`;
CREATE TABLE `glpi_rulecriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rules_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rules_id` (`rules_id`),
  KEY `condition` (`condition`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rulecriterias` VALUES ('9','6','locations_id','9','1');
INSERT INTO `glpi_rulecriterias` VALUES ('2','2','uid','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('3','2','samaccountname','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('4','2','MAIL_EMAIL','0','*');
INSERT INTO `glpi_rulecriterias` VALUES ('5','3','subject','6','/.*/');
INSERT INTO `glpi_rulecriterias` VALUES ('6','4','x-auto-response-suppress','6','/\\S+/');
INSERT INTO `glpi_rulecriterias` VALUES ('7','5','auto-submitted','6','/\\S+/');
INSERT INTO `glpi_rulecriterias` VALUES ('8','5','auto-submitted','1','no');
INSERT INTO `glpi_rulecriterias` VALUES ('10','6','items_locations','8','1');
INSERT INTO `glpi_rulecriterias` VALUES ('11','7','locations_id','9','1');
INSERT INTO `glpi_rulecriterias` VALUES ('12','7','users_locations','8','1');

### Dump table glpi_rulerightparameters

DROP TABLE IF EXISTS `glpi_rulerightparameters`;
CREATE TABLE `glpi_rulerightparameters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rulerightparameters` VALUES ('1','(LDAP)Organization','o','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('2','(LDAP)Common Name','cn','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('3','(LDAP)Department Number','departmentnumber','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('4','(LDAP)Email','mail','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('5','Object Class','objectclass','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('6','(LDAP)User ID','uid','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('7','(LDAP)Telephone Number','phone','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('8','(LDAP)Employee Number','employeenumber','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('9','(LDAP)Manager','manager','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('10','(LDAP)DistinguishedName','dn','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('12','(AD)User ID','samaccountname','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('13','(LDAP) Title','title','',NULL,NULL);
INSERT INTO `glpi_rulerightparameters` VALUES ('14','(LDAP) MemberOf','memberof','',NULL,NULL);

### Dump table glpi_rules

DROP TABLE IF EXISTS `glpi_rules`;
CREATE TABLE `glpi_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `sub_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `ranking` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_active` (`is_active`),
  KEY `sub_type` (`sub_type`),
  KEY `date_mod` (`date_mod`),
  KEY `is_recursive` (`is_recursive`),
  KEY `condition` (`condition`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_rules` VALUES ('2','0','RuleRight','1','Root','','OR','1',NULL,NULL,'0','500717c8-2bd6e957-53a12b5fd35745.02608131','0',NULL);
INSERT INTO `glpi_rules` VALUES ('3','0','RuleMailCollector','3','Root','','OR','1',NULL,NULL,'0','500717c8-2bd6e957-53a12b5fd36404.54713349','0',NULL);
INSERT INTO `glpi_rules` VALUES ('4','0','RuleMailCollector','1','Auto-Reply X-Auto-Response-Suppress','Exclude Auto-Reply emails using X-Auto-Response-Suppress header','AND','1',NULL,'2011-01-18 11:40:42','1','500717c8-2bd6e957-53a12b5fd36d97.94503423','0',NULL);
INSERT INTO `glpi_rules` VALUES ('5','0','RuleMailCollector','2','Auto-Reply Auto-Submitted','Exclude Auto-Reply emails using Auto-Submitted header','AND','1',NULL,'2011-01-18 11:40:42','1','500717c8-2bd6e957-53a12b5fd376c2.87642651','0',NULL);
INSERT INTO `glpi_rules` VALUES ('6','0','RuleTicket','1','Ticket location from item','','AND','0','Automatically generated by GLPI 0.84',NULL,'1','500717c8-2bd6e957-53a12b5fd37f94.10365341','1',NULL);
INSERT INTO `glpi_rules` VALUES ('7','0','RuleTicket','2','Ticket location from user','','AND','0','Automatically generated by GLPI 0.84',NULL,'1','500717c8-2bd6e957-53a12b5fd38869.86002585','1',NULL);

### Dump table glpi_slalevelactions

DROP TABLE IF EXISTS `glpi_slalevelactions`;
CREATE TABLE `glpi_slalevelactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slalevels_id` (`slalevels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevelcriterias

DROP TABLE IF EXISTS `glpi_slalevelcriterias`;
CREATE TABLE `glpi_slalevelcriterias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `criteria` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `condition` int(11) NOT NULL DEFAULT '0' COMMENT 'see define.php PATTERN_* and REGEX_* constant',
  `pattern` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `slalevels_id` (`slalevels_id`),
  KEY `condition` (`condition`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevels

DROP TABLE IF EXISTS `glpi_slalevels`;
CREATE TABLE `glpi_slalevels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slts_id` int(11) NOT NULL DEFAULT '0',
  `execution_time` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `match` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php *_MATCHING constant',
  `uuid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_active` (`is_active`),
  KEY `slts_id` (`slts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slalevels_tickets

DROP TABLE IF EXISTS `glpi_slalevels_tickets`;
CREATE TABLE `glpi_slalevels_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `slalevels_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `slalevels_id` (`slalevels_id`),
  KEY `unicity` (`tickets_id`,`slalevels_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slas

DROP TABLE IF EXISTS `glpi_slas`;
CREATE TABLE `glpi_slas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `calendars_id` (`calendars_id`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_slts

DROP TABLE IF EXISTS `glpi_slts`;
CREATE TABLE `glpi_slts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `number_time` int(11) NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `definition_time` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_of_working_day` tinyint(1) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  `slas_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`),
  KEY `slas_id` (`slas_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwarecategories

DROP TABLE IF EXISTS `glpi_softwarecategories`;
CREATE TABLE `glpi_softwarecategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `softwarecategories_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `softwarecategories_id` (`softwarecategories_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarecategories` VALUES ('1','FUSION',NULL,'0','FUSION','1',NULL,NULL);

### Dump table glpi_softwarelicenses

DROP TABLE IF EXISTS `glpi_softwarelicenses`;
CREATE TABLE `glpi_softwarelicenses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `softwarelicensetypes_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `serial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `otherserial` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `softwareversions_id_buy` int(11) NOT NULL DEFAULT '0',
  `softwareversions_id_use` int(11) NOT NULL DEFAULT '0',
  `expire` date DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `is_valid` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `is_helpdesk_visible` tinyint(1) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `contact` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_num` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `serial` (`serial`),
  KEY `otherserial` (`otherserial`),
  KEY `expire` (`expire`),
  KEY `softwareversions_id_buy` (`softwareversions_id_buy`),
  KEY `entities_id` (`entities_id`),
  KEY `softwarelicensetypes_id` (`softwarelicensetypes_id`),
  KEY `softwareversions_id_use` (`softwareversions_id_use`),
  KEY `date_mod` (`date_mod`),
  KEY `softwares_id_expire` (`softwares_id`,`expire`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `users_id` (`users_id`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `groups_id` (`groups_id`),
  KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  KEY `is_deleted` (`is_helpdesk_visible`),
  KEY `date_creation` (`date_creation`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `states_id` (`states_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwarelicensetypes

DROP TABLE IF EXISTS `glpi_softwarelicensetypes`;
CREATE TABLE `glpi_softwarelicensetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_softwarelicensetypes` VALUES ('1','OEM','',NULL,NULL);

### Dump table glpi_softwares

DROP TABLE IF EXISTS `glpi_softwares`;
CREATE TABLE `glpi_softwares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `is_update` tinyint(1) NOT NULL DEFAULT '0',
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `manufacturers_id` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_template` tinyint(1) NOT NULL DEFAULT '0',
  `template_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `groups_id` int(11) NOT NULL DEFAULT '0',
  `ticket_tco` decimal(20,4) DEFAULT '0.0000',
  `is_helpdesk_visible` tinyint(1) NOT NULL DEFAULT '1',
  `softwarecategories_id` int(11) NOT NULL DEFAULT '0',
  `is_valid` tinyint(1) NOT NULL DEFAULT '1',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `name` (`name`),
  KEY `is_template` (`is_template`),
  KEY `is_update` (`is_update`),
  KEY `softwarecategories_id` (`softwarecategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `manufacturers_id` (`manufacturers_id`),
  KEY `groups_id` (`groups_id`),
  KEY `users_id` (`users_id`),
  KEY `locations_id` (`locations_id`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `softwares_id` (`softwares_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_helpdesk_visible` (`is_helpdesk_visible`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_softwareversions

DROP TABLE IF EXISTS `glpi_softwareversions`;
CREATE TABLE `glpi_softwareversions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `softwares_id` int(11) NOT NULL DEFAULT '0',
  `states_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `operatingsystems_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `softwares_id` (`softwares_id`),
  KEY `states_id` (`states_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `operatingsystems_id` (`operatingsystems_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_solutiontemplates

DROP TABLE IF EXISTS `glpi_solutiontemplates`;
CREATE TABLE `glpi_solutiontemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_solutiontypes

DROP TABLE IF EXISTS `glpi_solutiontypes`;
CREATE TABLE `glpi_solutiontypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ssovariables

DROP TABLE IF EXISTS `glpi_ssovariables`;
CREATE TABLE `glpi_ssovariables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ssovariables` VALUES ('1','HTTP_AUTH_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('2','REMOTE_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('3','PHP_AUTH_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('4','USERNAME','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('5','REDIRECT_REMOTE_USER','',NULL,NULL);
INSERT INTO `glpi_ssovariables` VALUES ('6','HTTP_REMOTE_USER','',NULL,NULL);

### Dump table glpi_states

DROP TABLE IF EXISTS `glpi_states`;
CREATE TABLE `glpi_states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `states_id` int(11) NOT NULL DEFAULT '0',
  `completename` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_visible_computer` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_monitor` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_networkequipment` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_peripheral` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_phone` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_printer` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_softwareversion` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_softwarelicense` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `unicity` (`states_id`,`name`),
  KEY `is_visible_computer` (`is_visible_computer`),
  KEY `is_visible_monitor` (`is_visible_monitor`),
  KEY `is_visible_networkequipment` (`is_visible_networkequipment`),
  KEY `is_visible_peripheral` (`is_visible_peripheral`),
  KEY `is_visible_phone` (`is_visible_phone`),
  KEY `is_visible_printer` (`is_visible_printer`),
  KEY `is_visible_softwareversion` (`is_visible_softwareversion`),
  KEY `is_visible_softwarelicense` (`is_visible_softwarelicense`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_states` VALUES ('1','Activo','0','0','','0','Activo','1',NULL,NULL,'1','1','1','1','1','1','1','1','2017-07-26 10:36:01','2017-07-26 10:36:01');
INSERT INTO `glpi_states` VALUES ('2','En mantenimiento','0','0','','0','En mantenimiento','1',NULL,NULL,'1','1','1','1','1','1','1','1','2017-07-26 10:36:12','2017-07-26 10:36:12');
INSERT INTO `glpi_states` VALUES ('3','Reintegrado','0','0','','0','Reintegrado','1',NULL,NULL,'1','1','1','1','1','1','1','1','2017-07-26 10:36:38','2017-07-26 10:36:38');

### Dump table glpi_suppliers

DROP TABLE IF EXISTS `glpi_suppliers`;
CREATE TABLE `glpi_suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suppliertypes_id` int(11) NOT NULL DEFAULT '0',
  `address` text COLLATE utf8_unicode_ci,
  `postcode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `town` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phonenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `fax` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `suppliertypes_id` (`suppliertypes_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_suppliers_tickets

DROP TABLE IF EXISTS `glpi_suppliers_tickets`;
CREATE TABLE `glpi_suppliers_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `suppliers_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '0',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`suppliers_id`),
  KEY `group` (`suppliers_id`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_suppliertypes

DROP TABLE IF EXISTS `glpi_suppliertypes`;
CREATE TABLE `glpi_suppliertypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_taskcategories

DROP TABLE IF EXISTS `glpi_taskcategories`;
CREATE TABLE `glpi_taskcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completename` text COLLATE utf8_unicode_ci,
  `comment` text COLLATE utf8_unicode_ci,
  `level` int(11) NOT NULL DEFAULT '0',
  `ancestors_cache` longtext COLLATE utf8_unicode_ci,
  `sons_cache` longtext COLLATE utf8_unicode_ci,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_helpdeskvisible` tinyint(1) NOT NULL DEFAULT '1',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_active` (`is_active`),
  KEY `is_helpdeskvisible` (`is_helpdeskvisible`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tasktemplates

DROP TABLE IF EXISTS `glpi_tasktemplates`;
CREATE TABLE `glpi_tasktemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `is_recursive` (`is_recursive`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `entities_id` (`entities_id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketcosts

DROP TABLE IF EXISTS `glpi_ticketcosts`;
CREATE TABLE `glpi_ticketcosts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `begin_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `cost_time` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_fixed` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `cost_material` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `budgets_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `tickets_id` (`tickets_id`),
  KEY `begin_date` (`begin_date`),
  KEY `end_date` (`end_date`),
  KEY `entities_id` (`entities_id`),
  KEY `budgets_id` (`budgets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_ticketfollowups

DROP TABLE IF EXISTS `glpi_ticketfollowups`;
CREATE TABLE `glpi_ticketfollowups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `requesttypes_id` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `is_private` (`is_private`),
  KEY `requesttypes_id` (`requesttypes_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_ticketfollowups` VALUES ('1','5','2017-11-16 16:48:47','2','Cordial saludo Lina, se realiza una verificación de SISO para dar solución al incidente. 
Una feliz tarde','0','1','2017-11-16 16:48:47');

### Dump table glpi_ticketrecurrents

DROP TABLE IF EXISTS `glpi_ticketrecurrents`;
CREATE TABLE `glpi_ticketrecurrents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `begin_date` datetime DEFAULT NULL,
  `periodicity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_before` int(11) NOT NULL DEFAULT '0',
  `next_creation_date` datetime DEFAULT NULL,
  `calendars_id` int(11) NOT NULL DEFAULT '0',
  `end_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`),
  KEY `is_active` (`is_active`),
  KEY `tickettemplates_id` (`tickettemplates_id`),
  KEY `next_creation_date` (`next_creation_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets

DROP TABLE IF EXISTS `glpi_tickets`;
CREATE TABLE `glpi_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `closedate` datetime DEFAULT NULL,
  `solvedate` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `users_id_lastupdater` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '1',
  `users_id_recipient` int(11) NOT NULL DEFAULT '0',
  `requesttypes_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `urgency` int(11) NOT NULL DEFAULT '1',
  `impact` int(11) NOT NULL DEFAULT '1',
  `priority` int(11) NOT NULL DEFAULT '1',
  `itilcategories_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `solutiontypes_id` int(11) NOT NULL DEFAULT '0',
  `solution` longtext COLLATE utf8_unicode_ci,
  `global_validation` int(11) NOT NULL DEFAULT '1',
  `slts_tto_id` int(11) NOT NULL DEFAULT '0',
  `slts_ttr_id` int(11) NOT NULL DEFAULT '0',
  `ttr_slalevels_id` int(11) NOT NULL DEFAULT '0',
  `due_date` datetime DEFAULT NULL,
  `time_to_own` datetime DEFAULT NULL,
  `begin_waiting_date` datetime DEFAULT NULL,
  `sla_waiting_duration` int(11) NOT NULL DEFAULT '0',
  `waiting_duration` int(11) NOT NULL DEFAULT '0',
  `close_delay_stat` int(11) NOT NULL DEFAULT '0',
  `solve_delay_stat` int(11) NOT NULL DEFAULT '0',
  `takeintoaccount_delay_stat` int(11) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `validation_percent` int(11) NOT NULL DEFAULT '0',
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `closedate` (`closedate`),
  KEY `status` (`status`),
  KEY `priority` (`priority`),
  KEY `request_type` (`requesttypes_id`),
  KEY `date_mod` (`date_mod`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id_recipient` (`users_id_recipient`),
  KEY `solvedate` (`solvedate`),
  KEY `urgency` (`urgency`),
  KEY `impact` (`impact`),
  KEY `global_validation` (`global_validation`),
  KEY `slts_tto_id` (`slts_tto_id`),
  KEY `slts_ttr_id` (`slts_ttr_id`),
  KEY `due_date` (`due_date`),
  KEY `time_to_own` (`time_to_own`),
  KEY `users_id_lastupdater` (`users_id_lastupdater`),
  KEY `type` (`type`),
  KEY `solutiontypes_id` (`solutiontypes_id`),
  KEY `itilcategories_id` (`itilcategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `name` (`name`),
  KEY `locations_id` (`locations_id`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickets` VALUES ('1','0','hj','2017-08-15 23:57:38',NULL,NULL,'2017-12-06 14:48:35','2','2','11','1','&lt;p&gt;hj&lt;/p&gt;','3','3','3','2','2','0','&lt;p&gt;Se dio solucion al incidente&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','0','0','165','0','1','17','0','2017-08-15 23:57:38');
INSERT INTO `glpi_tickets` VALUES ('2','0','sv','2017-11-02 15:48:00',NULL,'2017-11-03 11:28:16','2017-11-03 11:28:16','2','5','8','1','&lt;p&gt;xcvvxcxetete&lt;/p&gt;','5','3','4','12','1','0',NULL,'1','0','0','0',NULL,NULL,'2017-11-03 11:28:16','0','0','0','70816','70816','0','0','0','0','2017-11-02 15:48:00');
INSERT INTO `glpi_tickets` VALUES ('3','0','diseño boletin','2017-11-07 16:14:00',NULL,NULL,'2017-12-06 14:48:35','17','1','17','1','&lt;p&gt;Hola Caludia!!!!!  estoy probando boooo&lt;/p&gt;','3','3','3','28','1','0',NULL,'1','0','0','0',NULL,NULL,NULL,'0','0','0','0','0','0','1','4','0','2017-11-07 16:14:00');
INSERT INTO `glpi_tickets` VALUES ('4','0','Activación reporte en SISREC','2017-11-14 10:40:42',NULL,'2017-11-14 16:05:32','2017-11-14 16:05:32','2','5','14','1','&lt;p&gt;]Se solicita activar reporte de octubre para el contratista con CC 1152702694.&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;NOTA 1: La oficina 232 es del Jefe del Centro de Investigación:&lt;/p&gt;
&lt;p&gt;NOTA 2: La oficina 237, donde me ubico, no está en el listado.&lt;/p&gt;','5','3','4','2','2','0',NULL,'1','0','0','0','2017-11-14 10:55:00','2017-11-14 10:50:00','2017-11-14 16:05:32','0','0','0','19490','19416','0','0','47','0','2017-11-14 10:40:42');
INSERT INTO `glpi_tickets` VALUES ('5','0','Dificultad para agregar persona en SISO','2017-11-16 14:59:13','2017-11-24 14:42:59','2017-11-24 14:42:59','2017-11-24 14:42:59','2','6','14','1','&lt;p&gt;He intentado agregar una persona al SISO, como contratista, pero no guarda. Adjunto pantallazo donde se ve el error que arroja el sistema. Gracias.&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Ya lo resolví. Gracias.&lt;/p&gt;','3','3','3','2','1','0','&lt;p&gt;Se ha reiniciado nuevamente el servicio, por favor realiza la verificación ene l sistema. &lt;/p&gt;','3','0','0','0','2017-11-16 18:00:00','2017-11-23 19:00:00',NULL,'0','0','690226','690226','6574','0','0','47','0','2017-11-16 14:59:13');
INSERT INTO `glpi_tickets` VALUES ('6','0','Solicitud cambio de planilla de seguridad social','2017-11-23 14:51:37','2017-11-24 14:41:41','2017-11-24 14:41:41','2017-11-24 14:41:41','2','6','14','1','&lt;p&gt;Buenas tardes Juan David,&lt;/p&gt;&lt;p&gt;Solicito por favor reemplazar la planilla de seguridad social que se encuentra en el reporte de noviembre de la contratista Alejandra Marin Uribe, cc 33917588 por el archivo que adjunto.&lt;/p&gt;&lt;p&gt;&lt;br /&gt;Muchas gracias.&lt;/p&gt;','5','3','4','9','1','0','&lt;p&gt;Cordial saludo Lina, &lt;br /&gt;El documento se ha reemplazado en el sistema. &lt;br /&gt;Una feliz día.&lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','85804','85804','85804','0','0','47','0','2017-11-23 14:51:37');
INSERT INTO `glpi_tickets` VALUES ('7','0','Solicitud cambio de planilla en SISREC','2017-11-28 11:01:36',NULL,NULL,'2017-12-06 14:51:12','2','4','14','1','&lt;p&gt;Buenos días,&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Solicito el cambio de la planilla de la contratista SANDRA PATRICIA LARA VARGAS, cc 43479573 por el que anexo debido a que la planilla que está en el sistema es la de octubre. Gracias.&lt;/p&gt;','4','3','4','9','1','0',NULL,'4','0','0','0',NULL,NULL,'2017-12-06 14:51:12','0','0','0','0','704144','0','0','47','0','2017-11-28 11:01:36');
INSERT INTO `glpi_tickets` VALUES ('8','0','Solicitud agregar planilla de ajuste en SISREC','2017-11-28 11:12:04',NULL,NULL,'2017-12-06 14:51:52','2','4','14','1','&lt;p&gt;Buenos días,&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Solicito agregar la planilla adjunta que es de novedad al reporte de noviembre de JOHANA PRADA ACEVEDO, cc 63493037.&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;NOTA: En este momento el SISREC nos permite como administradores hacer ajustes en valores de SS o fechas de reporte, pero no deja cargar archivos de novedad de SS o cambio de planilla.&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Gracias.&lt;/p&gt;','4','3','4','9','1','0',NULL,'1','0','0','0',NULL,NULL,'2017-12-06 14:51:52','0','0','0','0','703410','0','0','47','0','2017-11-28 11:12:04');
INSERT INTO `glpi_tickets` VALUES ('9','0','Planilla de ajuste para SISREC','2017-11-29 14:29:59','2017-12-06 14:34:38','2017-12-06 14:33:18','2017-12-06 14:34:38','2','6','14','1','&lt;p&gt;Adjunto planilla de ajuste de SS de noviembre de la contratista Claudia Viviana Valencia. Gracias.&lt;/p&gt;','4','3','4','9','1','0','&lt;p&gt;Cordial saludo, &lt;/p&gt;
&lt;p&gt;El archivo ha sido modificado. &lt;/p&gt;
&lt;p&gt;Una feliz tarde&lt;/p&gt;','1','0','0','0',NULL,NULL,'2017-12-06 14:33:18','0','0','605079','604999','604999','0','0','47','0','2017-11-29 14:29:59');
INSERT INTO `glpi_tickets` VALUES ('10','0','Problema con escaneo','2017-12-05 10:26:41',NULL,NULL,'2017-12-06 15:02:44','2','1','14','1','&lt;p&gt;Buen día Felipe,&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;La impresora no me permite escanear a mi correo. Me ayudas por favor? Gracias.&lt;/p&gt;','5','3','4','13','2','0',NULL,'1','0','0','0',NULL,NULL,NULL,'0','0','0','0','102963','0','0','47','0','2017-12-05 10:26:41');
INSERT INTO `glpi_tickets` VALUES ('11','0','Impresora en estado de error','2017-12-05 13:50:44',NULL,NULL,'2017-12-06 14:50:41','2','4','14','1','&lt;p&gt;Buenas tardes Felipe,&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Te cuento que la impresora de la 237 se encuentra en estado de error, además no permite enviar escaneos al mail y escaneo y saca copias con una rraya.&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Te agradezco nos brindes soporte lo antes posible.&lt;/p&gt;
&lt;p&gt; &lt;/p&gt;
&lt;p&gt;Quedo atenta.&lt;/p&gt;','5','3','4','13','2','0',NULL,'3','0','0','0',NULL,'2017-12-06 19:00:00','2017-12-06 14:50:41','0','0','0','0','88777','3600','0','47','0','2017-12-05 13:50:44');
INSERT INTO `glpi_tickets` VALUES ('12','0','Solicitud cambio de planilla de SS','2017-12-06 14:10:59','2017-12-06 14:24:29','2017-12-06 14:24:29','2017-12-06 14:24:29','2','6','14','1','&lt;p&gt;Buenas tardes juan Daivd,&lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt;Te solicito por favor cambiar las planillas de los reportes de diciembre de las siguientes personas por las planillas que adjunto.&lt;/p&gt;&lt;p&gt;Diana Isabel Cano Gil&lt;/p&gt;&lt;p&gt;Liliana García Laíno&lt;/p&gt;&lt;p&gt;Jhon Smith Arenas Murillo&lt;/p&gt;&lt;p&gt; &lt;/p&gt;&lt;p&gt;Muchas gracias.&lt;/p&gt;','5','3','4','9','2','0','&lt;p&gt;Cordial saludo, &lt;/p&gt;
&lt;p&gt;Los documentos de seguridad social han sido actualizados. &lt;/p&gt;
&lt;p&gt;Asimismo, quiero informarte que con tu cuenta de usuario puedes editar los archivos ingresando en cada uno de los informes en &gt;&gt; Ver &gt;&gt; Editar reporte. &lt;/p&gt;
&lt;p&gt;Un feliz día. &lt;/p&gt;','1','0','0','0',NULL,NULL,NULL,'0','0','810','810','810','0','0','0','0','2017-12-06 14:10:59');
INSERT INTO `glpi_tickets` VALUES ('13','0','Prueba','2018-02-28 10:20:35',NULL,NULL,'2018-02-28 10:20:35','8','1','8','1','&lt;p&gt;Esto es una prueba&lt;/p&gt;','3','3','3','10','2','0',NULL,'1','0','0','0',NULL,NULL,NULL,'0','0','0','0','0','0','0','5','0','2018-02-28 10:20:35');

### Dump table glpi_tickets_tickets

DROP TABLE IF EXISTS `glpi_tickets_tickets`;
CREATE TABLE `glpi_tickets_tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id_1` int(11) NOT NULL DEFAULT '0',
  `tickets_id_2` int(11) NOT NULL DEFAULT '0',
  `link` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `unicity` (`tickets_id_1`,`tickets_id_2`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickets_users

DROP TABLE IF EXISTS `glpi_tickets_users`;
CREATE TABLE `glpi_tickets_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `use_notification` tinyint(1) NOT NULL DEFAULT '1',
  `alternative_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`tickets_id`,`type`,`users_id`,`alternative_email`),
  KEY `user` (`users_id`,`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickets_users` VALUES ('1','1','11','1','1','claudia.jaramillo@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('2','1','2','2','0','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('3','2','8','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('4','2','2','3','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('5','3','17','1','1','nelly.zapata@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('6','4','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('7','4','2','3','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('8','5','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('9','5','2','3','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('10','6','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('11','6','2','3','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('12','7','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('13','7','2','3','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('14','8','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('15','8','2','3','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('16','9','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('17','9','2','3','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('18','10','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('19','10','6','3','1','felipe.becerra@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('20','11','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('21','11','6','3','1','felipe.becerra@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('22','12','14','1','1','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('23','12','2','3','1','juan.correa2@udea.edu.co');
INSERT INTO `glpi_tickets_users` VALUES ('24','13','8','1','1','');
INSERT INTO `glpi_tickets_users` VALUES ('25','13','11','3','1','claudia.jaramillo@udea.edu.co');

### Dump table glpi_ticketsatisfactions

DROP TABLE IF EXISTS `glpi_ticketsatisfactions`;
CREATE TABLE `glpi_ticketsatisfactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `type` int(11) NOT NULL DEFAULT '1',
  `date_begin` datetime DEFAULT NULL,
  `date_answered` datetime DEFAULT NULL,
  `satisfaction` int(11) DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickets_id` (`tickets_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettasks

DROP TABLE IF EXISTS `glpi_tickettasks`;
CREATE TABLE `glpi_tickettasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `taskcategories_id` int(11) NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `content` longtext COLLATE utf8_unicode_ci,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `actiontime` int(11) NOT NULL DEFAULT '0',
  `begin` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '1',
  `users_id_tech` int(11) NOT NULL DEFAULT '0',
  `groups_id_tech` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `date_mod` (`date_mod`),
  KEY `users_id` (`users_id`),
  KEY `tickets_id` (`tickets_id`),
  KEY `is_private` (`is_private`),
  KEY `taskcategories_id` (`taskcategories_id`),
  KEY `state` (`state`),
  KEY `users_id_tech` (`users_id_tech`),
  KEY `groups_id_tech` (`groups_id_tech`),
  KEY `begin` (`begin`),
  KEY `end` (`end`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettasks` VALUES ('1','11','0','2017-12-06 14:30:21','2','Cordial saludo, 
Despues de realizar la verificación y configuración de la impresora (Software), y con la reincidencia del día de hoy se llevará a verificación técnica. 
Un feliz dia ','0','3600','2017-12-06 14:30:00','2017-12-06 15:30:00','1','6','0','2017-12-06 14:30:21');
INSERT INTO `glpi_tickettasks` VALUES ('2','8','0','2017-12-06 14:36:29','2','Cordial saludo Lina, 
Por favor cargar nuevamente el archivo. No se puede visualizar. 
Enviarlo en PDF. 
Un feliz día','0','0',NULL,NULL,'0','2','0','2017-12-06 14:36:29');
INSERT INTO `glpi_tickettasks` VALUES ('3','7','0','2017-12-06 14:40:17','2','Cordial saludo, 
Por favor enviar nuevamente el archivo, el documento no abre. 
Un feliz día. ','0','0',NULL,NULL,'1','2','0','2017-12-06 14:40:17');

### Dump table glpi_tickettemplatehiddenfields

DROP TABLE IF EXISTS `glpi_tickettemplatehiddenfields`;
CREATE TABLE `glpi_tickettemplatehiddenfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_tickettemplatemandatoryfields

DROP TABLE IF EXISTS `glpi_tickettemplatemandatoryfields`;
CREATE TABLE `glpi_tickettemplatemandatoryfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplatemandatoryfields` VALUES ('1','1','21');

### Dump table glpi_tickettemplatepredefinedfields

DROP TABLE IF EXISTS `glpi_tickettemplatepredefinedfields`;
CREATE TABLE `glpi_tickettemplatepredefinedfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tickettemplates_id` int(11) NOT NULL DEFAULT '0',
  `num` int(11) NOT NULL DEFAULT '0',
  `value` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `unicity` (`tickettemplates_id`,`num`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplatepredefinedfields` VALUES ('1','1','1','');
INSERT INTO `glpi_tickettemplatepredefinedfields` VALUES ('2','1','83','0');
INSERT INTO `glpi_tickettemplatepredefinedfields` VALUES ('3','1','7','0');
INSERT INTO `glpi_tickettemplatepredefinedfields` VALUES ('4','1','21','');

### Dump table glpi_tickettemplates

DROP TABLE IF EXISTS `glpi_tickettemplates`;
CREATE TABLE `glpi_tickettemplates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `is_recursive` (`is_recursive`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_tickettemplates` VALUES ('1','Default','0','1',NULL);
INSERT INTO `glpi_tickettemplates` VALUES ('3','Entornos virtuales','0','0','Pendiente');
INSERT INTO `glpi_tickettemplates` VALUES ('4','Soporte técnico','0','0','');
INSERT INTO `glpi_tickettemplates` VALUES ('5','Sistemas','0','0','');
INSERT INTO `glpi_tickettemplates` VALUES ('6','Comunicaciones','0','0','');

### Dump table glpi_ticketvalidations

DROP TABLE IF EXISTS `glpi_ticketvalidations`;
CREATE TABLE `glpi_ticketvalidations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `users_id` int(11) NOT NULL DEFAULT '0',
  `tickets_id` int(11) NOT NULL DEFAULT '0',
  `users_id_validate` int(11) NOT NULL DEFAULT '0',
  `comment_submission` text COLLATE utf8_unicode_ci,
  `comment_validation` text COLLATE utf8_unicode_ci,
  `status` int(11) NOT NULL DEFAULT '2',
  `submission_date` datetime DEFAULT NULL,
  `validation_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `users_id` (`users_id`),
  KEY `users_id_validate` (`users_id_validate`),
  KEY `tickets_id` (`tickets_id`),
  KEY `submission_date` (`submission_date`),
  KEY `validation_date` (`validation_date`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_transfers

DROP TABLE IF EXISTS `glpi_transfers`;
CREATE TABLE `glpi_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `keep_ticket` int(11) NOT NULL DEFAULT '0',
  `keep_networklink` int(11) NOT NULL DEFAULT '0',
  `keep_reservation` int(11) NOT NULL DEFAULT '0',
  `keep_history` int(11) NOT NULL DEFAULT '0',
  `keep_device` int(11) NOT NULL DEFAULT '0',
  `keep_infocom` int(11) NOT NULL DEFAULT '0',
  `keep_dc_monitor` int(11) NOT NULL DEFAULT '0',
  `clean_dc_monitor` int(11) NOT NULL DEFAULT '0',
  `keep_dc_phone` int(11) NOT NULL DEFAULT '0',
  `clean_dc_phone` int(11) NOT NULL DEFAULT '0',
  `keep_dc_peripheral` int(11) NOT NULL DEFAULT '0',
  `clean_dc_peripheral` int(11) NOT NULL DEFAULT '0',
  `keep_dc_printer` int(11) NOT NULL DEFAULT '0',
  `clean_dc_printer` int(11) NOT NULL DEFAULT '0',
  `keep_supplier` int(11) NOT NULL DEFAULT '0',
  `clean_supplier` int(11) NOT NULL DEFAULT '0',
  `keep_contact` int(11) NOT NULL DEFAULT '0',
  `clean_contact` int(11) NOT NULL DEFAULT '0',
  `keep_contract` int(11) NOT NULL DEFAULT '0',
  `clean_contract` int(11) NOT NULL DEFAULT '0',
  `keep_software` int(11) NOT NULL DEFAULT '0',
  `clean_software` int(11) NOT NULL DEFAULT '0',
  `keep_document` int(11) NOT NULL DEFAULT '0',
  `clean_document` int(11) NOT NULL DEFAULT '0',
  `keep_cartridgeitem` int(11) NOT NULL DEFAULT '0',
  `clean_cartridgeitem` int(11) NOT NULL DEFAULT '0',
  `keep_cartridge` int(11) NOT NULL DEFAULT '0',
  `keep_consumable` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `keep_disk` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_transfers` VALUES ('1','complete','2','2','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1','1',NULL,NULL,'1');

### Dump table glpi_usercategories

DROP TABLE IF EXISTS `glpi_usercategories`;
CREATE TABLE `glpi_usercategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_useremails

DROP TABLE IF EXISTS `glpi_useremails`;
CREATE TABLE `glpi_useremails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `is_dynamic` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`users_id`,`email`),
  KEY `email` (`email`),
  KEY `is_default` (`is_default`),
  KEY `is_dynamic` (`is_dynamic`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_useremails` VALUES ('1','2','1','0','juan.correa2@udea.edu.co');
INSERT INTO `glpi_useremails` VALUES ('2','6','1','0','felipe.becerra@udea.edu.co');
INSERT INTO `glpi_useremails` VALUES ('3','7','1','0','ctangar@gmail.com');
INSERT INTO `glpi_useremails` VALUES ('4','9','1','0','aljelova@gmail.com');
INSERT INTO `glpi_useremails` VALUES ('5','11','1','0','claudia.jaramillo@udea.edu.co');
INSERT INTO `glpi_useremails` VALUES ('6','12','1','0','maria-epr@hotmail.com');
INSERT INTO `glpi_useremails` VALUES ('7','13','1','0','sjechavarria@gmail.com');
INSERT INTO `glpi_useremails` VALUES ('8','13','0','0','juliet.echavarria@udea.edu.co');
INSERT INTO `glpi_useremails` VALUES ('9','14','1','0','asistenciacontratacioncifnsp@udea.edu.co');
INSERT INTO `glpi_useremails` VALUES ('10','15','1','0','saira.chaverra@udea.edu.co');
INSERT INTO `glpi_useremails` VALUES ('11','16','1','0','erika.alzate1416@gmail.com');
INSERT INTO `glpi_useremails` VALUES ('12','17','1','0','nelly.zapata@udea.edu.co');

### Dump table glpi_users

DROP TABLE IF EXISTS `glpi_users`;
CREATE TABLE `glpi_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `realname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `locations_id` int(11) NOT NULL DEFAULT '0',
  `language` char(10) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'see define.php CFG_GLPI[language] array',
  `use_mode` int(11) NOT NULL DEFAULT '0',
  `list_limit` int(11) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `comment` text COLLATE utf8_unicode_ci,
  `auths_id` int(11) NOT NULL DEFAULT '0',
  `authtype` int(11) NOT NULL DEFAULT '0',
  `last_login` datetime DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_sync` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `profiles_id` int(11) NOT NULL DEFAULT '0',
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `usertitles_id` int(11) NOT NULL DEFAULT '0',
  `usercategories_id` int(11) NOT NULL DEFAULT '0',
  `date_format` int(11) DEFAULT NULL,
  `number_format` int(11) DEFAULT NULL,
  `names_format` int(11) DEFAULT NULL,
  `csv_delimiter` char(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_ids_visible` tinyint(1) DEFAULT NULL,
  `use_flat_dropdowntree` tinyint(1) DEFAULT NULL,
  `show_jobs_at_login` tinyint(1) DEFAULT NULL,
  `priority_1` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_2` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_3` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_4` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_5` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_6` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `followup_private` tinyint(1) DEFAULT NULL,
  `task_private` tinyint(1) DEFAULT NULL,
  `default_requesttypes_id` int(11) DEFAULT NULL,
  `password_forget_token` char(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_forget_token_date` datetime DEFAULT NULL,
  `user_dn` text COLLATE utf8_unicode_ci,
  `registration_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `show_count_on_tabs` tinyint(1) DEFAULT NULL,
  `refresh_ticket_list` int(11) DEFAULT NULL,
  `set_default_tech` tinyint(1) DEFAULT NULL,
  `personal_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `personal_token_date` datetime DEFAULT NULL,
  `display_count_on_home` int(11) DEFAULT NULL,
  `notification_to_myself` tinyint(1) DEFAULT NULL,
  `duedateok_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatewarning_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatecritical_color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatewarning_less` int(11) DEFAULT NULL,
  `duedatecritical_less` int(11) DEFAULT NULL,
  `duedatewarning_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duedatecritical_unit` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `display_options` text COLLATE utf8_unicode_ci,
  `is_deleted_ldap` tinyint(1) NOT NULL DEFAULT '0',
  `pdffont` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `begin_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `keep_devices_when_purging_item` tinyint(1) DEFAULT NULL,
  `privatebookmarkorder` longtext COLLATE utf8_unicode_ci,
  `backcreated` tinyint(1) DEFAULT NULL,
  `task_state` int(11) DEFAULT NULL,
  `layout` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `palette` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ticket_timeline` tinyint(1) DEFAULT NULL,
  `ticket_timeline_keep_replaced_tabs` tinyint(1) DEFAULT NULL,
  `set_default_requester` tinyint(1) DEFAULT NULL,
  `lock_autolock_mode` tinyint(1) DEFAULT NULL,
  `lock_directunlock_notification` tinyint(1) DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  `highcontrast_css` tinyint(1) DEFAULT '0',
  `plannings` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unicity` (`name`),
  KEY `firstname` (`firstname`),
  KEY `realname` (`realname`),
  KEY `entities_id` (`entities_id`),
  KEY `profiles_id` (`profiles_id`),
  KEY `locations_id` (`locations_id`),
  KEY `usertitles_id` (`usertitles_id`),
  KEY `usercategories_id` (`usercategories_id`),
  KEY `is_deleted` (`is_deleted`),
  KEY `is_active` (`is_active`),
  KEY `date_mod` (`date_mod`),
  KEY `authitem` (`authtype`,`auths_id`),
  KEY `is_deleted_ldap` (`is_deleted_ldap`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_users` VALUES ('2','paola','$2y$10$CwkeBLAVba.GN1sOGu/.ROpSWTauKiwIuY585Odsz/FAbnXs/OGby','2196889','','','Cardona','Paola','1',NULL,'0','20','1',NULL,'0','1','2018-04-02 15:32:42','2018-04-02 15:32:23',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2018-02-28 10:14:18',NULL,NULL,NULL,NULL,NULL,'ts2wworw9i78cnwe3n8lvc4tbanghb7dni1jg317','2017-06-29 21:35:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'');
INSERT INTO `glpi_users` VALUES ('3','post-only','$2y$10$gQOFkJYuyEmPVdTdo0hmBeT8DpOY1kxTqxM1JA46fjaxAhvCVbRU2','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','1','2018-03-20 20:08:25','2018-03-01 18:47:28',NULL,'1','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'');
INSERT INTO `glpi_users` VALUES ('4','tech','$2y$10$YfdF1e8KjUTJAS6pxZHP7.2axbR2vtRmB7i3B2iwzZ5XUN4m2frju','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','1','2018-01-12 11:50:15','2017-07-11 14:34:19',NULL,'1','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'');
INSERT INTO `glpi_users` VALUES ('5','normal','$2y$10$6M9wMg68x710tCevdSswSOsG4QqduHhEp8o5H3kFCted.hkWuEBJe','','','','',NULL,'0',NULL,'0','20','1',NULL,'0','1','2017-06-30 11:02:04','2017-07-11 14:34:19',NULL,'1','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'');
INSERT INTO `glpi_users` VALUES ('6','felipe.becerra','$2y$10$7oFUPLz3RuiSf0l9Aq/FS.vPlsJWhKyNJ7Ntdh/QxOYKnrf0l2lhi','2196863','','3187710179','Becerra','Felipe','2',NULL,'0',NULL,'1','','0','1','2017-08-10 10:38:44','2017-07-25 18:19:56',NULL,'0','0','0','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-06-30 11:06:26',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('7','carlos.tangarife','$2y$10$QNPVyyemWB6miDIxtR.DUeriMEjGvGJgjpmW3qaOKDDqeSgCNT006','2196832','','','Tangarife','Carlos Alberto','0',NULL,'0',NULL,'1','','0','1',NULL,'2018-01-24 15:19:56',NULL,'0','4','0','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-07-10 09:59:00',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('8','prueba','$2y$10$lpJNn/dHm//mVLyE1/DaMei.s7l79/QdXCgFI3R2SnHkmbBuPaSoe','','','','prueba','prueba','1',NULL,'0',NULL,'1','','0','1','2018-03-02 13:51:28','2018-02-28 10:17:39',NULL,'0','9','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-07-10 10:07:32',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('9','alberto.lopez','$2y$10$GO6SIAyr5XXz7KZjAQazd.4DXjpxa3eorEPHHZic14zDsXMNWI57m','2196863','','','Lopez Valencia ','Alberto de Jesus','2',NULL,'0',NULL,'1','','0','1',NULL,'2017-12-22 18:02:41',NULL,'0','0','0','1','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-07-18 09:44:37','0',NULL);
INSERT INTO `glpi_users` VALUES ('10','paula.hincapie','$2y$10$qBIoqo8QVdNgzzZgmdCmf.m3srW5TbzXWDSbrpjPaypD0Ei2oremK','','','','Hincapie','Paula Michell','0',NULL,'0',NULL,'1','','0','1',NULL,'2017-07-26 00:24:49',NULL,'0','0','0','5','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-07-26 00:24:49','0',NULL);
INSERT INTO `glpi_users` VALUES ('11','43157733','$2y$10$iDz3d0h/U.kHBsg/vZ3LqObH8p4ZXKkuTCkrXRM59BJIy2J.TqrBO','','','','Jaramillo','Claudia Marleny','0',NULL,'0',NULL,'1','','0','1','2017-08-18 13:24:43','2017-08-18 13:06:25',NULL,'0','13','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,'[]',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-07-27 11:25:52',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('12','43431665','$2y$10$e2tjWm6Di3/Zx4aX9FajNOavRqnQq1YUmeKGdvhnLN7TGtNU6fwF2','','','','Peña Restrepo','Maria Elena ','0',NULL,'0',NULL,'1','','0','1','2017-11-07 15:55:06','2017-11-07 15:41:46',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-07 15:41:31',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('13','1017133754','$2y$10$QuAc2KlatpTE1.4BJyd8BOlcmOiFiw4a/Duu.htekgE190SRsrmwK','','','','Echavarria Quiceno','Sandra Julieth ','0',NULL,'0',NULL,'1','','0','1',NULL,'2017-11-14 10:41:21',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-07 15:45:09','0',NULL);
INSERT INTO `glpi_users` VALUES ('14','43695135','$2y$10$PjiuRWLue2x49HJirSsK.eE0Mc/7324.Xh2eDXxc0A5fSKzLQnvAy','','','','Ospina Perez','Lina Maria ','0',NULL,'0',NULL,'1','','0','1','2017-12-11 10:34:52','2017-11-07 15:50:05',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-07 15:46:31',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('15','32258827','$2y$10$aQBmtxuaTUs/S65GZENSguEf/tEhOXB1VMYKlYnigdbZIVjiSfi.C','','','','Chaverra ','Saira Catalina','0',NULL,'0',NULL,'1','','0','1','2017-11-07 16:00:44','2017-11-07 16:00:44',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-07 16:00:37',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('16','1128395590','$2y$10$6YWEc.dZGK8Us98n/8wYjeiqEdgWhk6LF5ARtJGat4XbY1vVCDT2q','','','','Alzate Amariles','Erika','0',NULL,'0',NULL,'1','','0','1','2017-11-07 16:03:55','2017-11-07 16:03:55',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-07 16:03:49',NULL,NULL);
INSERT INTO `glpi_users` VALUES ('17','43075826','$2y$10$aNPMC6zCtKE6TNU0dUDXTutHiW2Dc7QlhpAQ8bRXQp4/cSkRfb1u.','','','','Zapata Villarreal','Luz Nelly','0',NULL,'0',NULL,'1','','0','1','2017-11-07 16:14:43','2017-11-07 16:08:31',NULL,'0','0','0','0','0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2017-11-07 16:08:23',NULL,NULL);

### Dump table glpi_usertitles

DROP TABLE IF EXISTS `glpi_usertitles`;
CREATE TABLE `glpi_usertitles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `glpi_usertitles` VALUES ('1','Ingeniero','','2017-06-30 11:06:00','2017-06-30 11:06:00');
INSERT INTO `glpi_usertitles` VALUES ('2','Docente',NULL,NULL,NULL);
INSERT INTO `glpi_usertitles` VALUES ('3','Administrador',NULL,NULL,NULL);
INSERT INTO `glpi_usertitles` VALUES ('4','Decano',NULL,NULL,NULL);
INSERT INTO `glpi_usertitles` VALUES ('5','Contratista',NULL,NULL,NULL);
INSERT INTO `glpi_usertitles` VALUES ('6','GESIS',NULL,NULL,NULL);
INSERT INTO `glpi_usertitles` VALUES ('7','Jefe',NULL,NULL,NULL);

### Dump table glpi_virtualmachinestates

DROP TABLE IF EXISTS `glpi_virtualmachinestates`;
CREATE TABLE `glpi_virtualmachinestates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinesystems

DROP TABLE IF EXISTS `glpi_virtualmachinesystems`;
CREATE TABLE `glpi_virtualmachinesystems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_virtualmachinetypes

DROP TABLE IF EXISTS `glpi_virtualmachinetypes`;
CREATE TABLE `glpi_virtualmachinetypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment` text COLLATE utf8_unicode_ci NOT NULL,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_vlans

DROP TABLE IF EXISTS `glpi_vlans`;
CREATE TABLE `glpi_vlans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `tag` int(11) NOT NULL DEFAULT '0',
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `entities_id` (`entities_id`),
  KEY `tag` (`tag`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


### Dump table glpi_wifinetworks

DROP TABLE IF EXISTS `glpi_wifinetworks`;
CREATE TABLE `glpi_wifinetworks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entities_id` int(11) NOT NULL DEFAULT '0',
  `is_recursive` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `essid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'ad-hoc, access_point',
  `comment` text COLLATE utf8_unicode_ci,
  `date_mod` datetime DEFAULT NULL,
  `date_creation` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `essid` (`essid`),
  KEY `name` (`name`),
  KEY `date_mod` (`date_mod`),
  KEY `date_creation` (`date_creation`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

